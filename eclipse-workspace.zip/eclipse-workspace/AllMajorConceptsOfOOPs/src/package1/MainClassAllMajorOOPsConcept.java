package package1;

import package1.*;

public class MainClassAllMajorOOPsConcept 
{
	public static void main(String[] args) 
	{
		Cat objOM = new Cat();

		//objOM.setName("Eco Sport");
		//objOM.printName();
		//objOM.printName("Aspire");
		
		objOM.setName("Anamika");
		objOM.printName();
		objOM.printName("Laskar");
	}
}
