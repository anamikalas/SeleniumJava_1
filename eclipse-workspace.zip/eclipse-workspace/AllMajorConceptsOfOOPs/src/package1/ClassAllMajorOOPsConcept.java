package package1;

public class ClassAllMajorOOPsConcept {}

interface Animal
{
	void printName();
}
class Dog
{
	private String name;
	public String getName()
	{
		return name;
	}
	public void setName(String newName)
	{
		name = newName;
	}
}
class Cat extends Dog implements Animal
{
	public void printName()
	{
		System.out.println("Overriding..." + super.getName());
	}
	public void printName(String str)
	{
		System.out.println("Overloading " + str);
	}
}