package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.Test;

public class DatabaseAutomation 
{
	@Test
	public void testMethod() throws SQLException
	{
		String strUrl = "jdbc:sqlserver://DVCINH6087927/SQLEXPRESS;databaseName=AdventureWorks2019;userName=anamika;password=Amdocs@123";
		Connection con = DriverManager.getConnection(strUrl);
		Statement state = con.createStatement();
		ResultSet res = state.executeQuery("select * from Person.Address;");
	}
}
