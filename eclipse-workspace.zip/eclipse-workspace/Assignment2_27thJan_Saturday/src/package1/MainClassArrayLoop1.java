package package1;

import package2.ClassArrayLoop1;

public class MainClassArrayLoop1 
{
	public static void main(String[] args)
	{
		ClassArrayLoop1 objAL1 = new ClassArrayLoop1();
		
		//objAL1.printArrayWithLoop1();
		//objAL1.printEvenNoFrom1to20_1();
		//objAL1.printArryWithNegativeNo();
		//int num1=1, num2=20;
		//objAL1.printSumFrom1To100_1(num1,num2);
		//int num1 = 50, num2 = 100;
		//objAL1.printCountOddNum50To100_1(num1,num2);
		//objAL1.printPrimeNo2To10_1();
		//objAL1.printPrimeNo2To10_1();
		//objAL1.printFactorial1(6);
		//objAL1.printAverage1(20);
		//objAL1.printAdditionOfEvenNo(10,20);
		//objAL1.findFactorOfANo1();
		objAL1.removeDuplicateValueFromArray();
	}
}
