package package2;

public class ClassArrayLoop1 
{
	public void printArrayWithLoop1() // Define array 10,20,30,40,50 And print110,120,130,140,150
	{
		int arr1[] = new int[] {10,20,30,40,50};
		for(int i=10; i<=50; i=i+10)
			//System.out.println(100 + i); //1st way to get expected result
		{
			int val1 = 100+i;
			System.out.println(val1); //2nd way to get expected result
		}
	}
	public void printEvenNoFrom1to20_1() //Print even number between 1 to 20
	{
		System.out.println("Even no's are:- ========================================================");
		for(int i=1; i<=20; i++)
		{
			if(i%2==0)
				System.out.println(i);
		}
	}
	public void printArryWithNegativeNo() //Print -ve numbers form an array
	{
		int arr1[] = new int[] {-45,89,-78,4,-6};
		int arr1Len1 = arr1.length;
		
		System.out.println("Negative numbers are:- ================================================");
		
		for(int i=0; i<arr1Len1; i++)
		{
			if(arr1[i]<0)
			{
				System.out.println(arr1[i]);
			}
			//else
				//System.out.println("Positive no.:- " + arr1[i]);
		}
	}
	public int printSumFrom1To100_1(int num1, int num2) //Print sum from 1 to 10 number
	{
		System.out.println("Sum is:- ===============================================================");
		
		int sum1 = 0;
		for(int i=num1; i<=num2; i++)
		{
			//sum1 = sum1 + i;
			sum1 += i;
		}	
		System.out.println(sum1);
		return sum1;
	}
	public int printCountOddNum50To100_1(int num1, int num2) //Print count of odd numbers from 50 to 100
	{
		System.out.println("Count of odd number's from 50 to 100:- =============================");
		int count1 = 0;
		for(int i=num1; i<=num2; i++)
		{
			if(i%2!=0)
			{
				count1 = count1 + 1;
			}			
		}
		
		System.out.println(count1);
		return count1;
	}
	public void printPrimeNo2To10_1() //Print prime numbers between 1 to 10
	{
		System.out.println("Prime numbers between 1 to 10 :- =====================================");
		//int count1 = 0;
		for(int i=2; i<=10; i++)
		{
			int count1 = 0;
			for(int j=1; j<=i; j++)
			{
				if(i%j==0)
					count1++;
			}
			if(count1==2)
				System.out.println(i);
		}
	}
	public int printFactorial1(int num1) //Print factorial of a no
	{
		int factorial1=1;
		for(int i=num1; i>=1; i--)
		{
			factorial1 = factorial1*i;
		}
		System.out.println(factorial1);
		return factorial1;
	}
	public double printAverage1(double num) //Print average
	{
		double sum = 0, avg = 0;
		for(double i=1; i<=num; i++)
		{
			sum += i;
			avg = sum/i;
		}
		
		
		System.out.println(avg);
		return avg;
	}
	public int printAdditionOfEvenNo(int num1,int num2) //Print Addition of even no
	{
		int sum=0;
		for(int i=num1; i<=num2; i++)
		{
			if(i%2==0)
			{
				//i++;
				System.out.println(i); //Printing all even no's
				sum +=i;
			}
			
		}
		
		System.out.println(sum); //Printing sum of even no's
		return sum;
	}
	public void findFactorOfANo1() //Print factor (the value by which number is divisible) of a number
	{
		int num=20;
		for(int i=1; i<=num; i++)
		{
			if(num%i==0)
				
				System.out.println(i);
		}
	}
	public void printReverseNumber() //Reverse a number
	{
		//int num = 12345;
	}
	public void removeDuplicateValueFromArray()
	{
		int intArr[] = new int[] {10,2,4,2,5,7,5,10,14,17,14,19};
		int countInt1 = 0, countInt2 = 0; 
		
		for(int i=0; i<intArr.length; i++)
		{
			for(int j=0; j<intArr.length; j++)
			{
				if(intArr[i] == intArr[j])
					countInt1++;
			}
			if(countInt1 > 1)
			{
				for(int k=0; k<=i; k++)
				{
					if(intArr[i] == intArr[k])
						countInt2++;
				}
			}
			if(countInt1 == 1 && countInt2 < 2)
				System.out.println("Unique character's are:- " + intArr[i]);
			countInt1 = 0;
			countInt2 = 0;
		}
		
	}
}
