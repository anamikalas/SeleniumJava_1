package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

public class Class_FileOperation 
{
	//we will pass key as parameter and will return key value
	public String readPropertyFile(String strKey) throws Exception
	{
		File file = new File(".\\InputFolder\\InputFile.properties"); //given the path of the file to read
		FileInputStream fis = new FileInputStream(file); //start reading file
		
		Properties prop = new Properties(); //read properties of file
		prop.load(fis);
		String strVal = prop.getProperty(strKey);
		return strVal;
	}
}
