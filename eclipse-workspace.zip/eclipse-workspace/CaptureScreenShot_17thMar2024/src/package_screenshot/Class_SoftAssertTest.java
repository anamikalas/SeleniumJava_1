package package_screenshot;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

@Test
public class Class_SoftAssertTest 
{
	public void testMethod2()
	{
		System.out.println("Line 1..........");
		
		//Assert.assertEquals(1, 2); //if there is 2 condition and 1st condition failed than it will stop execution and will not print Line 2
		System.out.println("Line 2..........");
				
		SoftAssert sa1 = new SoftAssert(); //if there is 2 condition and 1st condition failed than also it will go to the 2nd condition and will print Line 2
		sa1.assertEquals(1, 2);		
		System.out.println("Line 3...........");
		
		SoftAssert sa2 = new SoftAssert();
		sa2.assertEquals(3, 4);
		System.out.println("Line 4.......");
		
		sa2.assertAll(); //invoke all soft assert
		
		System.out.println("Line 5...........");
	}
}
