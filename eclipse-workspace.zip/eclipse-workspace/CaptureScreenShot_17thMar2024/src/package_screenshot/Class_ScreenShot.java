package package_screenshot;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import utilities.Class_FileOperation;

public class Class_ScreenShot 
{
	WebDriver driver;
	
	@Test(invocationCount = 2, description = "this method will execute 2 times", enabled = true) //this method will execute 2 times
	public void testMethod() throws Exception
	{
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe"); //Server layer
		driver = new ChromeDriver(); //API layer, launch browser
		driver.manage().window().maximize();
		//driver.manage().window().fullscreen(); //It will maximize window, will work for Safari browser
		//driver.get("https://www.saucedemo.com/");
		Class_FileOperation objFO = new Class_FileOperation();
		String strVal = objFO.readPropertyFile("pageUrl");
		driver.get(strVal);
		String strTitle = driver.getTitle();
		Assert.assertEquals(strTitle, "Test Title");		
	}
	
	@AfterMethod
	public void captureScreenshot(ITestResult testResult) throws Exception
	{
		if(testResult.getStatus() == ITestResult.FAILURE)
		{
			//code to capture screenshot
			TakesScreenshot tkSc = (TakesScreenshot)driver; //created an instance of TakeScreenshot interface
			File file = tkSc.getScreenshotAs(OutputType.FILE); //capture screenshot in a file variable
			FileHandler.copy(file, new File(".\\Screenshot_Folder\\Error.png")); //copied the file variable to an actual image file
		}
	}
}
