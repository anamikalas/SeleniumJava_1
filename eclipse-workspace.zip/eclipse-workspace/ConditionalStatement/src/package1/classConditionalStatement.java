package package1;

public class classConditionalStatement {
	
	public boolean compare2Numbrs(int a, int b) {

		if (a < b) {
			// System.out.println("a is less than b");
			return true;
		} else {
			// System.out.println("a is greater than b");
		}
		return false;
	}

	// verify 3 is in between 2 and 4, compare 3 number
	public void checkThreeNumber1() {
		if (3 > 2 && 3 < 4) // 3>2 and 3<4
		{
			// return b;
			System.out.println("Return 3");
		} else {
			System.out.println("Return 4");
		}
	}

	public boolean checkThreeNumber2(int a, int b, int c) {
		if (b > a && b < c) {
			return true;
		} else {
			return false;
		}
	}

	public void multipleNumber1() {
		int a = 10;
		// verify a is equal to 0
		// verify a is less than 100
		if (a == 0) {
			System.out.println("a is equal to 0");
		} else if (a < 100) {
			System.out.println("a is less than 100");
		} else {
			System.out.println("No condition matches");
		}
	}

	public int findMaxAmong3Nuber2(int a, int b, int c) {
		if (a > b && a > c) {
			return a;
		} else if (b > c && b > a) {
			return b;
		} else {
			return c;
		}
	}

	public void findLongestString() // Find longer string
	{
		String str1 = "Hello";
		String str2 = "Hello Java";
		int a = str1.length();
		int b = str2.length();

		if (str1.length() > str2.length()) {
			System.out.println(str1 + " " + "string is longer" + " " + ", length is" + " " + a);
		} else {
			System.out.println(str2 + " " + "string is longer" + " " + ", length is" + " " + b);
		}
	}
}
