package package1;

public class mainClass1 
{
	public static void main(String[] args)
	{
		classConditionalStatement objCS1=new classConditionalStatement();
		boolean res1=objCS1.compare2Numbrs(10, 20);
		System.out.println(res1);
		objCS1.checkThreeNumber1();
		boolean res2=objCS1.checkThreeNumber2(2, 3, 4);
		System.out.println(res2);
		objCS1.multipleNumber1();
		int res3=objCS1.findMaxAmong3Nuber2(50, 20, 30);
		System.out.println(res3);
		objCS1.findLongestString();
	}
}
