package package1;

import package2.*;

public class MainClass_AccessModifier
{
	public static void main(String[] args)
	{
		ClassAccessModifier objNew = new ClassAccessModifier();
		//objNew.testMethod();
		
	}
}
