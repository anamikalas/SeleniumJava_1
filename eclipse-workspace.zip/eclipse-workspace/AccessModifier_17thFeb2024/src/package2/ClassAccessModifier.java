package package2;

public class ClassAccessModifier // all exclude protedted
{
	public int a = 10; // all
	
	public ClassAccessModifier() //COnstructor - public protected default private
	{
		
	}
	
	private void testethod1()
	{
		System.out.println("Private Method 1...");
	}
	public void callPrivateMethod()
	{
		ClassAccessModifier objAM = new ClassAccessModifier();
		objAM.testethod1();
	}
	protected void protectedMethod()
	{
		System.out.println("Protected method...");
	}
	protected void privateMethod2()
	{
		System.out.println("Protected 2nd...");
	}
	void defaultAccessModifierMethod()
	{
		System.out.println("Default access modifier...");
	}
}