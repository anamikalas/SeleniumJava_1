package package2;

public class CLassCar extends ClassAccessModifier
{
public void callTestMethod1()
{
	ClassAccessModifier objAM = new ClassAccessModifier();
	//objAM.testMethod(); //giving error
	objAM.protectedMethod(); //within defined class 
	objAM.defaultAccessModifierMethod(); //scope limited to only package
}
}
