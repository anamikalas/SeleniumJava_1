package pacjake1;

import package2.ClassDynamicCollection;

public class MainClassDynamicCallection 
{
	public static void main(String[] args)
	{
		ClassDynamicCollection objCDC = new ClassDynamicCollection();
		//objCDC.demoArrayList();
		//objCDC.demoArrayListForLoop();
		//objCDC.verifyArrayListContainJava();
		objCDC.demoHashTable();
	}
}
