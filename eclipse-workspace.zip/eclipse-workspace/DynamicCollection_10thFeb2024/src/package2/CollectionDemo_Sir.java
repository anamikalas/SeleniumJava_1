package package2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Vector;

public class CollectionDemo_Sir {
	
	public void DemoArrayList()
	{
		
		ArrayList<String> arrlst=new ArrayList<String>();
		arrlst.add("Test");
		arrlst.add("Demo");
		arrlst.add("Java");
		arrlst.add("Hello");
		
		arrlst.size(); // Find the length of an array list
		
		System.out.println( arrlst.get(2));
		
		/*
		for(int i=3;i<arrlst.size();i=i+1)
		{
			System.out.println(arrlst.get(i));
		}
		*/
		// arr[i]
		// Verify arrlst contains Java or not 
		for(  String var  :   arrlst   )
		{
			if(var.equalsIgnoreCase("javA"))
			{
				System.out.println("Java is present");
			}
		}
		
		
		if(arrlst.contains("Java"))
			System.out.println("Java is present");
	
	}
	
	public void ListDemo()
	{
		// List-Interface
		// Rule: We cannot create an object of interface
		List<String> lst=new LinkedList<String>();
		List<String> lst1=new ArrayList<String>();
		List<String> lst2=new Vector<String>();
		
		Set<String> sss=new HashSet<String>();
		
		HashSet<String> hst=new HashSet<String>();
		
		// Set - you can not store duplicate value, can have only one null value
		// list - duplicate value is allowed, can have multiple null value
		
	}
	
	public void DemoHashTable()
	{
		// Key cannot be duplicate
		Hashtable<Integer, String> hst=new Hashtable<Integer, String>();
		hst.put(10, "a1");
		hst.put(20, "a2");
		hst.put(30, "a3");
		hst.put(40, "a4");
		
		System.out.println(hst.get(20));
		
		HashMap<Integer, String> hsp=new HashMap<Integer, String>();
		
		// HashMap - null value are allowed
		// Hashtable - null values are not allowed
		
		// Collection - Interface - Set,List,Queue
		// Collections - Class - All dynamic collection is under Collections class(Collection+Map)
	}

}
