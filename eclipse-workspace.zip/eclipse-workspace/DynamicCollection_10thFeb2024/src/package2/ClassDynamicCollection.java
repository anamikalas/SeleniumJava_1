package package2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class ClassDynamicCollection 
{
	public void demoArrayList()
	{
		ArrayList<String> arrList = new ArrayList<String>();
		arrList.add("Test");
		arrList.add("Demo");
		arrList.add("Java");
		arrList.add("Hello");
		
		System.out.println(arrList.get(2)); //java
	}
	public void demoArrayListForLoop()
	{
		ArrayList<String> arrList = new ArrayList<String>();
		arrList.add("Welcome");
		arrList.add("to");
		arrList.add("India");
		arrList.add("country");
		String newStr = "";
		
		//For loop
		/*for(int i=0; i<arrList.size(); i++)
		{
			//newStr = newStr + " " + arrList.get(i);
			System.out.println(arrList.get(i));
		}
		System.out.println(newStr);*/
		
		//For each loop
		for(String str : arrList)
		{
			System.out.println(str);
		}
	}
	public void verifyArrayListContainJava()
	{
		ArrayList<String> arrList = new ArrayList<String>();
		arrList.add("this");
		arrList.add("is");
		arrList.add("java");
		boolean isPresent = false;
		String str1 = "";
		
		/*if(arrList.contains("java"))
		{
			isPresent = true;
		}*/
		
		for(String str2 : arrList)
		{
			if(str2.equals("java"))
				isPresent = true;
		}
		if(isPresent == true)
			System.out.println("Java is there...");
		else
			System.out.println("Java not present...");
	}
	public void demoList()
	{	
		//List interface
		//we can't create object of an Interface
		List<String> listStr1 = new ArrayList<String>();
		List<String> listStr2 = new Vector<String>();
		List<String> listStr3 = new LinkedList<String>();
	}
	public void demoHashTable()
	{
		//Key can't be duplicate
		Hashtable<Integer, String> hasT = new Hashtable<Integer, String>();
		hasT.put(10, "a1");
		hasT.put(20, "a2");
		hasT.put(30, "a3");
		hasT.put(40, "a4");
		
		System.out.println(hasT.get(20));
		
		//HashMap - Can store null value
		//Hashtable - Can not store null value
	}
	public void addValueAtTheMiddleOfTheAyyayList()
	{
		ArrayList<String> arrList = new ArrayList<String>();
		arrList.add("Test 1");
		arrList.add("Test 2");
		arrList.add("Test 3");
		arrList.add("Test 4");
		
		int getIndex = arrList.indexOf("Test 2"); //Getting index of Test 2
		
		arrList.set(getIndex, "Replaced Text"); //Replacing text at that index position
		System.out.println(arrList.get(1));
	}
	public void addValueAtTheMiddleOfTheLinkedList()
	{
		LinkedList<String> linkedList = new LinkedList<String>();
		 linkedList.add("Hi 1");
		 linkedList.offerLast("Hi 5");
		 linkedList.add("Hi 2");
		 linkedList.add("Hi 3");
		 linkedList.add("Hi 4");
		 
		 //linkedList.offer("Hi 5");
		 System.out.println(linkedList);
	}
	public void sortIntegerArrayAndVerifyBothAreSame()
	{
		int intArr1[] = new int[] {2,1,5,3};
		int intArr2[] = new int[] {5,3,1,2};
		boolean isSame = false;

		Arrays.sort(intArr1);
		Arrays.sort(intArr2);

		if(intArr1.length != intArr2.length)
		{
			isSame = false;
			System.out.println("Both arrays are different in length...");
		}
		else
		{
			for(int i=0; i<intArr1.length; i++)
			{
				if(intArr1[i] != intArr2[i])
				{
					isSame = false;
					break;
				}
				else
					isSame = true;
			}
			if(isSame == true)
				System.out.println("Both arrays are same...");
			else
				System.out.println("Both arrays are not same...");
		}
	}
}
