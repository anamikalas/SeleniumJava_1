package package_ArrayList_UT;

import java.util.ArrayList;
import java.util.*;
//ArrayList's are index base Data Structure
//ArrayList can store different types of data types or Heterogeneous data types
//ArrayList can store duplicate values
//ArrayList can store any number of null values
//ArrayList follows insertion order, means the order inserted the value to the ArrayList same order data will be fetched
//ArrayList doesn't follow sorting order
//ArrayList's are non-synchronised
public class Class_ArrayList_UT 
{	
	public void arrayList()
	{
		ArrayList<Integer> arrList = new ArrayList<Integer>();
		arrList.add(0, 10);
		arrList.add(20);
		arrList.add(30);
		arrList.add(40);
		arrList.add(0, 50);
		
		//System.out.println(arrList);
		
		ArrayList<Object> arrList2 = new ArrayList<Object>();
		arrList2.add(10);
		arrList2.add("abc");
		arrList2.add(20.33);
		arrList2.add('c');
		arrList2.add(50.55f);
		arrList2.add(arrList);
		//System.out.println(arrList2);
		
		//System.out.println(arrList2);
		ArrayList objArr = new ArrayList();
		objArr.add(10);
		objArr.add("asd");
		//System.out.println(objArr);
		
		Integer intArr[] = new Integer[] {16,17,18,19,20,21};
		List<Integer> list = new ArrayList<Integer>(){{add(1);add(2);add(3);}};
		Collections.addAll(list, 4,5,6,7,8,9,0);
		System.out.println(list);
		
		list = List.of(11,12,13,14,15);                   
		System.out.println(list);
		
		list = new ArrayList<Integer>(Arrays.asList(intArr));
		System.out.println(list);
		
	}
}
