package package_ArrayList_UT;

public class MainClass_ArrayList_UT 
{
	public static void main(String[] args)
	{
		Class_ArrayList_UT objAL = new Class_ArrayList_UT();
		objAL.arrayList();
	}
}
