package demo1;

//import demo2.ArithmaticOps_Assignment2;

public class mainClassAssignment2 
{
	public static void main(String[] args)
	{
		demo2.ArithmaticOps_Assignment2 objAO2= new demo2.ArithmaticOps_Assignment2();
		System.out.println(objAO2.add1(10, 7));
		System.out.println(objAO2.sub1(20, 7));
		
	}
}
