package demo2;

public class ArithmaticOps_Assignment3
{
	public int add4(int a,int b)
	{
		return a+b;
	}
}
