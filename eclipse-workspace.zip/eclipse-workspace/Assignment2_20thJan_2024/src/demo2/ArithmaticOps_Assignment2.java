package demo2;

public class ArithmaticOps_Assignment2 
{
	public int add1(int a,int b)
	{
		int c=a+b;
		return c;
	}
	public int sub1(int a,int b)
	{
		int c=b-a;
		return c;
	}
}
