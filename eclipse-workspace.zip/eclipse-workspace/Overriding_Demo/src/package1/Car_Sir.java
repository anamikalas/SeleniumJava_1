package package1;

public class Car_Sir extends Vehicle_Sir
{
	
	public int Wheel(int b,String str1)
	{
		System.out.println("Car has 4 wheel");
		return 20;
	}

}
