package package1;

public class ClassCar extends ClassVehicle
{
	protected int methodWheel(int a, int b)
	{
		System.out.println("Wheel method got extended in ClassCar...");
		return a;
	}
	
	
}
