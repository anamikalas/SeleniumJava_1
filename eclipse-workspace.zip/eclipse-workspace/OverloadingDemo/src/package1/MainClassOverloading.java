package package1;

public class MainClassOverloading 
{
	// method name should be same
	//parameter (either number or in data type) should be different
	public static void main(String[] args)
	{
		ClassCar objCar1 = new ClassCar(2, 5); //constructor overloading
		ClassCar objCar2 = new ClassCar(2,2.5); //constructor overloading
		ClassCar objCar3 = new ClassCar(2.5, 3, 2); //constructor overloading
		ClassCar.staticMethod(5, 2);
		ClassCar.staticMethod(2.5, 3);
//		objCar.calculateSpeed();
//		objCar.calculateSpeed(100);
//		objCar.calculateSpeed(100, 60);
	}
}
