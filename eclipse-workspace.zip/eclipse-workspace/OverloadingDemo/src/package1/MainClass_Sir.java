package package1;

public class MainClass_Sir {

	// Rule
	// 1. Method name should be same
	// 2. Parameter should be different either in number or in data type
	// 3. Can we overload static method - Yes
	// 4. Can we overload a main method - Yes
	public static void main(String[] args) {
		
		Car_Sir obj=new Car_Sir(10);
		obj.CalculateSpeed(100,60);
		obj.CalculateSpeed(100, 60.23);
		obj.CalculateSpeed(100.23, 60);
	}
	
	public static void main(int a)
	{
		
	}

}
