package package1;

public class Car_Sir 
{
	
	public Car_Sir(int a)
	{
		
	}
	
	public Car_Sir(int a,int b)
	{
		
	}
	
	public void CalculateSpeed()
	{
		System.out.println("Speed of Car is 40kmph");
	}
	
	public void CalculateSpeed(int distance)
	{
		int speed=distance/60;
		System.out.println(speed);
	}
	
	
	
	public void CalculateSpeed(int distance,int time)
	{
		int speed=distance/time;
		System.out.println(speed+"....");
	}
	
	public void CalculateSpeed(double distance,double time)
	{
		double speed=distance/time;
		System.out.println(speed);
	}
	


}
