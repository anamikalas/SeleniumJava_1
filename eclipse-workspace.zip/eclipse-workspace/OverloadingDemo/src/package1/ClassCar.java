package package1;

public class ClassCar 
{
	public void calculateSpeed()
	{
		System.out.println("Speed of car is 40km/hr");
	}
	public void calculateSpeed(int distance)
	{
		int speed = distance/60;
		System.out.println(speed);
	}
	public void calculateSpeed(int distance, int time)
	{
		int speed = distance/time;
		System.out.println(speed);
	}
	public ClassCar(int a, int b) //constructor overloading
	{
		int c = a + b;
		System.out.println("Sum:- " + c);
	}
	public ClassCar(int a, double b) //constructor overloading
	{
		double c = a + b;
		System.out.println("Sum:- " + c);
	}
	public ClassCar(double a, int b, int c) //constructor overloading
	{
		double d = a + b + c;
		System.out.println("Sum:- " + d);
	}
	public static void staticMethod(int a, int b)
	{
		int c = a + b;
		System.out.println("Static sum:- " + c);
	}
	public static void staticMethod(double a, int b)
	{
		double c = a + b;
		System.out.println("Static sum:- " + c);
	}
}
