package Test_Script;

import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import Page_Repository.*;
import Utilities.FileOperation_OP;

public class CreateServiceRequestParkingSlot_Test extends BaseClass_OP_Test 
{
	String strMailBody = "";
	String strNew = "";

	// extract number from text
	public String extractNumberFromText(String strMailBdy) 
	{
		Login_OP_Page objSP = new Login_OP_Page(driver);
		strMailBody = objSP.getOutlookMailBodyText();
		char charArr[] = strMailBody.toCharArray();

		for (int i = 0; i < charArr.length; i++) 
		{
			if (Character.isDigit(charArr[i]))
				strNew = strNew + charArr[i];
		}

		// int num = Integer.parseInt(strNew);
		strNew = strNew.substring(1, 7);
		return strNew;
	}

	// switch to specific window
	public void switchToSpecificWindow(int windowId) 
	{

	}

	@Test(enabled = true, priority = 1)
	public void doLogin() 
	{
		try 
		{
			/// ************* Login /// *************************************************************************************************************
			// test = extntReport.createTest("testLogin");

			CreateServiceRequestParkingSlot_Page objSP = new CreateServiceRequestParkingSlot_Page(driver);
			FileOperation_OP objF = new FileOperation_OP();

			// String strTktName = objF.readPropertyFile("Ticket_Name_AC");

			objSP.switchiFrame();
			objSP.setUserName(objF.readPropertyFile("AC_User_Id"));
			objSP.setPassword(objF.readPropertyFile("AC_User_Pwd"));
			objSP.clickLoginBtn();

			if (driver.findElement(By.xpath("//input[@id='email_factor']")).isSelected()) // if CheckBox is selected
			{
				objSP.clickContinueBtn();
			} else 
			{
				objSP.checkCheckBox();
			}
			objSP.clickContinueBtn();

			String strDefaultWindowHandleBE = driver.getWindowHandle();

			driver.switchTo().newWindow(WindowType.TAB); // opening a new tab
			driver.get(objF.readPropertyFile("AC_Outlook_2")); // launching outlook in newly opened tab

			switchToSpecificWindow(1); // Switching to outlook window

			// objSP.setOutlookUserName(objF.readPropertiesFile("Outlook_UserNm"));
			// objSP.clickOutlookOkButton();

			objSP.setOutlookEmail(objF.readPropertyFile("Outlook_Email")); // set email id
			objSP.clickOutlookNextBtn(); // click Next button

			// Thread.sleep(2000);

			objSP.setOutlookPwd(objF.readPropertyFile("Outlook_Pwd"));
			Thread.sleep(5000);
			objSP.clickOutlookSignInBtn();

			Thread.sleep(20000);

			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(9900000)); // apply Explicit wait
			wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)']")));

			objSP.clickOnDraftFolder(); // click on Draft
			objSP.clickOutlookInbox(); // click on Inbox
			objSP.clickOutlookMultifactor();

			Thread.sleep(12000);

			extractNumberFromText(strNew); // getting mail body and extracting number from text
			System.out.println("Number: " + strNew);

			// objSP.clickDeleteIconOutlook1();

			// objSP.clickDeleteIconOutlook2();
			Actions actns = new Actions(driver);
			actns.moveToElement(driver.findElement(By.xpath("(//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)'])[1]"))).click(driver.findElement(By.xpath("(//div[@class='QpoLy'])[1]"))).build().perform();

			// driver.close(); //closing the outlook window/tab

			driver.switchTo().window(strDefaultWindowHandleBE); // switch to default window

			objSP.switchiFrame();
			objSP.set6DigitVerficationCode(strNew); // set 6 digit verification code
			objSP.clickVerifyBtn();

			switchToSpecificWindow(1);
			driver.get(objF.readPropertyFile("AC_Url_OP_FE"));

		} catch (Exception ex) 
		{
			ex.printStackTrace();
		}
	}

	@Test(enabled = true, priority = 2)
	public void hoverCreateShortCutAndCreateSR() throws IOException 
	{
		CreateServiceRequestParkingSlot_Page objSRP = new CreateServiceRequestParkingSlot_Page(driver);
		FileOperation_OP objF = new FileOperation_OP();
		
		WebDriverWait waitCS = new WebDriverWait(driver, Duration.ofSeconds(95000000));
		waitCS.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'CAMPUS')]")));		
		objSRP.clickCampusServices();
		
		WebDriverWait waitPL1 = new WebDriverWait(driver, Duration.ofSeconds(950000));
		waitPL1.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Parking Lot')]")));
		objSRP.clickParkingLotLevel_1();
		
		WebDriverWait waitPL2 = new WebDriverWait(driver, Duration.ofSeconds(95000));
		waitPL2.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Parking-lot')]")));
		objSRP.hoverParkingLotLevel_2(); //hover Parking-lot
		
		String strStarAttribute = objSRP.getPinkStarAttribute();
		if(!(strStarAttribute.equals(objF.readPropertyFile("NG_SOURCE"))))
		{
			objSRP.clickStarAddToFavIcon();
		}
		objSRP.clickQuickLinks();
		
		objSRP.clickMegaMenuParkingLot();
		
		String strServiceReq = objSRP.verifyServiceRequestPage();
		Assert.assertEquals(strServiceReq, "SERVICE REQUEST");
		
		String strTktName = objSRP.verifyTicketNameParkingLot();
		Assert.assertEquals(objF.readPropertyFile("TICKET_NAME"), strTktName);
		
		objSRP.clickQuickLinks();
		objSRP.hoverOnParkingLot();
		objSRP.clickOkBtn();
	}
}
