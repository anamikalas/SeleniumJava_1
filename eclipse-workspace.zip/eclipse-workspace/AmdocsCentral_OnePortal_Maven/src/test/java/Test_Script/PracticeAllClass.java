package Test_Script;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class PracticeAllClass 
{
	public ExtentSparkReporter extntSparkerReporter;
	public ExtentReports extntReports;
	public ExtentTest extntTest;
	
	public void startReport()
	{
		try
		{
			extntSparkerReporter = new ExtentSparkReporter("");
			
			extntReports = new ExtentReports();
			extntReports.attachReporter(extntSparkerReporter);
			extntReports.setSystemInfo("OS", "Windows 11");
			extntReports.setSystemInfo("Browser", "Chrome");
			
			extntSparkerReporter.config().setDocumentTitle("");
			extntSparkerReporter.config().setReportName("Report Name");
			extntSparkerReporter.config().setTheme(null);
			extntSparkerReporter.config().setTimeStampFormat("");
		}
		catch(Exception ex)
		{
			
		}
	}
}
