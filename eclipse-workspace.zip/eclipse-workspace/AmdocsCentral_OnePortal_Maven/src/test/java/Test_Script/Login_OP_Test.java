package Test_Script;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import Page_Repository.Login_OP_Page;
import Utilities.FileOperation_OP;

public class Login_OP_Test extends BaseClass_OP_Test 
{
	Login_OP_Page objL = new Login_OP_Page(driver);
	String strMailBody = "";
	String strNew = "";

	// extract number from text
	public String extractNumberFromText(String strMailBdy) 
	{
		Login_OP_Page objL = new Login_OP_Page(driver);
		strMailBody = objL.getOutlookMailBodyText();
		char charArr[] = strMailBody.toCharArray();

		for (int i = 0; i < charArr.length; i++) 
		{
			if (Character.isDigit(charArr[i]))
				strNew = strNew + charArr[i];
		}

		// int num = Integer.parseInt(strNew);
		strNew = strNew.substring(1, 7);
		return strNew;
	}

	// switch to specific window
	public void switchToSpecificWindow(int windowId) 
	{
		try 
		{
			String strWindowHandle = "";

			Set<String> setAllWindowHandle = driver.getWindowHandles();
			Iterator<String> itrWindowHandle = setAllWindowHandle.iterator();

			for (int i = 0; i <= windowId; i++) 
			{
				strWindowHandle = itrWindowHandle.next();
			}
			driver.switchTo().window(strWindowHandle);

		} catch (Exception ex) 
		{
			ex.printStackTrace();
		}
	}

	@Test(enabled = true, priority = 1)
	public void testLogin() 
	{
		try
		{
			///************* Login *************************************************************************************************************
			//test = extntReport.createTest("testLogin");
			
			Login_OP_Page objL = new Login_OP_Page(driver);
			FileOperation_OP objF = new FileOperation_OP();
			
			
			//String strTktName = objF.readPropertyFile("Ticket_Name_AC");

			objL.switchiFrame();
			objL.setUserName(objF.readPropertyFile("AC_User_Id"));
			objL.setPassword(objF.readPropertyFile("AC_User_Pwd"));
			objL.clickLoginBtn();

			if(driver.findElement(By.xpath("//input[@id='email_factor']")).isSelected()) //if CheckBox is selected
			{
				objL.clickContinueBtn();
			}
			else
			{
				objL.checkCheckBox();
			}
			objL.clickContinueBtn();

			String strDefaultWindowHandleBE = driver.getWindowHandle();	
			
			driver.switchTo().newWindow(WindowType.TAB); //opening a new tab
			driver.get(objF.readPropertyFile("AC_Outlook_2")); //launching outlook in newly opened tab	

			switchToSpecificWindow(1); //Switching to outlook window

			//objL.setOutlookUserName(objF.readPropertiesFile("Outlook_UserNm"));		
			//objL.clickOutlookOkButton();

			objL.setOutlookEmail(objF.readPropertyFile("Outlook_Email")); //set email id
			objL.clickOutlookNextBtn(); //click Next button
			
			//Thread.sleep(2000);
			
			objL.setOutlookPwd(objF.readPropertyFile("Outlook_Pwd"));
			Thread.sleep(5000);
			objL.clickOutlookSignInBtn();
			
			Thread.sleep(20000);

			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(9900000)); //apply Explicit wait
			wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)']")));

			objL.clickOnDraftFolder(); //click on Draft
			objL.clickOutlookInbox(); //click on Inbox
			objL.clickOutlookMultifactor();
			
			Thread.sleep(12000);
			
			extractNumberFromText(strNew); //getting mail body and extracting number from text
			System.out.println("Number: " + strNew);
			
			//objL.clickDeleteIconOutlook1();
			
			//objL.clickDeleteIconOutlook2();
			Actions actns = new Actions(driver);
			actns.moveToElement(driver.findElement(By.xpath("(//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)'])[1]"))).click(driver.findElement(By.xpath("(//div[@class='QpoLy'])[1]"))).build().perform();
			
			//driver.close(); //closing the outlook window/tab

			driver.switchTo().window(strDefaultWindowHandleBE); //switch to default window

			objL.switchiFrame();
			objL.set6DigitVerficationCode(strNew); //set 6 digit verification code
			objL.clickVerifyBtn();
			
			switchToSpecificWindow(1);
			driver.get(objF.readPropertyFile("AC_Url_OP_FE"));
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}

	}
}
