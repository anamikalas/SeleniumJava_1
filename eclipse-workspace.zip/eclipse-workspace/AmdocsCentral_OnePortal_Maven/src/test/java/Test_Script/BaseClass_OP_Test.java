package Test_Script;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

import Utilities.BrowserOperation_OP;
import Utilities.ExtentReport_OP;
import org.testng.annotations.*;

public class BaseClass_OP_Test
{
	public WebDriver driver;
	
	BrowserOperation_OP objB = new BrowserOperation_OP();
	
	ExtentReport_OP objER = new ExtentReport_OP();
	
	//launch application
	@BeforeClass(enabled = true)
	public void launchAppBE_OP_Base()
	{
		try
		{
			//objER.startReport();
			driver = objB.launchAppBE_OP();
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	//close browser
	@AfterClass(enabled = true)
	//public void closeBrowser(ITestResult testRes)
	public void closeBrowser()
	{
		//objER.getTestResult();
		objER.tearDown();
		driver.close();
	}
}
