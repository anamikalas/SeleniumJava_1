package Page_Repository;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CreateServiceRequestParkingSlot_Page 
{
	public WebDriver driver;
	
	public CreateServiceRequestParkingSlot_Page(WebDriver webDriver)
	{
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this);
	}
	
	/////////// LOGIN STARTED /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	@FindBy(xpath = "//iframe[@id='gsft_main']") private WebElement eleLoginiFrame;
	public void switchiFrame()
	{
		driver.switchTo().frame(eleLoginiFrame);
	}
	
	@FindBy(xpath = "//input[@id='user_name']") private WebElement eleUserName;
	public void setUserName(String strUNm)
	{
		eleUserName.sendKeys(strUNm);
	}
	
	@FindBy(xpath = "//input[@id='user_password']") private WebElement elePassword;
	public void setPassword(String strPwd)
	{
		elePassword.sendKeys(strPwd);
	}
	
	@FindBy(xpath = "//button[@id='sysverb_login']") private WebElement eleLoginBtn;
	public void clickLoginBtn()
	{
		eleLoginBtn.click();
	}
	
	@FindBy(xpath = "//input[@id='email_factor']") private WebElement eleCheckBoxGetvalidationCode;
	public void checkCheckBox()
	{
		//eleCheckBoxGetvalidationCode.click();
		((JavascriptExecutor)driver).executeScript("arguments[0].click();", eleCheckBoxGetvalidationCode);
	}
	
	@FindBy(xpath = "//button[@id='continue']") private WebElement eleContinueBtn;
	public void clickContinueBtn()
	{
		eleContinueBtn.click();
	}
	
	/*@FindBy(xpath = "//input[@id='tbUserName']") private WebElement eleOutlookUserName;
	public void setOutlookUserName(String strOLUNm)
	{
		eleOutlookUserName.sendKeys(strOLUNm);
	}
	
	@FindBy(xpath = "//input[@id='bOK']") private WebElement eleOutlookOkBtn;
	public void clickOutlookOkButton()
	{
		eleOutlookOkBtn.click();
	}*/
	
	@FindBy(xpath = "//input[@name='loginfmt']") private WebElement eleOutlookEmail;
	public void setOutlookEmail(String strOutlookEmail)
	{
		eleOutlookEmail.sendKeys(strOutlookEmail);
	}
	
	@FindBy(xpath = "//input[@id='idSIButton9']") private WebElement eleOutlookNextBtn;
	public void clickOutlookNextBtn()
	{
		eleOutlookNextBtn.click();
	}
	
	@FindBy(xpath = "//input[@name='passwd']") private WebElement eleOutlookPwd;
	public void setOutlookPwd(String strPwd)
	{
		eleOutlookPwd.sendKeys(strPwd);
	}
	
	@FindBy(xpath = "//input[@data-report-event='Signin_Submit']") private WebElement eleSignInBtn;
	public void clickOutlookSignInBtn()
	{
		eleSignInBtn.click();
	}
	
	@FindBy(xpath = "//span[text()='Folders']/following::div[@draggable='true']/div[contains(@title,'Drafts')]") private WebElement eleDraftFolder;
	public void clickOnDraftFolder()
	{
		eleDraftFolder.click();
	}
	
	@FindBy(xpath = "//span[text()='Folders']/following::div[@draggable='true']/div[contains(@title,'Inbox')]") private WebElement eleOutlookInbox;
	public void clickOutlookInbox()
	{
		eleOutlookInbox.click();
	}
	
	@FindBy(xpath = "//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)']") private WebElement eleOutlookMultiFactor;
	public void clickOutlookMultifactor()
	{
		eleOutlookMultiFactor.click();
	}
	
	@FindBy(xpath = "//div[@id='UniqueMessageBody_1']//div/div/div/pre[1]") private WebElement eleOutlookmailBody;
	public String getOutlookMailBodyText()
	{
		String str = eleOutlookmailBody.getText();
		return str;
	}
	
	@FindBy(xpath = "//input[@id='txtResponse_email']") private WebElement eleTxt6DigitVerficationCode;
	public void set6DigitVerficationCode(String str6DiditCode)
	{
		eleTxt6DigitVerficationCode.sendKeys(str6DiditCode);
	}
	
	@FindBy(xpath = "(//button[@id='sysverb_validate_mfa_code'])[2]") private WebElement eleVerifyBtn;
	public void clickVerifyBtn()
	{
		eleVerifyBtn.click();
	}
	
	/////////////////TICKET CREATION started //////////////////////////////////////////////////////////////////////////////////////////
	
	@FindBy(xpath = "//div[contains(text(),'CAMPUS')]") private WebElement eleCampusServicesDiv;
	public void clickCampusServices()
	{
		//eleCampusServicesDiv.click();
		((JavascriptExecutor)driver).executeScript("arguments[0].click();", eleCampusServicesDiv);
	}
	
	@FindBy(xpath = "//div[contains(text(),'Parking Lot')]") private WebElement eleParkingLotLevel_1;
	public void clickParkingLotLevel_1()
	{
		eleParkingLotLevel_1.click();
	}
	
	@FindBy(xpath = "//a[contains(text(),'Parking-lot')]") private WebElement eleParkingLotLevel_2;
	public void hoverParkingLotLevel_2()
	{
		Actions actns = new Actions(driver);
		actns.moveToElement(eleParkingLotLevel_2).build().perform();
	}
	
	@FindBy(xpath = "(//img[@ng-src='aop_star.svg'])[2]") private WebElement elePinkStarIcon;
	public String getPinkStarAttribute()
	{
		return elePinkStarIcon.getAttribute("ng-src");
	}
	
	@FindBy(xpath = "//a[contains(text(),'Parking-lot')]/following::img[@data-original-title='Add to favorites'][1]") private WebElement eleAddToFavIcon;
	public void clickStarAddToFavIcon()
	{
		eleAddToFavIcon.click();
	}
	
	@FindBy(xpath = "//div[contains(text(),'QUICK LINKS')]") private WebElement eleQuickLinks;
	public void clickQuickLinks()
	{
		eleQuickLinks.click();
	}
	
	@FindBy(xpath = "//a[text()='Parking-lot']") private WebElement eleMegaMenuParkingLot;
	public void clickMegaMenuParkingLot()
	{
		eleMegaMenuParkingLot.click();
	}
	
	@FindBy(xpath = "//div[contains(text(),'SERVICE REQUEST')]") private WebElement elePageTitleServiceReq;
	public String verifyServiceRequestPage()
	{
		return elePageTitleServiceReq.getText();
	}
	
	@FindBy(xpath = "//h1[text()='Parking-lot']") private WebElement eleTktNameParkingLot;
	public String verifyTicketNameParkingLot()
	{
		return eleTktNameParkingLot.getText();
	}
	
	@FindBy(xpath = "//*[@id='Symbols']") private WebElement eleQuickLinksIcon;
	public void clickQuickLinksIcon()
	{
		//eleQuickLinksIcon.click();
		((JavascriptExecutor)driver).executeScript("arguments[0].click();", eleQuickLinksIcon);
	}
	
	@FindBy(xpath = "(//a[text()='Parking-lot'])[1]") private WebElement eleParkingLot;
	@FindBy(xpath = "(//a[text()='Parking-lot']/following::img[@popover-title='Delete this item?'])[1]") private WebElement eleDeleteIcon;
	public void hoverOnParkingLot()
	{
		Actions actns = new Actions(driver);
		actns.moveToElement(eleParkingLot).click(eleDeleteIcon).build().perform();
	}
	
	@FindBy(xpath = "//button[text()='Ok']") private WebElement eleOkBtn;
	public void clickOkBtn()
	{
		eleOkBtn.click();
	}
}
