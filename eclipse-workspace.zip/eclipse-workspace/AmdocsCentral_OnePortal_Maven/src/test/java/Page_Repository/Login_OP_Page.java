package Page_Repository;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login_OP_Page 
{
public WebDriver driver;
	
	public Login_OP_Page(WebDriver webDriver)
	{
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this);
	}
	
	@FindBy(xpath = "//iframe[@id='gsft_main']") private WebElement eleLoginiFrame;
	public void switchiFrame()
	{
		driver.switchTo().frame(eleLoginiFrame);
	}
	
	@FindBy(xpath = "//input[@id='user_name']") private WebElement eleUserName;
	public void setUserName(String strUNm)
	{
		eleUserName.sendKeys(strUNm);
	}
	
	@FindBy(xpath = "//input[@id='user_password']") private WebElement elePassword;
	public void setPassword(String strPwd)
	{
		elePassword.sendKeys(strPwd);
	}
	
	@FindBy(xpath = "//button[@id='sysverb_login']") private WebElement eleLoginBtn;
	public void clickLoginBtn()
	{
		eleLoginBtn.click();
	}
	
	@FindBy(xpath = "//input[@id='email_factor']") private WebElement eleCheckBoxGetvalidationCode;
	public void checkCheckBox()
	{
		//eleCheckBoxGetvalidationCode.click();
		((JavascriptExecutor)driver).executeScript("arguments[0].click();", eleCheckBoxGetvalidationCode);
	}
	
	@FindBy(xpath = "//button[@id='continue']") private WebElement eleContinueBtn;
	public void clickContinueBtn()
	{
		eleContinueBtn.click();
	}
	
	/*@FindBy(xpath = "//input[@id='tbUserName']") private WebElement eleOutlookUserName;
	public void setOutlookUserName(String strOLUNm)
	{
		eleOutlookUserName.sendKeys(strOLUNm);
	}
	
	@FindBy(xpath = "//input[@id='bOK']") private WebElement eleOutlookOkBtn;
	public void clickOutlookOkButton()
	{
		eleOutlookOkBtn.click();
	}*/
	
	@FindBy(xpath = "//input[@name='loginfmt']") private WebElement eleOutlookEmail;
	public void setOutlookEmail(String strOutlookEmail)
	{
		eleOutlookEmail.sendKeys(strOutlookEmail);
	}
	
	@FindBy(xpath = "//input[@id='idSIButton9']") private WebElement eleOutlookNextBtn;
	public void clickOutlookNextBtn()
	{
		eleOutlookNextBtn.click();
	}
	
	@FindBy(xpath = "//input[@name='passwd']") private WebElement eleOutlookPwd;
	public void setOutlookPwd(String strPwd)
	{
		eleOutlookPwd.sendKeys(strPwd);
	}
	
	@FindBy(xpath = "//input[@data-report-event='Signin_Submit']") private WebElement eleSignInBtn;
	public void clickOutlookSignInBtn()
	{
		eleSignInBtn.click();
	}
	
	@FindBy(xpath = "//span[text()='Folders']/following::div[@draggable='true']/div[contains(@title,'Drafts')]") private WebElement eleDraftFolder;
	public void clickOnDraftFolder()
	{
		eleDraftFolder.click();
	}
	
	@FindBy(xpath = "//span[text()='Folders']/following::div[@draggable='true']/div[contains(@title,'Inbox')]") private WebElement eleOutlookInbox;
	public void clickOutlookInbox()
	{
		eleOutlookInbox.click();
	}
	
	@FindBy(xpath = "//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)']") private WebElement eleOutlookMultiFactor;
	public void clickOutlookMultifactor()
	{
		eleOutlookMultiFactor.click();
	}
	
	@FindBy(xpath = "//div[@id='UniqueMessageBody_1']//div/div/div/pre[1]") private WebElement eleOutlookmailBody;
	public String getOutlookMailBodyText()
	{
		String str = eleOutlookmailBody.getText();
		return str;
	}
	
	@FindBy(xpath = "//input[@id='txtResponse_email']") private WebElement eleTxt6DigitVerficationCode;
	public void set6DigitVerficationCode(String str6DiditCode)
	{
		eleTxt6DigitVerficationCode.sendKeys(str6DiditCode);
	}
	
	@FindBy(xpath = "(//button[@id='sysverb_validate_mfa_code'])[2]") private WebElement eleVerifyBtn;
	public void clickVerifyBtn()
	{
		eleVerifyBtn.click();
	}
	
	
	public void closeWindowTab()
	{
		
	}
}
