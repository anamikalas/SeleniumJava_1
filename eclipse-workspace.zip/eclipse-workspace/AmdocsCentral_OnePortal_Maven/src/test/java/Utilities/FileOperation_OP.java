package Utilities;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class FileOperation_OP 
{
	// read property file
	public String readPropertyFile(String strKey) throws IOException 
	{
		FileInputStream fis = new FileInputStream(".\\src\\test\\resources\\DataFolder_OP\\PropertyFile_OP.properties");
		Properties prop = new Properties();
		prop.load(fis);
		String strData = prop.getProperty(strKey);
		return strData;
	}

	// write data
	public FileOutputStream writeProperties(String strKey, String strVal) throws Exception 
	{
		try 
		{
			FileOutputStream fos = new FileOutputStream(
					".\\src\\test\\resources\\FolderProperties\\WriteProperties.properties");

			Properties prop = new Properties();
			prop.setProperty(strKey, strVal);
			prop.store(fos, "My Data");
			fos.close();
			return fos;
		} catch (Exception ex) 
		{
			// ex.printStackTrace();
			throw ex;
		}
	}
}
