package Utilities;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReport_OP 
{
	public ExtentSparkReporter htmlReport;
	public ExtentReports extntReport;
	public ExtentTest extntTest;
	
	//@BeforeTest
	//@BeforeClass
	public void startReport()
	{
		htmlReport = new ExtentSparkReporter(".\\src\\test\\resources\\Test_Case_Execution_Report\\TestCaseExecutionReport.html");
		//htmlReport = new ExtentSparkReporter(System.getProperty("user.dir") + "\\Test_Case_Execution_Report\\TestCaseExecutionReport.html");
		extntReport = new ExtentReports();
		extntReport.attachReporter(htmlReport);
		
		extntReport.setSystemInfo("Machine", "My PC");
		extntReport.setSystemInfo("OS", "Windows 11");
		extntReport.setSystemInfo("User", "Anamika");
		extntReport.setSystemInfo("Browser", "Chrome");
		
		htmlReport.config().setDocumentTitle("Document Title-My Doc");
		htmlReport.config().setReportName("Report Name-My Report");
		htmlReport.config().setTheme(Theme.STANDARD);
		htmlReport.config().setTimeStampFormat("EEEE, MMMM dd, yyyy 'at' hh:mm a '('zzz')'");
	}
	
	//@AfterMethod
	public void getTestResult(ITestResult testRes)
	{
		if(testRes.getStatus() == ITestResult.FAILURE)
		{
			extntTest.log(Status.FAIL, MarkupHelper.createLabel(testRes.getName() + "Fail", ExtentColor.RED));
			extntTest.fail(testRes.getThrowable()); //get details error
		}
		else if(testRes.getStatus() == ITestResult.SUCCESS)
		{
			extntTest.log(Status.PASS, MarkupHelper.createLabel(testRes.getName() + "Pass", ExtentColor.GREEN));
			extntTest.pass(testRes.getThrowable());
		}
		else if(testRes.getStatus() == ITestResult.SKIP)
		{
			extntTest.log(Status.SKIP, MarkupHelper.createLabel(testRes.getName() + "Skipped", ExtentColor.YELLOW));
			extntTest.skip(testRes.getThrowable());
		}
		
	}
	
	@AfterMethod
	public void tearDown()
	{
		extntReport.flush();
	}
}
