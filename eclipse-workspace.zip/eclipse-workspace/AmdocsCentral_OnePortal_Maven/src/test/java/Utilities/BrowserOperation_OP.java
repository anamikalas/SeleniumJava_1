package Utilities;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class BrowserOperation_OP 
{
	FileOperation_OP objF = new FileOperation_OP();
	
	public WebDriver launchAppBE_OP() throws Exception
	{
		FileOperation_OP objF = new FileOperation_OP();
		
		try
		{
			ChromeOptions options = new ChromeOptions();
			//options.addArguments("disable-notifications"); //disable normal popup
			//options.addArguments("--disable-geolocations"); //disable location popup
			//options.addArguments("--disable-media-stream"); //disable camera microphone popup
			
			Map<String, Integer> contentSettings = new HashMap<>();
			Map<String, Object> profile = new HashMap<>();
			Map<String, Object> pref = new HashMap<String, Object>();
			
			contentSettings.put("notifications", 2); // permission 0 - Cancel, 1 - Allow, 2 - Block
			profile.put("managed_default_content_settings", contentSettings);
			pref.put("profile", profile);
			options.setExperimentalOption("prefs", pref);
			
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
			
			driver.get(objF.readPropertyFile("AC_Url_OP_BE"));
			return driver;
		}
		catch(Exception ex)
		{
			throw ex;
		}
	}
}
