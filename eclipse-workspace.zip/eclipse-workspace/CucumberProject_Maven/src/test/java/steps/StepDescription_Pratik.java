package steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import dev.failsafe.internal.util.Assert;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.*;

public class StepDescription_Pratik 
{
	WebDriver driver = new ChromeDriver();

	@Given("Launch application") //pre-requisites
	public void launch_application() 
	{		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://www.saucedemo.com");
	}
	
	@When("user enters valid {string} and {string}") //steps to perform by using When //passing param for userId and pwd
	public void user_enters_valid_user_name_and_password(String strUserNm, String strPwd) 
	{
		driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys(strUserNm);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(strPwd);
		driver.findElement(By.xpath("//input[@id='login-button']")).click();
	}
	@Then("login should be successful") //verification
	public void login_should_be_successful() 
	{
		String strVal = driver.findElement(By.xpath("//span[text()='Products']")).getText();
		if(strVal.equals("Products"))
			System.out.println("Login successfully completed...");
		else
			System.out.println("Login failed...");
		//driver.quit();
		//return strVal;
	}



}
