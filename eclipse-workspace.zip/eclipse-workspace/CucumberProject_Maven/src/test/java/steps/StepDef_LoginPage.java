package steps;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import io.cucumber.java.en.*; //library for Given(), When() and Then()
import object_repository.LoginPage;


public class StepDef_LoginPage 
{
	//public WebDriver driver;
	
	WebDriver driver = new ChromeDriver();
	
	
	LoginPage objL = new LoginPage(driver);
		
	@Given("user launch browser {string}")
	public void user_launch_browser(String strUrl) 
	{
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
	    driver.get(strUrl);
	}

	@When("user name as {string}")
	public void user_name_as(String strUserNm) 
	{
	    objL.setUserName(strUserNm);
	}

	@When("user  password as {string}")
	public void user_password_as(String strUserPwd) 
	{
	    objL.setPassword(strUserPwd);
	}

	@When("click login button")
	public void click_login_button() 
	{
	    objL.clickLoginBtn();
	}

	@Then("login should be successful where page title {string}")
	public void login_should_be_successful_where_page_title(String strPageTitle) 
	{
	    Assert.assertEquals("PageTitle", strPageTitle);
	}

	@Then("close browser")
	public void close_browser() 
	{
	    
	}
}
