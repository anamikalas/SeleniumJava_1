package steps;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import object_repository.LoginByDataTable_Page;


public class LoginByDataTable_StepDef
{
	//public WebDriver driver;
	WebDriver driver = new ChromeDriver();	
	
	LoginByDataTable_Page objL = new LoginByDataTable_Page(driver);
	List<List<String>> dtLst;
	
	@Given("user launch the url using DataTable")
	public void user_launch_the_url_using_data_table(DataTable dataTable) 
	{
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		
		dtLst = dataTable.cells();
		driver.get(dtLst.get(0).get(0));
	}

	@When("user enter credential using DataTable")
	public void user_enter_credential_using_data_table(DataTable dataTable) 
	{
		dtLst = dataTable.cells();
		objL.setUserName(dtLst.get(0).get(0));
		objL.setPassword(dtLst.get(0).get(1));
	}

	@When("user click on login button")
	public void user_click_on_login_button() 
	{
		objL.clickLoginBtn();
	}

	@Then("login should be successful with page title")
	public void login_should_be_successful_with_page_title() 
	{
		System.out.println("Login successful...");
	}

}
