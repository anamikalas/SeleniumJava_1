package object_repository;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class LoginPage 
{
	public WebDriver driver;
	
	public LoginPage(WebDriver webDriver)
	{
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this);
	}
	
	@FindBy(xpath = "//iframe[@id='gsft_main']") private WebElement eleiFrameLoginPage;
	public void switchiFrameLoginPage()
	{
		driver.switchTo().frame(eleiFrameLoginPage);
	}
	
	@FindBy(xpath = "//input[@id='user-name']") private WebElement eleUserNmTextBox;
	public void setUserName(String strUNm)
	{
		eleUserNmTextBox.sendKeys(strUNm);
	}
	
	@FindBy(xpath = "//input[@id='password']") private WebElement elePwdTextBox;
	public void setPassword(String strPwd)
	{
		elePwdTextBox.sendKeys(strPwd);
	}
	
	@FindBy(xpath = "//input[@id='login-button']") private WebElement eleLoginBtn;
	public void clickLoginBtn()
	{
		eleLoginBtn.click();
	}
}
