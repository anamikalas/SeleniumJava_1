package runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

//import org.junit.runner

@RunWith(Cucumber.class) //telling JUnit that we have to run some cucumber file
@CucumberOptions(features = "FeaturesFile", glue = "steps") //steps is package name, glue is an keyword
public class TestRunner_Pratik 
{
	
}
