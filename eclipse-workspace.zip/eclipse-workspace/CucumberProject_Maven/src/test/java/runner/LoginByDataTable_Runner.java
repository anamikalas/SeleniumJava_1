package runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features={".\\FeatureFolder\\DataTableFeatureFile.feature"},
				 glue = {"steps"},
				 dryRun = false,
				 monochrome = true,
				 plugin = {"pretty", "junit:ExecutionReport/LoginByDataTable_StepDef.java_xml.xml", "json:ExecutionReport/LoginByDataTable_StepDef.java_json.json", "html:ExecutionReport/LoginByDataTable_StepDef.java_html.html"} //generate report
				)

//plugin = {"pretty", "html:ExecutionReport/LoginPageReport_html.html"} //generate html report
//plugin = {"pretty", "json:ExecutionReport/LoginPageReport_json.json"} //generate json report
//plugin = {"pretty", "junit:ExecutionReport/LoginPageReport_xml.xml"} //generate xml report

//this class will be empty
public class LoginByDataTable_Runner 
{

}
