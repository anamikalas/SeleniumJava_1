package runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {".\\FeatureFolder\\LoginFeature.feature"},
		glue = {"steps"},
		dryRun = false,
		monochrome = true,
		plugin = {"pretty", "junit:ExecutionReport/LoginPageReport_xml.xml", "json:ExecutionReport/LoginPageReport_json.json", "html:ExecutionReport/LoginPageReport_html.html"} //generate xml report
		)

//plugin = {"pretty", "html:ExecutionReport/LoginPageReport_html.html"} //generate html report
//plugin = {"pretty", "json:ExecutionReport/LoginPageReport_json.json"} //generate json report
//plugin = {"pretty", "junit:ExecutionReport/LoginPageReport_xml.xml"} //generate xml report

//this class will be empty
public class Run_LoginPage 
{
	
}
