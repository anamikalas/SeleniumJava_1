package demo;

// Rule:
// 1. We cannot create an object of abstract class
// 2. Can we have constructor in abstract class or not - Yes
// 3. Can we have only abstract method in abstract class - Yes(it is better to use interface)
// 4. Can we have all methods defined in abstract class, no abstract method - Yes (it is better to use normal class)
abstract public class Vehicle {
	
	private Vehicle()
	{
		System.out.println("Constructor vehicle");
	}
	
	abstract public void Accelerate(); // Implementation not known
	
	abstract public void Brake(); // 
	
	public void Engine() // Implementation  known
	{
		System.out.println("Vehicle engine");
	}

}
