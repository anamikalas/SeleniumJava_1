package demo;

public class Car extends Vehicle
{
	
	public void Accelerate()
	{
		System.out.println("Car accelerate");
	}
	
	public void Brake()
	{
		System.out.println("Car brake");
	}

}
