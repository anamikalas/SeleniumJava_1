package common_api;

import static io.restassured.RestAssured.*;

import java.util.HashMap;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import utilities.FileOperation;

public class APICommonMethods 
{
	FileOperation objF = new FileOperation();
	
	public String generateAccessToken() throws Exception
	{
		try
		{
			HashMap<String, String> hsMapBody = new HashMap<String, String>();
			hsMapBody.put("username", "kminchelle");
			hsMapBody.put("password", "0lelplR");
			hsMapBody.put("expiresInMins", "30");
			
			String strToken = 
					given()
					.contentType(ContentType.JSON)
					.with().body(hsMapBody)
					.when()
					.post(objF.readPropertyFile("Login_And_Get_Token_URI"))
					.then()
					.statusCode(200)
					.extract().response().jsonPath().getString("token");
			System.out.println("Token generated...");
			return strToken;
		}
		catch(Exception ex)
		{
			throw ex;
		}
		//return null;
	}
}
