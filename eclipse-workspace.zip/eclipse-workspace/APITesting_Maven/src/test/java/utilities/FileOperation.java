package utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class FileOperation 
{
	public String readPropertyFile(String strKey) throws Exception
	{
		try
		{
		FileInputStream fis = new FileInputStream(".\\src\\test\\resources\\PropertiesFileFolder\\APIPropertiesFile.properties");
		Properties prop = new Properties();
		prop.load(fis);
		String strVal = prop.getProperty(strKey);
		return strVal;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			throw ex;
		}
	}
	
	
	public FileInputStream readJSONFile() throws FileNotFoundException
	{
		FileInputStream fis = new FileInputStream(".\\src\\test\\resources\\JSONFileFolder\\AddToCart.json");
		return fis;
	}
}
