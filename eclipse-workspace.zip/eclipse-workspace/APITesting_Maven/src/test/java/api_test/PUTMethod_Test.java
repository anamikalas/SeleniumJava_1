package api_test;

import java.io.FileInputStream;

import org.testng.annotations.Test;

import utilities.FileOperation;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

public class PUTMethod_Test 
{
	FileOperation objF = new FileOperation();
	
	@Test(enabled = true, priority = 1)
	public void testPUTMethod() //PUT() - update cart
	{
		try
		{
			FileInputStream fis = objF.readJSONFile();
			
			given()
			.contentType(ContentType.JSON)
			.when()
			.put(objF.readPropertyFile("Update_Cart_URI"))
			.then()
			.statusCode(200)
			.extract().response().prettyPrint();
			System.out.println("PUT().....");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
