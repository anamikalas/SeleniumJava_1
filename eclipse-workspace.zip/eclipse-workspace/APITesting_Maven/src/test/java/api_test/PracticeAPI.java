package api_test;

import java.util.List;
import io.restassured.*;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

public class PracticeAPI 
{
	public void testMethod()
	{
		try
		{
			List<Object> obj = given()
					.contentType(ContentType.JSON)
					.with().body("")
					.when()
					.post("")
					.then()
					.statusCode(200)
					.extract().response().jsonPath().getList("products.id");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
