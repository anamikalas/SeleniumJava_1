package api_test;

import utilities.FileOperation;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.*;
import org.testng.annotations.*;

public class GETMethod_Test 
{
	FileOperation objFO = new FileOperation();
	
	@Test(enabled = true, priority = 1)
	public void testGETMethodPathParam()
	{
		try
		{
		FileOperation objF = new FileOperation();
		String strURI = objF.readPropertyFile("Products_URI_PathParam");
		
		given()
		.contentType(ContentType.JSON)
		.pathParam("id","3")
		.when()
		.get(strURI)
		.then()
		.statusCode(200)
		.extract().response().prettyPrint();
		System.out.println("testGETMethodPathParam.....");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	@Test(enabled = true, priority = 1)
	public void testGETMethodQueryParam() 
	{
		try
		{
		given()
		.contentType(ContentType.JSON)
		.queryParam("id", "1")
		.queryParam("limit", "2") //will show 3 records only, These parameters are used to customize the behavior of the API request, such as filtering, sorting, or paginating results.
		.when()
		.get(objFO.readPropertyFile("Products_URI_QueryParam"))
		.then()
		.statusCode(200)
		.extract().response().prettyPrint();
		System.out.println("testGETMethodQueryParam.......");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
