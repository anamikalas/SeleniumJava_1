package api_test;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.http.ContentType;
import utilities.FileOperation;
import static io.restassured.RestAssured.*;

public class POSTMethod_Test 
{
	FileOperation objF = new FileOperation();	
	
	@Test(enabled = false, priority = 1)
	public void testPOSTMethod_WithUnknowndataType()
	{
		try
		{			
			FileInputStream fis = objF.readJSONFile();
			
			//when data type is not known then need to write Object
			List<Object> lstAllId = given()
					.contentType(ContentType.JSON)
					.with().body(fis)
					.when()
					.post(objF.readPropertyFile("Add_Cart_URI"))
					.then()
					.statusCode(200)
					.extract().response().jsonPath().getList("products.id");
					Assert.assertTrue(lstAllId.contains(1));
					System.out.println("Id is: " + lstAllId.get(1));
					
					for(Object objId : lstAllId)
					{
						System.out.println("All Id (inside for loop): " + objId);
					}
					
					System.out.println("POST() 1....");
					
		}
		catch(Exception ex)
		{
			
		}
	}

	@Test(enabled = false, priority = 1)
	public void testPOSTMethod_WithKnownDataType()
	{
		try
		{
			FileInputStream fis = objF.readJSONFile();
			
			//when data type in known
			List<Integer> lstId = given()
					.contentType(ContentType.JSON)
					.with().body(fis)
					.when()
					.post(objF.readPropertyFile("Add_Cart_URI"))
					.then()
					.statusCode(200)
					.extract().response().jsonPath().getList("products.id");
					Assert.assertTrue(lstId.contains(1));
					System.out.println("Id of index 1: " + lstId.get(1)); //getting Id of index 1
					
					for(Integer intId : lstId)
					{
						System.out.println("All Id (inside for loop): " + lstId); //print all Id's
					}
					
					System.out.println("POST() 2....");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	@Test(enabled = true, priority = 1)
	public void testPOSTMethod_WithHashMap()
	{
		/*try
		{
			FileInputStream fis = objF.readJSONFile();
			
			//POST() with HashMap
			HashMap<String, String> hashMap = given()
					.contentType(ContentType.JSON)
					.with().body(fis)
					.when()
					.post(objF.readPropertyFile("Add_Cart_URI"))
					.then()
					.statusCode(200)
					//.extract().response().jsonPath().get("products.id");
			
			for(Map.Entry<String, String> strMap : hashMap.entrySet())
			{
				System.out.println("Key: " + strMap.getKey() + "Value: " + strMap.getValue());
			}
			
			System.out.println("POST() 3....");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}*/
	}
}
