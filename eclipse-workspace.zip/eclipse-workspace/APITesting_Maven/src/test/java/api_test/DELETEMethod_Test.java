package api_test;
import static io.restassured.RestAssured.*;
import io.restassured.http.ContentType;
import utilities.FileOperation;
import org.testng.annotations.*;

public class DELETEMethod_Test 
{
	FileOperation objF = new FileOperation();
	
	@Test(enabled = true, priority = 1)
	public void testDELETEMethod()
	{

		try
		{
			given()
			.contentType(ContentType.JSON)
			.when()
			.delete(objF.readPropertyFile("Update_Cart_URI"))
			.then()
			.statusCode(200)
			.extract().response().prettyPrint();
			
			System.out.println("DELETE().....");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
