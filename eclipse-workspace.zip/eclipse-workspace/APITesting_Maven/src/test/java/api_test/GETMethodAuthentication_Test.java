package api_test;

import common_api.APICommonMethods;
import static io.restassured.RestAssured.*;
import io.restassured.http.ContentType;
import utilities.FileOperation;
import org.testng.annotations.*;

public class GETMethodAuthentication_Test 
{
	APICommonMethods objA = new APICommonMethods();
	FileOperation objF = new FileOperation();
	
	@Test(enabled = true, priority = 1)
	public void testAuthentication_GETMethod()
	{
		try
		{
			String strToken = objA.generateAccessToken();
			
			given()
			.contentType(ContentType.JSON)
			.with().header("Authorization", "Bearer " + strToken)
			.when()
			.get(objF.readPropertyFile("Get_Auth_User_URI"))
			.then()
			.statusCode(200)
			.extract().response().prettyPrint();
			System.out.println("Authentication done...");
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
	}
}
