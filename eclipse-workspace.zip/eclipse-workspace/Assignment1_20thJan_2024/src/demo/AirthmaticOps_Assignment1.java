package demo;

public class AirthmaticOps_Assignment1 
{
 public int add1(int a, int b)
 {
	 int c=a+b;
	 return c;
 }
 public int sub1(int a,int b)
 {
	 int c=b-a;
	 return c;
 }
}
