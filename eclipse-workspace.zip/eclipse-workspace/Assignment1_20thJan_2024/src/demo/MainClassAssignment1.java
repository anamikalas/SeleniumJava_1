package demo;

public class MainClassAssignment1 {
	public static void main(String[] args) 
	{
		AirthmaticOps_Assignment1 objAO=new AirthmaticOps_Assignment1();
		System.out.println(objAO.add1(5, 7));
		System.out.println(objAO.sub1(17, 0));
	}
}
