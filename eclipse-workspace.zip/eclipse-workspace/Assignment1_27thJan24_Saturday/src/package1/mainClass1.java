package package1;

import package2.classArrayAndLoop1;

public class mainClass1 
{
	public static void main(String[] args)
	{
		classArrayAndLoop1 objAL = new classArrayAndLoop1();
		//objAL.printNumbersFrom1To100();
		//int num1 = 100;
		//objAL.printNumbersFrom1To100_1(num1);
		//int num2 = 10, num3 = 100;
		//objAL.printNumbersFrom10To100_1(num2, num3);
		//int num4 = 100, num5 = 50;
		//objAL.print100To50_1(num5, num4);
		//int num6 = -1, num7 = -50;
		//objAL.printNumberFromMynus1ToMynus50_1(num6, num7);
		objAL.findArrayWhoseLengthIsMax_1();
	}
}
