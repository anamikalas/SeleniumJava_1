package package2;

public class classArrayAndLoop1 
{
	public void printNumbersFrom1To100_1(int num1) //Print number 1 to 100
	{		
		for (int i=1; i<=num1; i++)
		{
			System.out.println(i);
		}
	}
	public void printNumbersFrom10To100_1(int num1, int num2) //Print number 10 to 100
	{
		for(int i=num1; i<=num2; i++)
			System.out.println(i);
	}
	public void print100To50_1(int num1, int num2) //Print number 100 to 50
	{
		for(int i=num2; i>=num1; i--)
			System.out.println(i);
	}
	public void printNumberFromMynus1ToMynus50_1(int num1, int num2)
	{
		//for(int i=num1; i>=num2; i++)
			//System.out.println(i);
		for(int i=-1; i>=-50; i--)
			System.out.println(i);
	}
	public void findArrayWhoseLengthIsMax_1() //Find the array whose length is max between 2 array
	{
		int arr1[] = new int[] {1,3,5,7,9};
		int arr2[] = new int[] {2,4,6,8,10,12,14,16};
		int arr1Len1 = arr1.length;
		int arr2Len2 = arr2.length;
		
		if(arr1Len1 > arr2Len2)
			System.out.println("Max length array is 1st array and length is:- " + arr1Len1);
		else
			System.out.println("Max length array is 2nd array and length is:-" +arr2Len2);
	}
}
