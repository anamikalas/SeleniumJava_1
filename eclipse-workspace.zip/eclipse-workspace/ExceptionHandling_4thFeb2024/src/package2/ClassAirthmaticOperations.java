package package2;

public class ClassAirthmaticOperations 
{
	public void devide()
	{
		try
		{
		System.out.println("Start...");
		
		String str = null;
		str.concat("abc"); //Execution of code will stop at this line
		
		System.out.println("Test line....."); //will not execute from this line since got 
		
		int a = 10;
		int b = a/0;
		
		System.out.println(b);
	
		}
		
		catch(NullPointerException ex1)
		{
			System.out.println("Specific exception...");
			System.out.println(ex1.getMessage());
		}
		catch(Exception ex2) //Once getting error at try block java will jump directly to the catch block
		{
			System.out.println("String is null so can't add to null string...");
			System.out.println(ex2.getMessage());
		}
		finally //If there is any finally block it always executes. Also finally block is optional.
		{
			System.out.println("Program end...");
		}
	}
	public void devide2()
	{
		try //When there is finally block try block will execute without catch block
		{
		String str = null;
		str.concat("abs");
		
		System.out.println(str);
		
		int a= 10;
		int b = 2;
		int c = a/b;
		
		System.out.println(c);
		}
		finally
		{
			System.out.println("Program end...");
		}
	}
	public void useThrow()
	{
		throw new NullPointerException();
	}
	public void useThrows() throws NullPointerException, ArithmeticException
	{
		
	}
	public void useFinallyBlock()
	{
		try
		{
		String str = null;
		str.concat("abc");
		System.out.println(str);
		}
		
		finally //Without try block finally will give error
		{
			System.err.println("hi");
		}
	}
}
