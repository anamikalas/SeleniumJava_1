package package_sp;

import package2.ClassAirthmaticOperations;

public class MainClass_TryCatchFinally_SP 
{
	public void tcfMethod()
	{
		try
		{
			int a = 100, b = 0;
			int c = a/b;
		}
		catch(ArithmeticException ex)
		{
			System.out.println(ex);
		}
		catch(NullPointerException ex)
		{
			throw ex;
		}
	}
}
