package package1;

import package2.ClassAirthmaticOperations;

public class MainClassExceptionHandling 
{
	public static void main(String[] args) throws Exception
	{
		ClassAirthmaticOperations objCAO = new ClassAirthmaticOperations();
		
		//objCAO.devide();
		//objCAO.devide2();
		objCAO.useThrow();
		objCAO.useThrows();
	}
}
