package utilities;

import java.io.FileInputStream;
import java.io.IOException;


import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelOperation 
{
	XSSFSheet sheetName;

	//find sheet name of excel file
	public void findSheetName() throws IOException
	{
		FileInputStream fis = new FileInputStream(".\\src\\test\\resources\\InputFolder\\InputFile.xlsx");

		XSSFWorkbook wb = new XSSFWorkbook(fis); //creating instance of excel file
		sheetName = wb.getSheet("Sheet1"); //getting sheet name which need to read
	}

	public int getTotalRows()
	{
		int totalRows = sheetName.getLastRowNum()-1; //getting total number of rows present in a sheet
		return totalRows;
	}

	public String readCell(int row, int column)
	{
		String strCellVal = sheetName.getRow(row).getCell(column).getStringCellValue(); //will read data based on input
		return strCellVal;
	}
}
