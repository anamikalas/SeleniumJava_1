import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import utilities.ExcelOperation;


public class LoginTest 
{
	//get data from excel file
	@DataProvider
	public Object[][] getData() throws IOException
	{
		ExcelOperation objEO = new ExcelOperation();
		objEO.findSheetName();
		int totalRows = objEO.getTotalRows();
		Object[][] data = new Object[totalRows][2]; //3 row, 2 column

		for(int i=0; i<totalRows; i++) 
		{
			data[i][0] = objEO.readCell(i, 0); //1st column data
			data[i][0] = objEO.readCell(i, 1); //2nd column data
		}

		return data;
	}

	@Test(dataProvider = "getData", enabled = true) //method name //this test case will execute 3 times, number of rows
	public void methodLoginTest(String strUserNm, String strPwd)
	{
		//System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		driver.get("https://www.saucedemo.com/");

		driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys(strUserNm);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(strPwd);
		driver.findElement(By.xpath("//input[@id='login-button']")).click();
	}


}
