package package1;

public class VehicleSir 
{
	
	int x;
	String str;
	
	// 1. Method name = Class name
	// 2. No return type
	public VehicleSir(int a,String abc) // Parameterized constructor
	{
		System.out.println("Constructor calling.....");
		x=a;
		str=abc;
		System.out.println(x);
		System.out.println(str);
	}
	
	public VehicleSir(int a)
	{
		
	}
	
	
	public static void StaticMethod()
	{
		
	}
	
	public void TestMethod(int a)
	{
		int x=70; 
		x=a;
		System.out.println(x);
		System.out.println(this.x);
	}

}
