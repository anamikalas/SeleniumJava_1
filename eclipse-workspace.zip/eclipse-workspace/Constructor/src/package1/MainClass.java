package package1;

public class MainClass 
{
	public static void main(String[] args)
	{
		//Vehicle objVeh1 = new Vehicle();
		//Vehicle.staticMethod();
		Vehicle objVeh2 = new Vehicle(10);
	}
}
