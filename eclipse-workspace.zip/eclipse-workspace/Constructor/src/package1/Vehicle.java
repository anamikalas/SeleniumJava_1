package package1;

public class Vehicle 
{
	int y;
	int z; //Global variable default value is 0
	String str; 
	
	public Vehicle() //1. Method name = class name 2. No return type //this is default constructor
	{
		System.out.println("Calling  Default constructor...");
	}
	public static void staticMethod()
	{
		System.out.println("Static method calling...");
	}
	public Vehicle(int a) //Parameterized constructor
	{
		System.out.println("Calling Parameterised constructor...");
		int x=0; //Local variable always need to initialize
		System.out.println(x);
		System.out.println(str);
		
		y=a;
		System.out.println(y);
	}
	public void testMethod()
	{
		int z = 70;
		System.out.println(z); //local variable where value is 70
		System.out.println(this.z); //By using this keyword we are acessing global variale
	}
	public void paramCons(int a, String str)
	{
		
	}
}
