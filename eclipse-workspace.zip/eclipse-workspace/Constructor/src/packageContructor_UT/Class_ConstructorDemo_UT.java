package packageContructor_UT;

class Class_ConstructorDemo_UT 
{
	
}

//when we are not creating any constructor (NO ARGUMENT CONSTRUCTOR or PARAMETERISED CONSTRUCTOR) in a class then javac automatically creates default constructor by itself
//when we are creating any constructor (NO ARGUMENT CONSTRUCTOR or PARAMETERISED CONSTRUCTOR) in a class then javac is not creating any default constructor
class Test
{
	int i;
	String s;
	
	//No Argument COnstructor created manually
	Test()
	{
		System.out.println("No Argument Constructor...");
	}
	
	Test(int a, String str)
	{
		System.out.println("Parameterised Constructor...");
	}
}


class Employee
{
	int empId;
	String empName;
	
	Employee()
	{
		
	}
	
	Employee(String strName, int empID)
	{
		this.empId = empID;
		this.empName = strName;
	}
}