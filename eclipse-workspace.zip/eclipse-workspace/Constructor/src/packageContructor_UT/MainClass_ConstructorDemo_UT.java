package packageContructor_UT;

public class MainClass_ConstructorDemo_UT 
{
	public static void main(String[] args)
	{
		Test objT1 = new Test(); //when we create object of a class constructors are called automatically by javac*/
		/*System.out.println(objT1.i + " " + objT1.s); //default constructor created by javac automatically so initialized with default value and printed default value of i and s*/
		Test objT2 = new Test(10, "Hello");
		
		Employee objE1 = new Employee(); //created 2 object (objE1, objE2) of class Employee
		Employee objE2 = new Employee(); //created 2 object (objE1, objE2) of class Employee		
		System.out.println(objE1.empId + " " + objE1.empName); //calling variable by object objE1 of the class Employee
		System.out.println(objE2.empId + " " + objE2.empName); //calling variable by object objE1 of the class Employee
		
		Employee objE3 = new Employee("Hello", 10);
		Employee objE4 = new Employee("world", 20);
		System.out.println(objE3.empId + " " + objE3.empName); //calling variable by object objE1 of the class Employee
		System.out.println(objE4.empId + " " + objE4.empName);
	}
}
