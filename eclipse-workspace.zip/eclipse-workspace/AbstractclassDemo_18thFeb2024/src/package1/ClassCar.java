package package1;

public class ClassCar extends ClassVehicle_AbstractClass
{
	public ClassCar()
	{
		System.out.println("Constractor Car class...");
	}
	public void methodAccelerate()
	{
		System.out.println("Accelerate method from Car class....");
	}
	public void methodBrake()
	{
		System.out.println("Brake method from Car class....");
	}
	public void methodEngine()
	{
		System.out.println();
	}
}
