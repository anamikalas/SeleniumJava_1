package package1;

public class MainClass_Abstractclass 
{
	public static void main(String[] args)
	{
		ClassCar objCC = new ClassCar();
		//ClassVehicle_AbstractClass objVAC = new ClassVehicle_AbstractClass(); //getting error bcoz constructor is private
	}
}
