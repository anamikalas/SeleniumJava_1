package package1;

//We can't an object of an Abstract class
abstract public class ClassVehicle_AbstractClass 
{
	public ClassVehicle_AbstractClass()
	{
		System.out.println("Constractor ClassVehicle_AbstractClass...");
	}
	abstract public void methodAccelerate();
	abstract public void methodBrake();
	public void methodEngine()
	{
		System.out.println("Engine method from Vehicle class...");
	}
}
