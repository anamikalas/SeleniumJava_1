package packageAbstraction_UT;

public class MainClassAbstractionDemo_UT 
{
	public static void main(String[] args)
	{
		/*we can't create object of abstract class
		vehicle objV = new vehicle(); */
		
		car objC = new car();
		objC.display();
		
		scooter objS = new scooter();
		objS.display();
	}
}
