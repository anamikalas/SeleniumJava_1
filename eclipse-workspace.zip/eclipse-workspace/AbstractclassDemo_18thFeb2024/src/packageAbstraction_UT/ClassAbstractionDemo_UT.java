package packageAbstraction_UT;

public class ClassAbstractionDemo_UT 
{

}

abstract class vehicle
{
	int a = 10;
	public int b;
	/*privare int c; //compile time error, does't support private*/
	protected int d;
	/*default int e; //will throw compile time error, does't support default access modifier*/
	static int f;
	final int g = 0; //final variable need to initialize always, else will throw compile time error.
	
	
	//Abstract method's are by default public access modifier
	//Abstract method allow public and protected access modifier only
	//when any method of a class is abstract then class also need to be abstract, else it will show compile time error.
	//without abstract keyword if we are declaring any method then method body should be there
	//if in a class there is any method without body then we need to use abstract keyword to the method, else it will throw compile time error
	abstract void display();
}

class car extends vehicle
{
	//when inheriting any abstract method than scope of the access modifier can be same or need to increase
	public void display() 
	{
		int a = 20;
		System.out.println("Car class..." + a);
	}
}

class scooter extends vehicle
{
	protected void display()
	{
		System.out.println("Scooter class...");
	}
}
