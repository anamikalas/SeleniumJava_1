package demo_package;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class HandleWindows 
{
	@Test
	public void testMultipleWindows()
	{
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); //Selenium 3
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS); //Selenium 4
		driver.get("https://way2automation.com/way2auto_jquery/index.php");
		
		//When tabName is "<a>" then we can use LinkText, text between <a> and </a>	
		driver.findElement(By.linkText("Signin")).click();
		
		//driver.findElement(By.xpath("(//input[@name='username'])[2]")).sendKeys("test");
		List<WebElement> lstUserName = driver.findElements(By.name("username"));
		for(WebElement webEle : lstUserName)
		{
			if(webEle.isDisplayed() == true)
				webEle.sendKeys("test");
		}
		
		List<WebElement> lstPwd = driver.findElements(By.name("password"));
		for(WebElement webEle : lstPwd)
		{
			if(webEle.isDisplayed() == true)
				webEle.sendKeys("test");
		}
		
		List<WebElement> lstEnterTW = driver.findElements(By.linkText("ENTER TO THE TESTING WEBSITE"));
		for(WebElement webEle : lstEnterTW)
		{
			if(webEle.isDisplayed() == true)
				webEle.click();
		}
		
		String strMainWIndowHandle = driver.getWindowHandle(); //Get main window title/handle
		System.out.println("Main window handle: " + strMainWIndowHandle);
		
		WebElement imgElement = driver.findElement(By.xpath("//img[@alt=\'frames-and-windows\']"));
		//ElementNotClickable - if we get this exception then we use alternative way of click JavaScriptExecutor
		JavascriptExecutor jse = (JavascriptExecutor)driver; //we are using driver bcoz everything is driven by driver in Selenium
		jse.executeScript("arguments[0].click();", imgElement); //Run JavaScript to element
		
		//How to highlight element by using JavScriptExecutor
		//How to sendkeys by using JavScriptExecutor
		//How to scroll up and down or to some element by using JavScriptExecutor
		
		Set<String> allWindowHandles = driver.getWindowHandles();
		for(String strHandle : allWindowHandles)
		{
			//System.out.println("All window handles: " + strHandle);
			if(!strMainWIndowHandle.equals(strHandle))
				driver.switchTo().window(strHandle);
		}
		
		String strNewWindowHandle = driver.getWindowHandle();
		System.out.println("New window handle: " + strNewWindowHandle); //Get new window title/handle
		
		//WebElement frameElement = driver.findElement(By.xpath("//iframe[@src='frames-windows/defult1.html']"));
		//driver.switchTo().frame(frameElement);
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@src='frames-windows/defult1.html']"))); //switching iFrame
		driver.findElement(By.linkText("New Browser Tab")).click();
		
		//driver.close(); //will close only current window
		//driver.quit(); //will close all the opened windows
	}
}
