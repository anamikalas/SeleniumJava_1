package utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.Test;

@Test
public class SelectQuery 
{
	//String strUrl = "DVCINH6087927/SQLEXPRESS"; //server name
	//String strUrl = "jdbc:sqlserver://DVCINH6087927/SQLEXPRESS:1433;databaseName=AdventureWorks2019;user=anamika;password=Amdocs@123";
	String strUrl = "jdbc:sqlserver://DVCINH6087927/SQLEXPRESS;databaseName=AdventureWorks2019;userName=anamika;password=Amdocs@123";
	//String strDBName = "AdventureWorks2019";
	//String strDBUrl = strUrl + "/" + strDBName;
	//String strUserNm = "anamika";
	//String strPwd = "Amdocs@123";
	//String connectionUrl = "jdbc:sqlserver://localhost;encrypt=true;database=AdventureWorks;integratedSecurity=true;";
	//String strDriver = "com.mysql.jdbc.Driver";
	
	public void getDataFromDB() throws SQLException
	{

		Connection con = DriverManager.getConnection(strUrl);
		Statement state = con.createStatement();
		ResultSet res = state.executeQuery("select * from Person.Address;");

	}
	
}
