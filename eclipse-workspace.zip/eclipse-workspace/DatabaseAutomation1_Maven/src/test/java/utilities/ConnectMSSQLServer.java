//package com.abc.automation.utilities;
package utilities;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.lang.Object;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;



//import com.abc.automation.commonmethods.BaseTest;
//import com.abc.automation.utilities.extentreports.ExtentTestManager;


/*public class ConnectMSSQLServer {
	private static final String SQL_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private static final Logger log = LoggerFactory.getLogger(ConnectMSSQLServer.class);
	private static String dbConnectionURL=BaseTest.pr.getStringProperty("sqlserver.connURL");
	private static String databaseName=BaseTest.pr.getStringProperty("sqlserver.databaseName");
	private static String dbUsername=BaseTest.pr.getStringProperty("sqlserver.username");
	private static String dbPassword=BaseTest.pr.getStringProperty("sqlserver.password");

	/* *
	 * Method will wait for package processing to given package process data
	 * */
	/*public void waitForPackageProcessForOrderID(String clientRefNumber,int packageProcess) throws Exception
	{
		int pkg_Processed = -1;
		try 
		{
			Class.forName(SQL_DRIVER);
			Connection conn = DriverManager.getConnection(dbConnectionURL, dbUsername, dbPassword);
			ExtentTestManager.extentLogger.info("Connected to db "+dbConnectionURL);
			Statement statement = conn.createStatement();
			int i=0;
			do
			{
				String queryString = "USE " + databaseName
				+ " select pkg_processed from search where client_ref_number='"+clientRefNumber+"'";
				ExtentTestManager.extentLogger.info("Running query - " + queryString);
				log.info("Running query - " + queryString);
				ResultSet rs = statement.executeQuery(queryString);

				while (rs.next())
				{
					log.info("Package ID for the searchId : " + rs.getString(1));
					pkg_Processed=rs.getInt("pkg_processed");

				}
				if(pkg_Processed==packageProcess)
					break;
				Thread.sleep(10000);
				ExtentTestManager.extentLogger.info("Package process is "+pkg_Processed+" which is less than "+packageProcess+" - <br>Retrying.... after wait for 5s");
				i++;
			}while(i<12);

			log.info("Retrieved Package Request ID from the search ID detail from database.");
			conn.close();
			if(i==12&&pkg_Processed<packageProcess)
			{
				ExtentTestManager.extentLogger.fail("Fail to move order to process " +packageProcess +"or more");
				Assert.fail("Fail to move order to process packageProcess"+packageProcess);
			}
			else
				ExtentTestManager.extentLogger.pass("Successfully Package process is"+ packageProcess);
			ExtentTestManager.extentLogger.info("Reterived data from db closing connection");
		} 
		catch (Exception e)
		{
			ExtentTestManager.extentLogger.info("Failed to reterive data from db");
			log.error("Unable to Package Request ID from the search ID detail from database.");
			log.error("Fail ", e);
			Assert.fail("Unable to Package Request ID from the search ID detail from database.", e);
		}
	}*/

	/* *
	 * Method will wait for Search status P for an order
	 * */
	/*public void waitForSearchStatusPForOrder(String clientRefNumber) throws Exception
	{
		String searchStatus = "";
		try 
		{
			Class.forName(SQL_DRIVER);
			Connection conn = DriverManager.getConnection(dbConnectionURL, dbUsername, dbPassword);
			ExtentTestManager.extentLogger.info("Connected to db "+dbConnectionURL);
			Statement statement = conn.createStatement();
			int i=0;
			do
			{
				String queryString = "USE " + databaseName
				+ " select search_status from search where client_ref_number='"+clientRefNumber+"'";
				ExtentTestManager.extentLogger.info("Running query - " + queryString);
				log.info("Running query - " + queryString);
				ResultSet rs = statement.executeQuery(queryString);

				while (rs.next())
				{
					log.info("Package ID for the searchId : " + rs.getString(1));
					searchStatus=rs.getString("search_status");

				}
				if(searchStatus.equals("P"))
					break;
				Thread.sleep(10000);
				ExtentTestManager.extentLogger.info("Search status is "+searchStatus+" which is not P - <br>Retrying.... after wait for 5s");
				i++;
			}while(i<12);

			log.info("Retrieved Package Request ID from the search ID detail from database.");
			conn.close();
			if(i==12&&!searchStatus.equals("P"))
			{
				ExtentTestManager.extentLogger.fail("Fail to move order to P");
				Assert.fail("Fail to move order to P");
			}
			else
				ExtentTestManager.extentLogger.pass("Successfully Package move to P status");
			ExtentTestManager.extentLogger.info("Reterived data from db closing connection");
		} 
		catch (Exception e)
		{
			ExtentTestManager.extentLogger.info("Failed to reterive data from db");
			log.error("Unable to Package Request ID from the search ID detail from database.");
			log.error("Fail ", e);
			Assert.fail("Unable to Package Request ID from the search ID detail from database.", e);
		}
	}*/

	/* *
	 * Method will run any select query 
	 * Returns: List of row with the HashMap of column and its value
	 * */
	/*public List<HashMap<String,String>> runSelectQuery(String query) throws Exception
	{
		List<HashMap<String,String>> result=new ArrayList<HashMap<String,String>>();
		String finalquery=query;
		if(query.contains("[")||query.contains("]"))
			finalquery=query.replace("[", "").replace("]", "");

		System.out.println(finalquery);
		try {

			Class.forName(SQL_DRIVER);
			Connection conn = DriverManager.getConnection(dbConnectionURL, dbUsername, dbPassword);

			ExtentTestManager.extentLogger.info("Connected to db "+dbConnectionURL);
			Statement statement = conn.createStatement();
			String queryString = "USE " + databaseName
					+ " "+finalquery;
			ExtentTestManager.extentLogger.info("Running query - " + queryString);

			ResultSet rs = statement.executeQuery(queryString);
			if(rs!=null)
			{

				while (rs.next()) 
				{
					HashMap<String,String> data=new HashMap<String,String>();
					ResultSetMetaData columns = rs.getMetaData();
					for(int i=1;i<=columns.getColumnCount();i++)
					{
						data.put(columns.getColumnName(i), rs.getString(columns.getColumnName(i)));
					}
					result.add(data);

				}
			}
			conn.close();
			ExtentTestManager.extentLogger.info("Reterived data from db closing connection");
		} catch (Exception e) {
			ExtentTestManager.extentLogger.info("Failed to reterive data from db");
			log.error("Unable to Package Request ID from the search ID detail from database.");
			log.error("Fail ", e);
			Assert.fail("Unable to Package Request ID from the search ID detail from database.", e);
		}
		return result;
	}




	public void wait_For_PackageProcess_move_to_40_and_above(String clientRefNumber) throws Exception
	{
		int pkg_Processed = -1;
		try 
		{
			Class.forName(SQL_DRIVER);
			Connection conn = DriverManager.getConnection(dbConnectionURL, dbUsername, dbPassword);
			ExtentTestManager.extentLogger.info("Connected to db "+dbConnectionURL);
			Statement statement = conn.createStatement();
			int i=0;
			do
			{
				String queryString = "USE " + databaseName
				+ " select pkg_processed from search where client_ref_number='"+clientRefNumber+"'";
				ExtentTestManager.extentLogger.info("Running query - " + queryString);
				log.info("Running query - " + queryString);
				ResultSet rs = statement.executeQuery(queryString);

				while (rs.next())
				{
					log.info("Package ID for the searchId : " + rs.getString(1));
					pkg_Processed=rs.getInt("pkg_processed");

				}
				if(pkg_Processed>=40)
					break;
				Thread.sleep(5000);
				ExtentTestManager.extentLogger.info("Package process is "+pkg_Processed+" which is less than 40 - <br>Retrying.... after wait for 5s");
				i++;
			}while(i<15);

			log.info("Retrieved Package Request ID from the search ID detail from database.");
			conn.close();
			if(i==10&&pkg_Processed<40)
			{
				ExtentTestManager.extentLogger.fail("Fail to move order to process 40 or more Actual pkg_processed"+pkg_Processed);
				Assert.fail("Fail to move order to process 40");
			}
			else
				ExtentTestManager.extentLogger.info("Reterived data from db closing connection");
				ExtentTestManager.extentLogger.pass("Successfully Package process is move 40 and above");

		} 
		catch (Exception e)
		{
			ExtentTestManager.extentLogger.info("Failed to reterive data from db");
			log.error("Unable to Package Request ID from the search ID detail from database.");
			log.error("Fail ", e);
			Assert.fail("Unable to Package Request ID from the search ID detail from database.", e);
		}
	}*/

//	public HashMap<String,String> getsearchtypecodeusingClientRefNumber(String id, String dbconnURL, String dbDatabaseName ,String dbconnUsername,String dbconnPassword)
//	{
//		HashMap<String,String> data=new HashMap<String,String>();
//		String searchtypecode = null ;
//		try 
//		{
//			Class.forName(SQL_DRIVER);
//			Connection conn = DriverManager.getConnection(dbconnURL, dbconnUsername, dbconnPassword);
//			/* System.out.println("connected"); */
//			//log.info("Connected to " + ParameterDataSetup.testEnvironment + " database.");
//			ExtentTestManager.extentLogger.info("Connected to db "+dbconnURL);
//			Statement statement = conn.createStatement();
//			String queryString = "USE " + dbDatabaseName
//					+ " select pkg_processed,package_req_id from search where client_ref_number = '"+id+"";
//			ExtentTestManager.extentLogger.info("Running query - " + queryString);
//			log.info("Running query - " + queryString);
//			ResultSet rs = statement.executeQuery(queryString);
//
//			while (rs.next()) {
//				log.info("Package ID for the searchId : " + rs.getString(1));
//				data.put("pkgProcessed", rs.getString("pkg_processed"));
//				data.put("yCode", rs.getString("package_req_id"));
//
//			}
//			log.info("Retrieved Package Request ID from the search ID detail from database.");
//			conn.close();
//			ExtentTestManager.extentLogger.info("Reterived data from db closing connection");
//		} catch (Exception e) {
//			ExtentTestManager.extentLogger.info("Failed to reterive data from db");
//			log.error("Unable to Package Request ID from the search ID detail from database.");
//			log.error("Fail ", e);
//			Assert.fail("Unable to Package Request ID from the search ID detail from database.", e);
//		}
//		return data;
//	}

	/*public void runUpdateQuery(String updateQuery) throws Exception
	{
		ExtentTestManager.extentLogger.info("Running update query: "+updateQuery);
		DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
		Class.forName(SQL_DRIVER);
		Connection conn = DriverManager.getConnection(dbConnectionURL, dbUsername, dbPassword);
		ExtentTestManager.extentLogger.info("Connected to db "+dbConnectionURL);
		Statement stmt = conn.createStatement();

		int updateCount = stmt.executeUpdate(updateQuery);
		ExtentTestManager.extentLogger.info("Executed update query<br>Result Rows updated: "+updateCount);
		stmt.close();
		conn.close();
	}


}*/
