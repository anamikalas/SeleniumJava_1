package Demo1;

public class AirthmaticOperation1 
{
	int x; // global variable

	// Addition method
	public void add() {
		int a = 3; // local variable
		int b = 2;
		int c = a + b;
		System.out.println(c);
	}

	// Subtract method
	public void sub() 
	{
		int a = 10;
		int b = 6;
		int c = a - b;
		System.out.println(c);
	}

	// Multiplication method
	public void mul() 
	{
		int a = 5;
		int b = 3;
		int c = a * b;
		System.out.println(c);
	}

	public void add1(int a, int b) 
	{
		int c = a + b;
		System.out.println(c);
	}

	public void printString(String str) 
	{
		String str1 = "Hello 1";
		System.out.println(str1);
	}

	public void printVariable(int a, String str) 
	{
		System.out.println(a);
		System.out.println(str);
	}

	public int sub1() 
	{
		int a = 10;
		int b = 20;
		int c = a - b;
		return c;
	}

	public static void testMethod() {
		System.out.println("Inside Static Method");
	}
}
