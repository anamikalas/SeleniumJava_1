package Demo1;

public class MainClass1
{
	
public static void main(String[] args)
{
	//1. Create object of method class
   
   AirthmaticOperation1 objAO= new AirthmaticOperation1();
   objAO.add();
   //objAO.sub();
   //objAO.mul();
   //objAO.add1(10,20);
   objAO.printString("Hello 2");
   objAO.printString(null);
   objAO.printVariable(5, "Test");
   int res=objAO.sub1();
   System.out.println(res);
   objAO.sub1();
   System.out.println(objAO.sub1());
   AirthmaticOperation1.testMethod();
}



}
