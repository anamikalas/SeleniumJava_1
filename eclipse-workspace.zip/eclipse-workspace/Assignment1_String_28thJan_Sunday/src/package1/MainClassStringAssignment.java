package package1;

import package2.GetPercentageOfObjectsThatArePresentInStrArray;
import package2.StringAssignment;

public class MainClassStringAssignment 
{
	public static void main(String[] args)
	{
		StringAssignment objSA = new StringAssignment();
		
		//objSA.printLengthOfEachString1();
		//objSA.verifyStringIsPalindrome2();
		//objSA.verifyPrimeNoOrNot();
		//objSA.verifyTwoStringEndWIthSameChar3();
		//objSA.verify8thCharOfTwoStringIsSame4_1();
		//objSA.verify8thCharOfTwoStringIsSame4_2();
		//objSA.print1stDuplicateCharOfAStr5_1();
		//objSA.print1stDuplicateCharOfAStr5_2();
		//objSA.print1stUniqueCharOfAString6();
		//objSA.reverseEachCharOfAString15();
		//objSA.countWhiteSpaceInAString16();
		//objSA.verifyStringContainsNumber17();
		//objSA.printAllNumbersExistInAString18();
		//objSA.printAllIndexOfAllNumbersInAString19();
		//objSA.swap1stAndLastCharOfAString20();
		//objSA.addAWordBeforeAString21();
		//objSA.printTextSimple22();
		//objSA.printAllDuplicateCharPresentInString7();
		//objSA.printAllUniqueCharPresentInAString8();
		//objSA.printTheOccurenceOfEachCharOfAString14();
		//objSA.printTheCharWhoseOccurenceIsMaxInAString12();
		//objSA.devideStringIn3EqualPart11_1();
		//objSA.devideStringIn3EqualPart11_1();
		//objSA.devideStringIn3EqualPart11_2();
		//objSA.findCountOfAllCharacterInAString9_1();
		//objSA.findCountOfAllCharacterInAString9_2();
		//objSA.compareStringWithSpaceAndSpecialChar();
		//objSA.printTheCharWhoseOccurenceIsMinInAString13();
		
		GetPercentageOfObjectsThatArePresentInStrArray objA = new GetPercentageOfObjectsThatArePresentInStrArray();
		objA.getPercentageOfObjectsThatArePresentInStrArray();
	}
}
