package package2;

public class VerifyNumberIsFibonakiOrNot 
{
	public static void main(String[] args)
	{
		int number1 = 5;
        int number2 = 7;
        int number3 = 8;
        
        System.out.println(number1 + " is Fibonacci? " + isFibonacci(number1));
        System.out.println(number2 + " is Fibonacci? " + isFibonacci(number2));
        System.out.println(number3 + " is Fibonacci? " + isFibonacci(number3));
	    }
	    
	    public static boolean isFibonacci(int number) 
	    {
	    	if (number < 0) 
	    	{
	            return false; // Fibonacci sequence starts from 0
	        }
	        
	        int a = 0;
	        int b = 1;
	        
	        for (int i = 0; a < number; i++) {
	        	
	            int temp = b;
	            System.out.println("temp: " + temp);
	            b = a + b;
	            System.out.println("B: " + b);
	            a = temp;
	            System.out.println("A: " + a);
	        }
	        
	        return a == number;
	    }

}
