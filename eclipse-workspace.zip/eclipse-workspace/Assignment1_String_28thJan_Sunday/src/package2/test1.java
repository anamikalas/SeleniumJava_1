package package2;

import java.util.*;
import java.io.*;
import java.util.Scanner;
class Main 
{

  public static int PermutationStep(Integer num) 
  {
        char[] digits = Integer.toString(num).toCharArray();
       //char[] digits = num.toCharArray();
        int i;
      //  System.out.print("1");
        
        for (i = digits.length - 2; i >= 0; i--) 
        {
            if (digits[i] < digits[i + 1]) 
            {
                break;
            }
        }

        if (i == -1) 
        {
            return -1; 
        }
     // System.out.print("2");
        int j;
        for (j = digits.length - 1; j > i; j--) 
        {
            if (digits[j] > digits[i]) 
            {
                break;
            }
        }
        
        char temp = digits[i];
        digits[i] = digits[j];
        digits[j] = temp;
        //System.out.print("3");
       
        for (int start = i + 1, end = digits.length - 1; start < end; start++, end--) 
        {
            char t = digits[start];
            digits[start] = digits[end];
            digits[end] = t;
        }
       // System.out.print("4");
        return Integer.parseInt(new String(digits));
    }

  public static void main(String[] args) 
  {  
   Scanner s = new Scanner(System.in);     
   int pp = s.nextInt();
   int result = PermutationStep(pp);
   System.out.print( result);
  }

}