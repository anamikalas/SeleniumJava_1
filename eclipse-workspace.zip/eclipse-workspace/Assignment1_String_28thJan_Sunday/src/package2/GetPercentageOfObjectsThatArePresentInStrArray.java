package package2;

import java.util.ArrayList;
import java.util.Scanner;

public class GetPercentageOfObjectsThatArePresentInStrArray 
{
	public void getPercentageOfObjectsThatArePresentInStrArray() 
	{
		try 
		{
			ArrayList<String> arrLst = new ArrayList<>();
			Scanner sc1 = new Scanner(System.in);
			System.out.println("Enter values one by one:    ");			
			for(int i = 0; i < 100; i++)
			{
				String input = sc1.next(); // Line().toString()
				arrLst.add(input);
				// currentSize++;

				if(input.equalsIgnoreCase("FULL")) 
				{
					System.out.println("Array is full...");
					break;
				}
			}
			// System.out.println("Current size: " + currentSize);

			// Determine the percentage of K objects present in the array
			Scanner sc2 = new Scanner(System.in);
			System.out.println("Enter the size of k:   ");
			int k = sc2.nextInt(); // size of k
			sc2.nextLine(); // value of k with new line

			int countPresence = 0;
			System.out.println("Enter " + k + " objects to check their presence in the array list:- ");
			for(int i=0; i<k; i++)
			{
				String strObjectToChk = sc2.nextLine();
				for(int j=0; j<arrLst.size(); j++)
				{
					if(arrLst.contains(strObjectToChk))
					{
						countPresence++;
						break; // Object found, no need to check further
					}
				}
			}

			// Calculate and display the percentage rounded to the nearest integer
			if(k > 0)
			{
				double percentage = ((double) countPresence/k) * 100;
				int roundedPercentage = (int) Math.round(percentage);
				System.out.println("Percentage of objects present in the array:   " + roundedPercentage + "%");
			}
			else
			{
				System.out.println("No objects provided to check percentage.");
			}
			
			sc1.close();
			sc2.close();
		} 
		catch (Exception ex) 
		{
			ex.printStackTrace();
		}

	}
}
