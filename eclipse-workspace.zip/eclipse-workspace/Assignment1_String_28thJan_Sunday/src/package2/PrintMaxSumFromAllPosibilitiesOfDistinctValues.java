package package2;

import java.util.Scanner;

public class PrintMaxSumFromAllPosibilitiesOfDistinctValues 
{
	public class MaxSumWithLCM 
	{
	    // Function to calculate GCD of two numbers
	    static int gcd(int a, int b) 
	    {
	        while (b != 0) 
	        {
	            int temp = b;
	            b = a % b;
	            a = temp;
	        }
	        return a;
	    }

	    // Function to calculate LCM of two numbers
	    static int lcm(int a, int b) 
	    {
	        return (a / gcd(a, b)) * b;
	    }

	    // Function to calculate LCM of an array of numbers
	    static int lcmArray(int[] arr, int size) 
	    {
	        int ans = arr[0];
	        for (int i = 1; i < size; i++) 
	        {
	            ans = lcm(ans, arr[i]);
	        }
	        return ans;
	    }

	    // Function to find the maximum sum of distinct values
	    // whose LCM equals the second largest element in the array
	    static int maxSumWithLCM(int[] arr, int n) 
	    {
	        if (n < 2)
	            return 0;

	        // Finding the second largest element
	        int max1 = Integer.MIN_VALUE, max2 = Integer.MIN_VALUE;
	        for (int i = 0; i < n; i++) 
	        {
	            if (arr[i] > max1) 
	            {
	                max2 = max1;
	                max1 = arr[i];
	            } 
	            else if (arr[i] > max2 && arr[i] != max1) 
	            {
	                max2 = arr[i];
	            }
	        }

	        int targetLCM = max2;
	        int maxSum = 0;

	        // Generate all subsets using bit masking
	        int subsetCount = 1 << n; // 2^n subsets
	        for (int mask = 1; mask < subsetCount; mask++) 
	        {
	            int sum = 0;
	            int subsetLCM = 0; // Initialize LCM of subset to 0
	            boolean isValidSubset = true;

	            for (int i = 0; i < n; i++) 
	            {
	                if ((mask & (1 << i)) != 0) 
	                { // Check if i-th element is in the subset
	                    sum += arr[i];
	                    if (subsetLCM == 0) 
	                    {
	                        subsetLCM = arr[i];
	                    }
	                    else 
	                    {
	                        subsetLCM = lcm(subsetLCM, arr[i]);
	                    }
	                    if (subsetLCM > targetLCM) 
	                    {
	                        isValidSubset = false;
	                        break;
	                    }
	                }
	            }

	            // Check if the subset is valid and its LCM equals targetLCM
	            if (isValidSubset && subsetLCM == targetLCM) 
	            {
	                if (sum > maxSum) 
	                {
	                    maxSum = sum;
	                }
	            }
	        }

	        return maxSum;
	    }

	    public static void main(String[] args) 
	    {
	        Scanner sc = new Scanner(System.in);

	        // Input size of the array
	        System.out.print("Enter the size of the array: ");
	        int n = sc.nextInt();

	        // Input array elements
	        int[] arr = new int[n];
	        System.out.println("Enter the elements of the array:");
	        for (int i = 0; i < n; i++) {
	            arr[i] = sc.nextInt();
	        }

	        // Find and print the maximum sum
	        int maxSum = maxSumWithLCM(arr, n);
	        System.out.println("Maximum sum from distinct values whose LCM equals the second largest element: " + maxSum);

	        sc.close();
	    }
}
}
