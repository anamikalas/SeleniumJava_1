package package2;

import java.util.Scanner;

public class StringAssignment 
{
	public void printLengthOfEachString1() //Get length of each string, for eg - this - 4, is - 2 and demo - 4
	{
		String str = "this is demo";
		String strArr[] = str.split("\\s+");
		String newStr;
		int len;

		for(int i=0; i<strArr.length; i++)
		{
			newStr = strArr[i];
			len = newStr.length();

			System.out.println("Length of '" + strArr[i] + "' string is:-" + len);
		}
	}
	public void verifyStringIsPalindrome2() //Check whether a string is palindrome or not
	{
		String str = "madam";
		char charArr[] = str.toCharArray(); 
		boolean isPalindrome = false;

		for(int i=0,j=charArr.length-1; i<charArr.length; i++,j--)
		{
			if(!(charArr[i] == charArr[j]))
			{
				isPalindrome = false;
				break;
			}
			else
				isPalindrome = true;
		}
		if(isPalindrome == false)
			System.out.println(str + " not palindrome...");
		else
			System.out.println(str + " palindrome...");
	}
	public void verifyPrimeNoOrNot() //Verify palindrome or not
	{
		int n = 9;
		boolean isPrime = true;

		for(int i=2; i<=n-1; i++)
		{
			if(n%i==0)
			{
				isPrime = false;
				break;
			}
		}
		if(isPrime == true)
			System.out.println(n + " is prime...");
		else
			System.out.println(n + " not prime...");
	}
	public void verifyTwoStringEndWIthSameChar3() //Verify 2 string end with same character
	{
		String str1 = "name";
		char strArr1[]= str1.toCharArray();
		int len1 = strArr1.length-1;
		System.out.println("1st string length is:- " + len1 + " and last char is:- " + strArr1[strArr1.length-1]);

		String str2 = "fameege";
		char strArr2[] = str2.toCharArray();
		int len2 = strArr2.length-1;
		System.out.println("1st string length is:- " + len2 + " and last char is:- " + strArr2[strArr2.length-1]);

		if(strArr1[len1] == strArr2[len2])
			System.out.println("Last char of " + str1 + " and " + str1 + " which is " +  " same");
		else
			System.out.println("Last char of " + str2 + " and " + str2 + " which is " +  " not same");
	}
	public void verify8thCharOfTwoStringIsSame4_()
	{
		int indexNo = 8;
		String str1 = "violencce";
		char charArr1[] = str1.toCharArray();
		int arrLen1 = charArr1.length;

		String str2 = "excelence";
		char charArr2[] = str2.toCharArray();
		int arrLen2 = charArr2.length;

		if((charArr1[arrLen1-1]) == (charArr2[arrLen2-1]))
		{
			System.out.println("char last of string :\"" +charArr1[arrLen1-1] + "\"  and char of second string: '" +charArr2[arrLen1-1]+ "'");
			//System.out.println(charArr2[arrLen1-1]);
			//System.out.println(charArr1[arrLen1-1] + " same...");
		}
		else
		{
			System.out.println(charArr1[arrLen1-1]);
			System.out.println(charArr2[arrLen1-1]);
			System.out.println(charArr1[arrLen1-1] + " not same...");
		}


	}
	public void verify8thCharOfTwoStringIsSame4_2() //Print 1st duplicate character of a string
	{
		boolean isSame = false;
		String str1 = "temperature";
		char charArr1[] = str1.toCharArray();
		int arrLen1 = charArr1.length;

		String str2 = "okfurniture";
		char charArr2[] = str2.toCharArray();
		int arrLen2 = charArr2.length;

		for(int i=0, j=0; i<9; i++,j++)
		{
			if(charArr1[i] != charArr2[j])
			{
				isSame = false;
				//break;
			}
			else {
				isSame = false;
				break;
			}
		}
		if(isSame == true)
		{
			System.out.println("1st value is:- " + charArr1[7]);
			System.out.println("2nd value is:- " + charArr2[7]);
			System.out.println("Char is:- " + charArr1[7] + " and it's same...");
		}
		else
		{
			System.out.println("1st value is:- " + charArr1[7]);
			System.out.println("2nd value is:- " + charArr2[7]);
			System.out.println("Char is:- " + charArr2[7] + " and not same...");
		}
	}
	public void print1stDuplicateCharOfAStr5_1()
	{
		boolean isDuplicate = false;
		char charVal = 0;
		String str1 = "thisis java is";
		char charArr1[] = str1.toCharArray();
		int countDuplicate = 0;

		for(int i=0; i<charArr1.length; i++)
		{
			for(int j=0; j<charArr1.length; j++)
			{
				if(charArr1[i] == charArr1[j])
				{
					countDuplicate++;
					isDuplicate = true;
					charVal = charArr1[i];
					if(countDuplicate >1)
						break;					
				}	
			}

			if(isDuplicate == true && countDuplicate > 1) 
				break;				
			countDuplicate = 0;
		}
		System.out.println("1st duplicate character is:- " + charVal);
	}
	public void print1stDuplicateCharOfAStr5_2() //Practice
	{
		String str = "this is java";
		char charArr[] = str.toCharArray();

		boolean isDuplicate = false;
		int countDuplicate = 0;
		char duplicateChar = 0;
		int index = 0;

		for(int i=0; i<charArr.length; i++)
		{
			for(int j=0; j<charArr.length; j++)
			{
				if(charArr[i] == charArr[j])
				{
					isDuplicate = true;
					duplicateChar = charArr[i];
					index = i;
					countDuplicate++;
				}
				if(isDuplicate == true && countDuplicate > 1)
					break;
			}
			if(isDuplicate == true && countDuplicate > 1)
				break;
			countDuplicate = 0;
		}
		System.out.println("1st duplicate char is:-" + duplicateChar + " and index of " + duplicateChar + " is:- " + index);
	}
	public void print1stUniqueCharOfAString6()  
	{
		String str = "telcometo Amdocslllxxx";
		char charArr[] = str.toCharArray();
		boolean isUnique = false;
		char charUnique = 0;
		int countUnique = 0;
		int index = 0;

		for(int i=0; i<charArr.length; i++)
		{
			for(int j=0; j<charArr.length; j++)
			{
				if(charArr[i] == charArr[j]) 
					countUnique++;	 
			}		
			if(countUnique<2)
			{
				charUnique = charArr[i];
				break;
			}
			countUnique = 0;
		}	
		System.out.println("1st unique: " + charUnique);
	}
	public void reverseEachCharOfAString15()
	{
		String str = "this is demo";
		String strArr[] = str.split("\\s+");
		String strNew = "";

		for(int i=0;i<strArr.length;i++)
		{
			char charArr[] = strArr[i].toCharArray();
			//String strNew = "";

			for(int j=charArr.length-1; j>=0; j--)
			{
				strNew = strNew + charArr[j];					
			}
			System.out.print(strNew + " ");
			strNew = "";
		}
	}
	public void countWhiteSpaceInAString16()
	{
		String str = "Welcome to India, we all are going to Indian";
		String strArr[] = str.split("\\S+"); //Fetching white spaces only from a string and creating array of those white spaces
		int countWhite = 0;
		for(int i=0; i<strArr.length; i++)
		{
			//if(strArr[i].equals(" "))
			if(strArr[i].matches(" "))
				//countWhite = countWhite + 1;
				countWhite++;
		}
		System.out.println("Total white space count in string is:- " + countWhite);
	}
	public void verifyStringContainsNumber17()
	{
		String str = "2welcome 217 In34dia 6 which5 is no. 1";
		char charArr[] = str.toCharArray();
		String newStr = "";
		int countNumber = 0;

		for(int i=0; i<charArr.length; i++)
		{
			//if(strArr[i].matches("\\d"));
			if(Character.isDigit(charArr[i]))
			{
				countNumber++;
				newStr = newStr + charArr[i];
			}
		}
		if(countNumber > 0)
			System.out.println("Number's are " + newStr + " and total count of number is:- " + countNumber);
		else
			System.out.println("Number doesn't exist...");
	}
	public void printAllNumbersExistInAString18()
	{
		String str = "welcome 2 space. 7Each spa9ce contain5ing5 people8";
		char charArr[] = str.toCharArray();
		String newStr = "";

		for(int i=0; i<charArr.length; i++)
		{
			if(Character.isDigit(charArr[i]))
				newStr = newStr + charArr[i];
		}
		System.out.println("All numbers that exist in the string is:- " + newStr);
	}
	public void printAllIndexOfAllNumbersInAString19()
	{
		String str = "2welc3ome1 to i5nd6ia7";
		char charArr[] = str.toCharArray();

		for(int i=0; i<charArr.length; i++)
		{
			if(Character.isDigit(charArr[i]))
			{
				//System.out.println(charArr[i]);
				System.out.println("Index of " + charArr[i] + " is:- " + i);
			}
		}
	}
	public void swap1stAndLastCharOfAString20()
	{
		String str = "Welcome";
		char charArr[] = str.toCharArray();
		int len = charArr.length-1;
		char swapArr = 0;
		String newStr = "";

		swapArr = charArr[0];
		charArr[0] = charArr[charArr.length-1];
		//charArr[charArr.length-1] = charArr[0];
		charArr[charArr.length-1] = swapArr;

		for(int i=0; i<charArr.length; i++)
		{
			newStr = newStr + charArr[i];
		}
		System.out.println(newStr);
	}
	public void addAWordBeforeAString21()
	{
		StringBuilder str1 = new StringBuilder("hello");
		StringBuilder str2 = new StringBuilder("India");

		str2.append(" " + str1);
		System.out.println(str2);
	}
	public void printTextSimple22()
	{
		String str1 = "simple";
		char charArr1[] = str1.toCharArray();

		String str2 = "Welcome";
		char charArr2[] = str2.toCharArray();

		System.out.println("Printing text SIMPLE=======================");
		for(int i=0; i<str1.length(); i++)
		{
			//System.out.println(str.substring(0, i+1));
			//System.out.println(str.substring(0, str.length()-i));
			for(int j=0; j<charArr1.length-i; j++)
			{

				System.out.print(charArr1[j]);
			}
			System.out.println("");
		}
		System.out.println("Printing text WELCOME==================");
		for(int i=0; i<charArr2.length; i++)
		{
			//System.out.println(str.substring(0, i+1));
			System.out.println(str2.substring(0, str2.length()-i));
		}

	}
	public void printAllDuplicateCharPresentInString7() //Print all duplicate characters present in a array
	{
		String str = "hello world";
		char charArr[] = str.toCharArray();
		//int countDup = 0;

		System.out.println("Duplicate characters are:- =============");
		for(int i=0; i<charArr.length; i++)
		{
			for(int j=i+1; j<charArr.length; j++)
			{
				if(charArr[i] == charArr[j] && charArr[i] != ' ')
				{
					System.out.println(charArr[j]);
					break;
				}
			}
		}

	}
	public void printAllUniqueCharPresentInAString8()
	//Print all unique characters present in a array
	{
		String str = "hello world";
		char charArr[] = str.toCharArray();
		boolean isDuplicate = true;
		int countDup = 0;

		for (int i = 0; i < charArr.length; i++) 
		{
			// isDuplicate = false;
			for (int j = 0; j < charArr.length; j++) 
			{
				if (charArr[i] == charArr[j])
				{
					//isDuplicate = true;
					countDup++;
					//break;
				}
			}

			if (countDup <2) 
			{
				System.out.println(charArr[i] + " ");
			}
			countDup =0;
		}
	}
	public void printTheOccurenceOfEachCharOfAString14()
	//Print all unique characters present in a array
	{
		String str = "Hello World is a string of characters";
		char charArr[] = str.toCharArray();
		boolean isDuplicate = true;
		int countChar1 = 0;
		int countChar2 = 0;

		for (int i=0; i<charArr.length; i++) 
		{
			for (int j=0; j<charArr.length; j++) 
			{
				if (charArr[i] == charArr[j])
				{
					countChar1++;
				}
			}				
			if(countChar1 >1) 
			{
				for (int k=0 ; k<=i; k++) 
				{
					if (charArr[k] == charArr[i])
					{
						countChar2++;
					}
				}
				if (countChar1 >1 && countChar2 <2) 
				{
					System.out.println(charArr[i] + " total  repeted times "+ countChar1);
				}
			}									
			countChar1 =0;
			countChar2 =0;
		}
	}
	public void printTheCharWhoseOccurenceIsMaxInAString12() //Incomplete
	{
		String str = "Hello world hi";
		char charArr[] = str.toCharArray();	
		int countMax = 0;
		int countTotal = 0;
		char charVal ='\0';

		for(int i=0; i<charArr.length; i++)
		{
			for(int j=0; j<charArr.length; j++)
			{
				if(charArr[i] == charArr[j])
					countMax++;
			}
			if(countMax > countTotal)
			{
				charVal = charArr[i];
				countTotal = countMax;		
			}
			countMax =0;
		}		
		System.out.println("Max occurance of char is: " + charVal +" and count: "+ countTotal);
	}
	public void printTheCharWhoseOccurenceIsMinInAString13()
	{
		String str = "Hello     HhhHHHHHHHworldere                     wrakjhsh       dtsufijslfjleeeeeeeeeeee";
		char charArr[] = str.toCharArray();	
		int countChar1 = 0;
		int countTotal = 0;
		char charVal ='\0';

		for(int i=0; i<charArr.length; i++)
		{
			for(int j=0; j<charArr.length; j++)
			{
				if(charArr[i] == charArr[j])
				{
					countChar1++;
				}
			}
			if(i == 0) 
			{
				charVal = charArr[i];
				countTotal = countChar1;
			}
			if(countChar1 < countTotal )
			{
				charVal = charArr[i];
				countTotal = countChar1;		
			}
			countChar1 = 0;
		}		
		System.out.println("min occurance of char is: " + charVal +" and count: "+ countTotal);
	}
	public void devideStringIn3EqualPart11_1()
	{
		String str = "university is always good read";
		char charArr[] = str.toCharArray();

		int len = charArr.length;
		int noOfPart = 3;
		int partSize = 0;
		String newStr = "";

		if(len % noOfPart != 0)
		{
			System.out.println("Sorry, cant devided into 3 parts...");
		}
		else
		{			
			for(int i=0; i<charArr.length; i++)
			{
				partSize = len / noOfPart;
				int start = i*partSize;
				int end = (i+1)*partSize; 

				for(int j=start; j<end; j++)
				{
					newStr = newStr + charArr[j];					
				}

				System.out.println(newStr);
				newStr = "";
				if(len == end)
					break;
			}
		}
	}
	public void devideStringIn3EqualPart11_2()
	{
		String str = "university is a good option ofcourse";
		//String strArr[] = new String[3];
		int strLen = str.length();
		int noOfParts = 3;
		String newArr[] = new String[noOfParts];
		int partSize = strLen/noOfParts;

		if(strLen % noOfParts != 0)
		{
			System.out.println("Sorry can not print");
		}
		else
		{
			for(int i=0; i<partSize; i++)
			{
				int start = i*partSize;
				int end = (i+1)*partSize;

				newArr[i] = str.substring(start,end);
				System.out.println(newArr[i]);
				if(end == strLen)
					break;
			}
		}

	}
	public void findCountOfAllCharacterInAString9_1()
	{
		String str = "Welcome";
		char charArr[] = str.toCharArray();
		int countChar1 = 0, countChar2 = 0;

		for (int i = 0; i < charArr.length; i++) 
		{
			for (int j = 0; j < charArr.length; j++) 
			{
				if (charArr[i] == charArr[j]) 
					countChar1++;
			}
			if (countChar1 > 1)
			{
				for (int k = 0; k <= i; k++) 
				{
					if(charArr[k] == charArr[i])
						countChar2++;	
				}				
			}
			if(countChar1 >= 1 && countChar2 < 2)
				System.out.println(charArr[i] + " count is:- " + countChar1);

			countChar1 = 0;
			countChar2 = 0;
		}
	}	
	public void findCountOfAllCharacterInAString9_2()
	{
		String str = "Welcome Welcome Welcome Welcome";
		char charArr[] = str.toCharArray();
		int countChar1 = 0, countChar2 = 0;

		for(int i=0 ;i< charArr.length; i++) 
		{
			char cs= charArr[i];
			long count = str.chars().filter(a->a == cs).count();
			System.out.println(charArr[i] + " count is:- " + count);
		}

	}
	public void compareStringWithSpaceAndSpecialChar()
	{
		String str1 = "MADAM";		
		String str2 = "mad   am  ";
		String str3 = "madam  ";
		String str4 = "madam";

		System.out.println(str4.compareToIgnoreCase(str1) ==  0 ? "same" : "not same");
		System.out.println(str3.compareTo(str2) ==  0 ? "same" : "not same");
		System.out.println(str4.compareToIgnoreCase(str1.replace(" ", "")) ==  0 ? "same" : "not same");		
		System.out.println(str3.trim().compareToIgnoreCase(str2.replace(" ", "")) ==  0 ? "same" : "not same");	
	}
	public void getCountOfString()
	{
		String str = "hello world welcome to India, hello all, come to India, we will welcome you";
		String strArr[] = str.split("\\s+");
		int countStr1 = 0, countStr2 = 0;

		for(int i=0; i<strArr.length; i++)
		{
			for(int j=0; j<strArr.length; j++)
			{
				if(strArr[i].equals(strArr[j]))
					countStr1++;
			}
			if(countStr1 >= 1)
			{
				for(int k=0; k<=i; k++)
				{
					if(strArr[k] == strArr[i])
						countStr2++;
				}
			}
			if(countStr1 == 1 && countStr2 < 2)
				System.out.println("Count of " + strArr[i] + " is:- " + countStr1);
			countStr1 = 0;
			countStr2 = 0;
		}
	}
	public void swap2String() //Swap 2 string
	{
		/*StringBuilder str1 = new StringBuilder("Anamika");
		StringBuilder str2 = new StringBuilder("Laskar"); */

		String str1 = "hello";
		String str2 = "world";

		str1 = str1 + str2;
		System.out.println("Before: " + str1);

		str2 = str1.substring(0, str1.length()-str2.length());
		System.out.println("Str 2: " + str2);

		str1 = str1.substring(str2.length());
		//System.out.println("Str 2: " + str2);

		System.out.println("After: " + str1 + str2);
	}
	public void swap2Integer() //Swap 2 integer
	{
		int a = 2, b = 3;
		System.out.println("Before, A: " + a + " and B: " + b);

		b = a + b;
		a = b - a;
		b = b - a;

		System.out.println("After, A: " + a + " and B: " + b);
	}
	public void getSmallestAndLargetWordInAString()
	{
		String str = "welcome to India my country";
		String strArr[] = str.split("\\s+");
		int strLen = 0, totLen = 0;
		String strVal = "";

		for(int i=0; i<strArr.length; i++)
		{
			strLen = strArr[i].length();
			System.out.println("Length of word: " + strArr[i] + strLen);
			if(i==0)
			{
				totLen = strLen;
				strVal = strArr[i];
			}
			if(strLen > totLen)
			{
				totLen = strLen;
				strVal = strArr[i];
			}
		}
		//len1 = 0;
		System.out.println("Long word: \"" + strVal + "\" and length is: " + totLen);
	}

	//take 1 and provide output 0, take 0 and provide output 1
	public void print0or1()
	{
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter 0 or 1: ");
		int inputVal = scanner.nextInt();

		// Use XOR operation to flip the bit
		int flippedVal = inputVal ^ 1;

		System.out.println("Flipped value: " + flippedVal);

		scanner.close();
	}


	public void verifyYearIsLeapYeasrOrNot()
	{
		try
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter year:- ");
			int year = sc.nextInt();
			boolean isLeapYear = false;

			if(year % 4 == 0)
				isLeapYear = true;
			else if(year % 100 == 0)
				isLeapYear = true;
			else if(year % 400 == 0)
				isLeapYear = true;
			else
				isLeapYear = false;
			if(isLeapYear == true)
				System.out.println("Leap year...");
			else
				System.out.println("No...");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	//get the maximum no from an integer array
	public void getMaxNoFromAnInteger()
	{
		int intArr[] = new int[] {1,2,3,4,5,6,7,1,2,2,1,};
		int maxNo = 0;
		
		for(int i=0; i<intArr.length; i++)
		{
			for(int j=0; j<intArr.length; j++)
			{
				if(intArr[i] > intArr[j])
					maxNo = intArr[i];
			}
			//maxNo = 0;
		}
		System.out.println("Max: " + maxNo);
	}
	
	//input = Automation Testing, Output = noitamotuA Testing
	public void reverse1stString()
	{
		String str = "Automation Testing";
		String strArr[] = str.split("\\s+");
		char charArr[] = strArr[0].toCharArray();
		
		String strNew1 = "", strNew2 = "";
		
		for(int i=charArr.length-1; i>=0; i--)
		{
			strNew1 = strNew1 + charArr[i];
		}
		
		strNew2 = strNew1 + " " + strArr[1];
		
		System.out.println(strNew2);
	}
	
	//convert a number into a integer array
	public void printVal()
	{
		 int number = 123456;
		 String str1 = String.valueOf(number);
	     int intArr[] = new int[str1.length()];
	     
	     	// Step 3: Parse each character (digit) and store in the array
	        for (int i = 0; i < str1.length(); i++) 
	        {
	            char digitChar = str1.charAt(i);
	            intArr[i] = Character.getNumericValue(digitChar);
	        }
	        
	        // Print the resulting array (optional)
	        System.out.println("Integer array from number:");
	        for (int digit : intArr) 
	        {
	            System.out.print(digit + " ");
	        }
	        System.out.println();
	}
	
	
}
