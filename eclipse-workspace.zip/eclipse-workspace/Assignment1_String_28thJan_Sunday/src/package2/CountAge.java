package package2;

import java.util.*;
import java.io.*;
import java.net.*;

public class CountAge 
{
	public static void main(String[] args) 
	{
		String endpointUrl = "https://coderbyte.com/api/challenges/json/age-counting";
		try 
		{
			String jsonResponse = getHttpResponse(endpointUrl);
			// System.out.println(jsonResponse);

			int count = countAgesGreaterThanOrEqualTo(jsonResponse, 50);

			System.out.println(count);
		} 
		catch (Exception ex) 
		{
			System.err.println("Error");
		}
	}

	private static String getHttpResponse(String strUrl) throws IOException 
	{
		HttpURLConnection huc = null;
		BufferedReader reader = null;
		StringBuilder response = new StringBuilder();

		try 
		{
			URL url = new URL(strUrl);
			huc = (HttpURLConnection) url.openConnection();
			//HttpURLConnection huc = (HttpURLConnection) new URI(strUrl).toURL().openConnection();
			huc.setRequestMethod("GET");

			reader = new BufferedReader(new InputStreamReader(huc.getInputStream()));
			String line;
			while ((line = reader.readLine()) != null) 
			{
				response.append(line);
			}

		} 
		catch (Exception ex) 
		{
			System.err.println("Error");
			// throw ex;
		} 
		finally 
		{

			if (reader != null) 
			{
				try 
				{
					reader.close();
				} catch (IOException e) 
				{

				}
			}
			if (huc != null) 
			{
				huc.disconnect();
			}
		}

		return response.toString();
	}

	private static String extractDataFieldValue(String strJsonString) 
	{
		int dataIndex = strJsonString.indexOf("\"data\":\"") + "\"data\":\"".length();
		int endIndex = strJsonString.lastIndexOf("\"}");

		String str = strJsonString.substring(dataIndex, endIndex);
		return str;
	}

	private static int countAgesGreaterThanOrEqualTo(String jsonResponse, int threshold) 
	{
		int count = 0;

		String strJsonItems = extractDataFieldValue(jsonResponse);
		String[] items = strJsonItems.split(",\\s*");

		for (String item : items) 
		{
			if (item.startsWith("age=")) 
			{
				try {

					int age = Integer.parseInt(item.substring(4).strip());

					if (age >= threshold) 
					{
						count++;
					}
				} 
				catch (Exception e) 
				{

					System.err.println("Invalid age format: " + item.substring(4));
				}
			}
		}

		return count;
	}
}