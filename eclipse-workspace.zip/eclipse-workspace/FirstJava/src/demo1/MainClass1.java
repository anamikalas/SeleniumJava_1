package demo1;

public class MainClass1 {
	public static void main(String[] args) {
		System.out.println("Hello java");
		int a=2;
		int b=3;
		int c=a+b;
		System.out.println(c);
		int d=b-a;
		System.out.println(d);
	}

}
