package package_demo;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class ActionOperations_16thMar2024 
{
	@Test (enabled =  true) //this will not execute code
	public void launchApplication()
	{
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe"); //Server layer
		WebDriver driver = new ChromeDriver(); //API layer, launch browser
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize(); //To maximize browser (this command will not work for Safari browser)
		//driver.manage().window().fullscreen(); //It will maximize window, will work for Safari browser
		driver.get("https://jqueryui.com//"); //Chrome, Firefox, Edge, Safari //Sending command, launching url
		
		driver.findElement(By.xpath("//a[text()='Droppable']")).click();
		
		WebElement mouseHoverEle = driver.findElement(By.xpath("//a[text()='Contribute']"));
		Actions actions1 = new Actions(driver);
		//driver.switchTo().defaultContent();		
		actions1.moveToElement(mouseHoverEle);
		//actions1.contextClick(); //right click
		Action act1 = actions1.build();
		act1.perform();
				
		WebElement frameEle = driver.findElement(By.xpath("//iframe[@class='demo-frame']"));
		driver.switchTo().frame(frameEle);
		
		WebElement sourceEle = driver.findElement(By.xpath("//div[@id='draggable']"));
		WebElement targetEle = driver.findElement(By.xpath("//div[@id='droppable']"));
		
		
		Actions actions2 = new Actions(driver);
		//driver.switchTo().frame(frameEle);
		actions2.dragAndDrop(sourceEle, targetEle);
		//driver.switchTo().defaultContent();			
		Action act2 = actions2.build();
		act2.perform();
	}
	
	@Test
	public void pressKeyboardKey() //opening new tab
	{
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe"); //Server layer
		WebDriver driver = new ChromeDriver(); //API layer, launch browser
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		//driver.manage().window().fullscreen(); //It will maximize window, will work for Safari browser
		driver.get("https://jqueryui.com//");
		
		Actions actions = new Actions(driver);
		actions.keyDown(Keys.CONTROL).sendKeys("t").keyUp(Keys.CONTROL);
		Action act = actions.build();
		act.perform();
		
		//Explicit wait
		WebDriverWait webWait = new WebDriverWait(driver, 10);
		//WebDriverWait webWait = new WebDriverWait(driver, Duration.ofSeconds(10)); //selenium 4 code
		webWait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//a[text()='Draggable']"))));
		
	}
}
