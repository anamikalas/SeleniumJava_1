package object_repository;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OpenAGenericRequest_Page
{
	public WebDriver driver;
	
	public OpenAGenericRequest_Page(WebDriver webDriver)
	{
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this);
	}
	
	
	@FindBy(xpath = "//iframe[@id='gsft_main']") private WebElement eleLoginiFrame;
	public void switchiFrame()
	{
		driver.switchTo().frame(eleLoginiFrame);
	}
	
	@FindBy(xpath = "//input[@id='user_name']") private WebElement eleUserName;
	public void setUserName(String strUNm)
	{
		eleUserName.sendKeys(strUNm);
	}
	
	@FindBy(xpath = "//input[@id='user_password']") private WebElement elePassword;
	public void setPassword(String strPwd)
	{
		elePassword.sendKeys(strPwd);
	}
	
	@FindBy(xpath = "//button[@id='sysverb_login']") private WebElement eleLoginBtn;
	public void clickLoginBtn()
	{
		eleLoginBtn.click();
	}
	
	@FindBy(xpath = "//input[@id='email_factor']") private WebElement eleCheckBoxGetvalidationCode;
	public void checkCheckBox()
	{
		//eleCheckBoxGetvalidationCode.click();
		((JavascriptExecutor)driver).executeScript("arguments[0].click();", eleCheckBoxGetvalidationCode);
	}
	
	@FindBy(xpath = "//button[@id='continue']") private WebElement eleContinueBtn;
	public void clickContinueBtn()
	{
		eleContinueBtn.click();
	}
	
	@FindBy(xpath = "//input[@name='loginfmt']") private WebElement eleOutlookEmail;
	public void setOutlookEmail(String strOutlookEmail)
	{
		eleOutlookEmail.sendKeys(strOutlookEmail);
	}
	
	@FindBy(xpath = "//input[@id='idSIButton9']") private WebElement eleOutlookNextBtn;
	public void clickOutlookNextBtn()
	{
		eleOutlookNextBtn.click();
	}
	
	
	
	@FindBy(xpath = "//input[@name='passwd']") private WebElement eleOutlookPwd;
	public void setOutlookPwd(String strPwd)
	{
		eleOutlookPwd.sendKeys(strPwd);
	}
	
	@FindBy(xpath = "//input[@id='idSIButton9']") private WebElement eleSignInBtn;
	public void clickOutlookSignInBtn()
	{
		eleSignInBtn.click();
	}
	
	@FindBy(xpath = "//span[text()='Folders']/following::div[@draggable='true']/div[contains(@title,'Drafts')]") private WebElement eleDraftFolder;
	public void clickOnDraftFolder()
	{
		eleDraftFolder.click();
	}
	
	@FindBy(xpath = "//span[text()='Folders']/following::div[@draggable='true']/div[contains(@title,'Inbox')]") private WebElement eleOutlookInbox;
	public void clickOutlookInbox()
	{
		eleOutlookInbox.click();
	}
	
	@FindBy(xpath = "//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)']") private WebElement eleOutlookMultiFactor;
	public void clickOutlookMultifactor()
	{
		eleOutlookMultiFactor.click();
	}
	
	@FindBy(xpath = "//div[@id='UniqueMessageBody']//div/div/div/pre[1]") private WebElement eleOutlookmailBody;
	public String getOutlookMailBodyText()
	{
		String str = eleOutlookmailBody.getText();
		return str;
	}
	
	@FindBy(xpath = "//div[@class='XG5Jd WNvBZ TBtad q0f8X XW8cf']//div/input") private WebElement eleCheckBoxOutlook;
	public void selectCheckBoxAutheticationMail()
	{
		//eleCheckBoxOutlook.click();
		((JavascriptExecutor)driver).executeScript("arguments[0].click();", eleCheckBoxOutlook);
	}
	
	@FindBy(xpath = "//div[@aria-label='Delete']/span/button") private WebElement eleDeleteOutlook;
	public void clickDeleteIconOutlook()
	{
		//eleDeleteOutlook.click();
		((JavascriptExecutor)driver).executeScript("arguments[0].click()", eleDeleteOutlook);
	}
	
	@FindBy(xpath = "//input[@id='txtResponse_email']") private WebElement eleTxt6DigitVerficationCode;
	public void set6DigitVerficationCode(String str6DiditCode)
	{
		eleTxt6DigitVerficationCode.sendKeys(str6DiditCode);
	}
	
	@FindBy(xpath = "(//button[@id='sysverb_validate_mfa_code'])[2]") private WebElement eleVerifyBtn;
	public void clickVerifyBtn()
	{
		eleVerifyBtn.click();
	}
	
	@FindBy(xpath = "//div[contains(text(),'Contact us')]") private WebElement eleFooterContactusBtn;
	public void clickFooterContactUs()
	{
		eleFooterContactusBtn.click();
	}
	
	@FindBy(xpath = "(//div[contains(text(),'Open a Service Request')])[2]") private WebElement eleFooterOpenAServiceReqLink;
	public void clickFooterOpenAServiceReqLink()
	{
		eleFooterOpenAServiceReqLink.click();
		//((JavascriptExecutor)driver).executeAsyncScript("arguments[0].click();", eleFooterOpenAServiceReqLink);
	}
	
	@FindBy(xpath = "(//input[@placeholder='Search Request Topic'])[1]") private WebElement eleSearchReqTopicTextBox;
	public void setSearchRequestTopic(String strSearchReqTopic)
	{
		eleSearchReqTopicTextBox.sendKeys(strSearchReqTopic);
	}
	
	@FindBy(xpath = "(//strong[text()='Software'])[1]") private WebElement eleCategpryNameLink;
	public void clickCategoryName()
	{
		eleCategpryNameLink.click();
	}
	
	@FindBy(xpath = "(//a[text()='Open a Generic Request'])[3]") private WebElement eleOpenAGenericReqLink1;
	public void scrollToOpenAGenericRequest()
	{
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();",eleOpenAGenericReqLink1);
	}
	
	@FindBy(xpath = "(//a[text()='Open a Generic Request'])[3]") private WebElement eleOpenAGenericReqLink2;
	public void clickOpenAGenericReqLink()
	{
		eleOpenAGenericReqLink2.click();
	}
	
	@FindBy(xpath = "//div[@class='main not-display']/div[contains(text(),'Open Generic Request')]") private WebElement elePageHeader;
	public String getPageHeader()
	{
		return elePageHeader.getText();
	}
	
	@FindBy(xpath = "//textarea[@id='sp_formfield_description']") private WebElement eleDescribeyourIssueTextArea;
	public void setDescribeYourIssue(String strDescribeUrIssue)
	{
		eleDescribeyourIssueTextArea.sendKeys(strDescribeUrIssue);
	}
	
	@FindBy(xpath = "//div[@aria-label='Forms and Knowledge Results']") private WebElement eleFormsAndKnowledgeResultsDiv;
	public void verifyVisibilityOfFormsAndKnowledgeResultsDiv()
	{
		eleFormsAndKnowledgeResultsDiv.isDisplayed();
	}
	
	@FindBy(xpath = "//div[@id='s2id_sp_formfield_u_select_application']") private WebElement eleScrollSelectTheApplicationDDL;
	public void scrollToSelectTheApplicationDDL()
	{
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();", eleScrollSelectTheApplicationDDL);
	}
	
	@FindBy(xpath = "//div[@id='s2id_sp_formfield_u_select_application']") private WebElement eleSelectTheApplicationDiv; 
	public void clickSelectTheApplicationDDL()
	{
		eleSelectTheApplicationDiv.click();
	}
	
	@FindBy(xpath = "//span[text()='Click or Drag to add']") private WebElement eleAttachments;
	public void scrollToAttachments()
	{
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();", eleAttachments);
	}
	
	@FindBy(xpath = "//span[text()='Click or Drag to add']") private WebElement eleClickOrDragLink;
	public void clickOnClickOrDrag()
	{
		eleClickOrDragLink.click();
	}
	
	@FindBy(xpath = "//button[text()='Submit Request']") private WebElement eleSubmitRequestBtn1;
	public void scrollToSubmitRequestBtn()
	{
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();", eleSubmitRequestBtn1);
	}
	
	@FindBy(xpath = "//button[text()='Submit Request']") private WebElement eleSubmitRequestBtn2;
	public void clickSubmitRequestBtn()
	{
		eleSubmitRequestBtn2.click();
	}
}
