package object_repository;

import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class CreateKnowledgeArticle_Page 
{
	public WebDriver driver;
	
	public CreateKnowledgeArticle_Page(WebDriver webDriver)
	{
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this);
	}
	
	
	@FindBy(xpath = "//iframe[@id='gsft_main']") private WebElement eleLoginiFrame;
	public void switchiFrame()
	{
		driver.switchTo().frame(eleLoginiFrame);
	}
	
	@FindBy(xpath = "//input[@id='user_name']") private WebElement eleUserName;
	public void setUserName(String strUNm)
	{
		eleUserName.sendKeys(strUNm);
	}
	
	@FindBy(xpath = "//input[@id='user_password']") private WebElement elePassword;
	public void setPassword(String strPwd)
	{
		elePassword.sendKeys(strPwd);
	}
	
	@FindBy(xpath = "//button[@id='sysverb_login']") private WebElement eleLoginBtn;
	public void clickLoginBtn()
	{
		eleLoginBtn.click();
	}
	
	@FindBy(xpath = "//input[@id='email_factor']") private WebElement eleCheckBoxGetvalidationCode;
	public void checkCheckBox()
	{
		//eleCheckBoxGetvalidationCode.click();
		((JavascriptExecutor)driver).executeScript("arguments[0].click();", eleCheckBoxGetvalidationCode);
	}
	
	@FindBy(xpath = "//button[@id='continue']") private WebElement eleContinueBtn;
	public void clickContinueBtn()
	{
		eleContinueBtn.click();
	}
	
	/*@FindBy(xpath = "//input[@id='tbUserName']") private WebElement eleOutlookUserName;
	public void setOutlookUserName(String strOLUNm)
	{
		eleOutlookUserName.sendKeys(strOLUNm);
	}
	
	@FindBy(xpath = "//input[@id='bOK']") private WebElement eleOutlookOkBtn;
	public void clickOutlookOkButton()
	{
		eleOutlookOkBtn.click();
	}*/
	
	@FindBy(xpath = "//input[@name='loginfmt']") private WebElement eleOutlookEmail;
	public void setOutlookEmail(String strOutlookEmail)
	{
		eleOutlookEmail.sendKeys(strOutlookEmail);
	}
	
	@FindBy(xpath = "//input[@id='idSIButton9']") private WebElement eleOutlookNextBtn;
	public void clickOutlookNextBtn()
	{
		eleOutlookNextBtn.click();
	}
	
	@FindBy(xpath = "//input[@name='passwd']") private WebElement eleOutlookPwd;
	public void setOutlookPwd(String strPwd)
	{
		eleOutlookPwd.sendKeys(strPwd);
	}
	
	@FindBy(xpath = "Outlook_Pwd") private WebElement eleSignInBtn;
	public void clickOutlookSignInBtn()
	{
		eleSignInBtn.click();
	}
	
	@FindBy(xpath = "//span[text()='Folders']/following::div[@draggable='true']/div[contains(@title,'Drafts')]") private WebElement eleDraftFolder;
	public void clickOnDraftFolder()
	{
		eleDraftFolder.click();
	}
	
	@FindBy(xpath = "//span[text()='Folders']/following::div[@draggable='true']/div[contains(@title,'Inbox')]") private WebElement eleOutlookInbox;
	public void clickOutlookInbox()
	{
		eleOutlookInbox.click();
	}
	
	@FindBy(xpath = "(//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)'])[1]") private WebElement eleOutlookMultiFactor;
	public void clickOutlookMultifactor()
	{
		eleOutlookMultiFactor.click();
	}
	
	@FindBy(xpath = "//div[@id='UniqueMessageBody_1']//div/div/div/pre[1]") private WebElement eleOutlookmailBody;
	public String getOutlookMailBodyText()
	{
		String str = eleOutlookmailBody.getText();
		return str;
	}
	
	@FindBy(xpath = "//div[@aria-label='Delete']/span/button[1]") private WebElement eleDeleteIconOutlook1;
	public void clickDeleteIconOutlook1()
	{
		//eleDeleteIconOutlook1.click();
		//((JavascriptExecutor)driver).executeScript("arguments[0].click()", eleDeleteIconOutlook1);
		/*Actions actns = new Actions(driver);
		actns.moveToElement(eleDeleteIconOutlook1).click().build().perform();*/
	}
	
	@FindBy(xpath = "(//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)'])[1]") 
	private WebElement eleHoverOnMail;
	@FindBy(xpath = "(//div[@class='QpoLy'])[1]") 
	private WebElement eleDeleteIcon;
	public void clickDeleteIconOutlook2()
	{
		Actions actns = new Actions(driver);
		actns.moveToElement(eleHoverOnMail).click(eleDeleteIcon).build().perform();
	}
	
	@FindBy(xpath = "//input[@id='txtResponse_email']") private WebElement eleTxt6DigitVerficationCode;
	public void set6DigitVerficationCode(String str6DiditCode)
	{
		eleTxt6DigitVerficationCode.sendKeys(str6DiditCode);
	}
	
	@FindBy(xpath = "(//button[@id='sysverb_validate_mfa_code'])[2]") private WebElement eleVerifyBtn;
	public void clickVerifyBtn()
	{
		eleVerifyBtn.click();
	}
	
	//create KB article*******************************************************************************************************************************************************************************************
	
	@FindBy(xpath = "//input[@id='filter']") private WebElement eleFilterNavigatorTextBox;
	public void setKnowledgeOnFilterNavigatorTextBox(String strKnowledge)
	{
		eleFilterNavigatorTextBox.sendKeys(strKnowledge);
	}
	
	@FindBy(xpath = "//div[text()='All Articles']") private WebElement eleTableNameAllArtclesLink;
	public void clickTableNameAllArticles()
	{
		eleTableNameAllArtclesLink.click();
	}
	
	@FindBy(xpath = "//iframe[@id='gsft_main']") private WebElement eleiFrameKB;
	public void switchiFrameKB()
	{
		driver.switchTo().frame(eleiFrameKB);
	}
	
	@FindBy(xpath = "//button[@id='sysverb_new']") private WebElement eleNewBtn;
	public void clickNewBtn()
	{
		eleNewBtn.click();
	}
	
	@FindBy(xpath = "//input[@id='sys_readonly.kb_knowledge.number']") private WebElement eleKBNoTextBox;
	public String getKBNumber()
	{
		String strKBNo = eleKBNoTextBox.getAttribute("value");
		return strKBNo;
	}
	
	@FindBy(xpath = "//button[@id='lookup.kb_knowledge.kb_knowledge_base']") private WebElement eleKnowledgeBaseMG;
	public void clickKnowledgeBaseMG()
	{
		eleKnowledgeBaseMG.click();
	}
	
	@FindBy(xpath = "//input[@id='kb_knowledge_base_table_header_search_control']") private WebElement eleKBTitleTextBox;
	public void setKnowledgeBaseTextBox(String strKBTitle)
	{
		eleKBTitleTextBox.sendKeys(strKBTitle);
	}
	
	
	public void sendKBTitleEnter()
	{
		Actions actns = new Actions(driver);
		actns.keyDown(Keys.ENTER).keyUp(Keys.RETURN).build().perform();
	}
	
	@FindBy(xpath = "//table[@id='kb_knowledge_base_table']/tbody/tr[1]/td[3]/a[1]") private WebElement eleKnowledgeBaseHR;
	public void clickKnowledgeBaseHR()
	{
		eleKnowledgeBaseHR.click();
	}
	
	@FindBy(xpath = "//input[@id='kb_knowledge.kb_knowledge_base']") private WebElement eleKnowledgeBaseTextBox;
	public String getAndVerifyKnowledgeBase()
	{
		String strKnowledgebaseName = eleKnowledgeBaseTextBox.getAttribute("value");
		return strKnowledgebaseName;
	}
	
	@FindBy(xpath = "//button[@id='lookup.kb_knowledge.u_service_category']") private WebElement eleServiceCategoryMG;
	public void clickServiceCategoryMG()
	{
		eleServiceCategoryMG.click();
	}
	
	@FindBy(xpath = "//table[@id='sc_category_table']/tbody/tr[1]/td[3]") private WebElement eleServiceCategory;
	public void clickServiceCategory()
	{
		eleServiceCategory.click();
	}
	
	/*@FindBy(xpath = "//select[@id='kb_knowledge.u_article_type']") private WebElement eleArticleType;
	public void SelectArticleType()
	{
		Select selDDL = new Select(eleArticleType);
		List<WebElement> eleLst = selDDL.getOptions();
		for(WebElement ele : eleLst)
		{
			if(ele.getText().contains(""))
				ele.click();
				
		}
	}*/
	
	@FindBy(xpath = "//select[@id='kb_knowledge.u_article_type']") private WebElement eleArticleTypeDDL;
	public void selectArticleTypeFromDDL()
	{
		Select selDDL = new Select(eleArticleTypeDDL);
		selDDL.selectByIndex(1);
	}
	
	@FindBy(xpath = "(//button[@id='kb_knowledge.sys_updated_on.ui_policy_sensitive'])[2]") private WebElement eleUpdatedDateIcon;
	public void clickUpdatedDateIcon()
	{
		eleUpdatedDateIcon.click();
	}
	
	@FindBy(xpath = "//textarea[@id='kb_knowledge.short_description']") private WebElement eleShortDesctextArea;
	public void setShortDescription(String strShortDesc)
	{
		eleShortDesctextArea.sendKeys(strShortDesc);
	}
	
	@FindBy(xpath = "//select[@id='kb_knowledge.workflow_state']") private WebElement eleWorkflowDraftSelect;
	public String verifyWokflowIsDraft()
	{
		Select selDDL = new Select(eleWorkflowDraftSelect);
		String strWorkflow =  selDDL.getFirstSelectedOption().getText();
		return strWorkflow;
	}
	
	@FindBy(xpath = "//input[@id='ni.kb_knowledge.u_rejected']") private WebElement eleRejectedCheckBox;
	public boolean verifyRejectedIsFalse()	
	{
		return eleRejectedCheckBox.isEnabled();
	}
	
	@FindBy(xpath = "//iframe[@id='AC.kb_knowledge.u_service_category_shim']") private WebElement eleiFrameCalendar;
	public void switchiFrameCalendar()
	{
		driver.switchTo().frame(eleiFrameCalendar);
	}
	
	@FindBy(xpath = "//textarea[@id='kb_knowledge.meta']") private WebElement eleMetaTextarea;
	public void clickMetaTextarea()
	{
		eleMetaTextarea.click();
	}
	
	@FindBy(xpath = "//span[@class='navbar_ui_actions']/button[text()='Save']") private WebElement eleSaveBtn;
	public void clickSaveButton()
	{
		eleSaveBtn.click();
	}
	
	@FindBy(xpath = "//select[@id='kb_knowledge.workflow_state']") private WebElement eleWorkflowDraftTextBox;
	public String getWorkflowReview()
	{
		Select selDDL = new Select(eleWorkflowDraftTextBox);
		return selDDL.getFirstSelectedOption().getText();
	}
	
	@FindBy(xpath = "//span[@class='navbar_ui_actions']/button[text()='Submit to Review']") private WebElement eleSubmitToReviewBtn;
	public void clickSubmitToReviewBtn()
	{
		eleSubmitToReviewBtn.click();
	}

}
