package object_repository;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class VerifyCreatedRITM_Page 
{
	public WebDriver driver;
	
	public VerifyCreatedRITM_Page(WebDriver webDriver)
	{
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this);
	}
	
	
	@FindBy(xpath = "//iframe[@id='gsft_main']") private WebElement eleLoginiFrame;
	public void switchiFrame()
	{
		driver.switchTo().frame(eleLoginiFrame);
	}
	
	@FindBy(xpath = "//input[@id='user_name']") private WebElement eleUserName;
	public void setUserName(String strUNm)
	{
		eleUserName.sendKeys(strUNm);
	}
	
	@FindBy(xpath = "//input[@id='user_password']") private WebElement elePassword;
	public void setPassword(String strPwd)
	{
		elePassword.sendKeys(strPwd);
	}
	
	@FindBy(xpath = "//button[@id='sysverb_login']") private WebElement eleLoginBtn;
	public void clickLoginBtn()
	{
		eleLoginBtn.click();
	}
	
	@FindBy(xpath = "//input[@id='email_factor']") private WebElement eleCheckBoxGetvalidationCode;
	public void checkCheckBox()
	{
		//eleCheckBoxGetvalidationCode.click();
		((JavascriptExecutor)driver).executeScript("arguments[0].click();", eleCheckBoxGetvalidationCode);
	}
	
	@FindBy(xpath = "//button[@id='continue']") private WebElement eleContinueBtn;
	public void clickContinueBtn()
	{
		eleContinueBtn.click();
	}
	
	/*@FindBy(xpath = "//input[@id='tbUserName']") private WebElement eleOutlookUserName;
	public void setOutlookUserName(String strOLUNm)
	{
		eleOutlookUserName.sendKeys(strOLUNm);
	}
	
	@FindBy(xpath = "//input[@id='bOK']") private WebElement eleOutlookOkBtn;
	public void clickOutlookOkButton()
	{
		eleOutlookOkBtn.click();
	}*/
	
	@FindBy(xpath = "//input[@name='loginfmt']") private WebElement eleOutlookEmail;
	public void setOutlookEmail(String strOutlookEmail)
	{
		eleOutlookEmail.sendKeys(strOutlookEmail);
	}
	
	@FindBy(xpath = "//input[@id='idSIButton9']") private WebElement eleOutlookNextBtn;
	public void clickOutlookNextBtn()
	{
		eleOutlookNextBtn.click();
	}
	
	@FindBy(xpath = "//input[@name='passwd']") private WebElement eleOutlookPwd;
	public void setOutlookPwd(String strPwd)
	{
		eleOutlookPwd.sendKeys(strPwd);
	}
	
	@FindBy(xpath = "Outlook_Pwd") private WebElement eleSignInBtn;
	public void clickOutlookSignInBtn()
	{
		eleSignInBtn.click();
	}
	
	@FindBy(xpath = "//span[text()='Folders']/following::div[@draggable='true']/div[contains(@title,'Drafts')]") private WebElement eleDraftFolder;
	public void clickOnDraftFolder()
	{
		eleDraftFolder.click();
	}
	
	@FindBy(xpath = "//span[text()='Folders']/following::div[@draggable='true']/div[contains(@title,'Inbox')]") private WebElement eleOutlookInbox;
	public void clickOutlookInbox()
	{
		eleOutlookInbox.click();
	}
	
	@FindBy(xpath = "(//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)'])[1]") private WebElement eleOutlookMultiFactor;
	public void clickOutlookMultifactor()
	{
		eleOutlookMultiFactor.click();
	}
	
	@FindBy(xpath = "//div[@id='UniqueMessageBody_1']//div/div/div/pre[1]") private WebElement eleOutlookmailBody;
	public String getOutlookMailBodyText()
	{
		String str = eleOutlookmailBody.getText();
		return str;
	}
	
	@FindBy(xpath = "//div[@aria-label='Delete']/span/button[1]") private WebElement eleDeleteIconOutlook1;
	public void clickDeleteIconOutlook1()
	{
		//eleDeleteIconOutlook1.click();
		//((JavascriptExecutor)driver).executeScript("arguments[0].click()", eleDeleteIconOutlook1);
		/*Actions actns = new Actions(driver);
		actns.moveToElement(eleDeleteIconOutlook1).click().build().perform();*/
	}
	
	@FindBy(xpath = "(//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)'])[1]") 
	private WebElement eleHoverOnMail;
	@FindBy(xpath = "(//div[@class='QpoLy'])[1]") 
	private WebElement eleDeleteIcon;
	public void clickDeleteIconOutlook2()
	{
		Actions actns = new Actions(driver);
		actns.moveToElement(eleHoverOnMail).click(eleDeleteIcon).build().perform();
	}
	
	@FindBy(xpath = "//input[@id='txtResponse_email']") private WebElement eleTxt6DigitVerficationCode;
	public void set6DigitVerficationCode(String str6DiditCode)
	{
		eleTxt6DigitVerficationCode.sendKeys(str6DiditCode);
	}
	
	@FindBy(xpath = "(//button[@id='sysverb_validate_mfa_code'])[2]") private WebElement eleVerifyBtn;
	public void clickVerifyBtn()
	{
		eleVerifyBtn.click();
	}
	
	@FindBy(xpath = "//input[@id='filter']") private WebElement eleFilterNavigatorTxtBox;
	public void setTableNameOnFilterNavigator(String strTableName)
	{
		eleFilterNavigatorTxtBox.sendKeys(strTableName);
	}
	
	@FindBy(xpath = "//div[text()='All Requested Items']") private WebElement eleTablenameLink;
	public void clickOnTableName()
	{
		eleTablenameLink.click();
	}
	
	@FindBy(xpath = "//iframe[@id='gsft_main']") private WebElement eleIFrame;
	public void switchToFrame()
	{
		driver.switchTo().frame(eleIFrame);
	}
	
	@FindBy(xpath = "(//td[@name='number']/div/div/div/input[1])[1]") private WebElement eleRITMInputBox;
	public void setRITMNumberOnInputBox(String strRITMNo)
	{
		eleRITMInputBox.sendKeys(strRITMNo);
	}	
	
	public void sendEnterRITMTxtBox()
	{
		Actions actns = new Actions(driver);
		actns.keyDown(Keys.CONTROL).sendKeys(Keys.ENTER).keyUp(Keys.CONTROL).build().perform();
	}
	
	@FindBy(xpath = "//a[contains(@aria-label,'Preview record:')]") private WebElement elePreviewBtn;
	public void clickPreviewBtn()
	{
		elePreviewBtn.click();
	}
	
	@FindBy(xpath = "//a[text()='Open Record']") private WebElement eleOpenRecordBtn;
	public void clickOpenRecordBtn()
	{
		eleOpenRecordBtn.click();
	}
	
	@FindBy(xpath = "//input[@id='sc_req_item.cat_item_label']") private WebElement eleItemTextBox;
	public String getItem()
	{
		String strItem = eleItemTextBox.getText();
		return strItem;
	}
	
	@FindBy(xpath = "//textarea[@id='sys_readonly.sc_req_item.u_questionnaire']") private WebElement eleBusinessUnitTextarea;
	public String getBusinessUnit()
	{
		String strBU = eleBusinessUnitTextarea.getText();
		return strBU;
	}
	
	@FindBy(xpath = "//span[contains(text(),'Catalog Tasks')]") private WebElement eleCatalogTaskTab1;
	public void scrollToCatalogTaskTab()
	{
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();", eleCatalogTaskTab1);
	}
	
	@FindBy(xpath = "//span[contains(text(),'Catalog Tasks')]") private WebElement eleCatalogTaskTab2;
	public void clickCatalogTaskTab()
	{
		eleCatalogTaskTab2.click();
	}
	
	@FindBy(xpath = "(//a[contains(text(),'TASK')])[1]") private WebElement eleTaskNoLink;
	public void openTaskRightClick()
	{
		Actions actns = new Actions(driver);
		actns.keyDown(Keys.CONTROL).click(eleTaskNoLink).build().perform();
	}
	
	@FindBy(xpath = "//span[@class='navbar_ui_actions']/button[text()='Take over']") private WebElement eleTakeOverBtn; 
	public void clickTakeOverBtn()
	{
		eleTakeOverBtn.click();
	}
	
	@FindBy(xpath = "//select[@id='sc_task.state']") private WebElement eleStateDDL;
	public void selectStateAwaitingUserInfo()
	{
		Select selDDL = new Select(eleStateDDL);
		selDDL.selectByVisibleText("Awaiting User Info");
	}
	
	@FindBy(xpath = "//span[@class='navbar_ui_actions']/button[text()='Save']") private WebElement eleSaveBtn;
	public void clickSaveBtn()
	{
		eleSaveBtn.click();
	}
	
	@FindBy(xpath = "//select[@id='sc_task.state']") private WebElement eleStateDDLAwaitingUserInfo;
	public String getStateDDL()
	{
		Select selDDLState = new Select(eleStateDDLAwaitingUserInfo);
		String strState = selDDLState.getFirstSelectedOption().getText();
		return strState;
	}
	
	@FindBy(xpath = "//label[@id='label.ni.sc_req_item.u_awaiting_user_info']") private WebElement eleCheckBox;
	public boolean verifyCheckBoxIsReadOnly()
	{
		boolean isBoolean = eleCheckBox.isEnabled();
		return isBoolean;
	}
	
	@FindBy(xpath = "//button[@id='header_add_attachment']") private WebElement clickAttachmentIcon;
	public void clickAttachmentIcon()
	{
		clickAttachmentIcon.click();
	}
	
	@FindBy(xpath = "//input[@id='loadFileXml']") private WebElement eleChooseFileBtn;
	public void clickChooseFileBtn()
	{
		eleChooseFileBtn.click();
	}
	
	@FindBy(xpath = "//button[@id='attachment_closemodal']") private WebElement eleXBtn;
	public void clickXBtn()
	{
		eleXBtn.click();
	}
	
	@FindBy(xpath = "//a[@id='header_attachment_list_label']") private WebElement eleVerifyAttachments;
	public boolean verifyAttachmentGotAttached()
	{
		boolean isAttached = eleVerifyAttachments.isDisplayed();
		return isAttached;
	}
}
