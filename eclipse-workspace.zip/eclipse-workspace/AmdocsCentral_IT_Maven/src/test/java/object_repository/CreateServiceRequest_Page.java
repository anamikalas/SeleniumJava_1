package object_repository;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.FileOperation_IT;

public class CreateServiceRequest_Page 
{
	public WebDriver driver;
	FileOperation_IT objF = new FileOperation_IT();
	
	public CreateServiceRequest_Page(WebDriver webDriver)
	{
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this);
	}
	
	@FindBy(xpath = "//iframe[@id='gsft_main']") private WebElement eleLoginiFrame;
	public void switchiFrame()
	{
		driver.switchTo().frame(eleLoginiFrame);
	}
	
	@FindBy(xpath = "//input[@id='user_name']") private WebElement eleUserName;
	public void setUserName(String strUNm)
	{
		eleUserName.sendKeys(strUNm);
	}
	
	@FindBy(xpath = "//input[@id='user_password']") private WebElement elePassword;
	public void setPassword(String strPwd)
	{
		elePassword.sendKeys(strPwd);
	}
	
	@FindBy(xpath = "//button[@id='sysverb_login']") private WebElement eleLoginBtn;
	public void clickLoginBtn()
	{
		eleLoginBtn.click();
	}
	
	@FindBy(xpath = "//input[@id='email_factor']") private WebElement eleCheckBoxGetvalidationCode;
	public void checkCheckBox()
	{
		//eleCheckBoxGetvalidationCode.click();
		((JavascriptExecutor)driver).executeScript("arguments[0].click();", eleCheckBoxGetvalidationCode);
	}
	
	@FindBy(xpath = "//button[@id='continue']") private WebElement eleContinueBtn;
	public void clickContinueBtn()
	{
		eleContinueBtn.click();
	}
	
	/*@FindBy(xpath = "//input[@id='tbUserName']") private WebElement eleOutlookUserName;
	public void setOutlookUserName(String strOLUNm)
	{
		eleOutlookUserName.sendKeys(strOLUNm);
	}
	
	@FindBy(xpath = "//input[@id='bOK']") private WebElement eleOutlookOkBtn;
	public void clickOutlookOkButton()
	{
		eleOutlookOkBtn.click();
	}*/
	
	@FindBy(xpath = "//input[@name='loginfmt']") private WebElement eleOutlookEmail;
	public void setOutlookEmail(String strOutlookEmail)
	{
		eleOutlookEmail.sendKeys(strOutlookEmail);
	}
	
	@FindBy(xpath = "//input[@id='idSIButton9']") private WebElement eleOutlookNextBtn;
	public void clickOutlookNextBtn()
	{
		eleOutlookNextBtn.click();
	}
	
	@FindBy(xpath = "//input[@name='passwd']") private WebElement eleOutlookPwd;
	public void setOutlookPwd(String strPwd)
	{
		eleOutlookPwd.sendKeys(strPwd);
	}
	
	@FindBy(xpath = "Outlook_Pwd") private WebElement eleSignInBtn;
	public void clickOutlookSignInBtn()
	{
		eleSignInBtn.click();
	}
	
	@FindBy(xpath = "//span[text()='Folders']/following::div[@draggable='true']/div[contains(@title,'Drafts')]") private WebElement eleDraftFolder;
	public void clickOnDraftFolder()
	{
		eleDraftFolder.click();
	}
	
	@FindBy(xpath = "//span[text()='Folders']/following::div[@draggable='true']/div[contains(@title,'Inbox')]") private WebElement eleOutlookInbox;
	public void clickOutlookInbox()
	{
		eleOutlookInbox.click();
	}
	
	@FindBy(xpath = "//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)']") private WebElement eleOutlookMultiFactor;
	public void clickOutlookMultifactor()
	{
		eleOutlookMultiFactor.click();
	}
	
	@FindBy(xpath = "//div[@aria-label='Message body']//div/div/div/pre[1]") private WebElement eleOutlookmailBody;
	public String getOutlookMailBodyText()
	{
		String str = eleOutlookmailBody.getText();
		return str;
	}
	
	@FindBy(xpath = "//div[@aria-label='Delete']/span/button[1]") private WebElement eleDeleteOutlook;
	public void clickDeleteIconOutlook()
	{
		//eleDeleteOutlook.click();
		((JavascriptExecutor)driver).executeScript("arguments[0].click()", eleDeleteOutlook);
	}
	
	@FindBy(xpath = "//input[@id='txtResponse_email']") private WebElement eleTxt6DigitVerficationCode;
	public void set6DigitVerficationCode(String str6DiditCode)
	{
		eleTxt6DigitVerficationCode.sendKeys(str6DiditCode);
	}
	
	@FindBy(xpath = "(//button[@id='sysverb_validate_mfa_code'])[2]") private WebElement eleVerifyBtn;
	public void clickVerifyBtn()
	{
		eleVerifyBtn.click();
	}
	
	@FindBy(xpath = "//div[@uib-popover='Accounts & Permissions']") private WebElement eleAccountsAndPermissions;
	public void scrollToCatagoryAccountsAndPermissions()
	{
		//((JavascriptExecutor)driver).executeScript("window.scrollBy(0,document.body.scrollHeight)");
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();", eleAccountsAndPermissions);
	}
	
	@FindBy(xpath = "//div[@class='row item-list']//div/a[1]") private WebElement eleDivAccountsAndPermissions;
	public void clickAccountsAndPermissions()
	{
		eleDivAccountsAndPermissions.click();
	}
	
	@FindBy(xpath = "//div[@id='s2id_sp_formfield_u_sensitive_data']/a/span[1]") private WebElement eleDDLHighlySensitiveData;
	public void clickDDlHighlySensitiveData()
	{
		eleDDLHighlySensitiveData.click();
		//((JavascriptExecutor)driver).executeScript("arguments[0].click();", eleDDLHighlySensitiveData);
		//((Actions)driver).moveToElement(eleAccountsAndPermissions).click().build().perform();
	}
	
	@FindBy(xpath = "//div[@id='select2-drop']/ul/li[3]") private WebElement eleYesHighlySensitiveData;
	public void clickYes()
	{
		eleYesHighlySensitiveData.click();
	}
	
	@FindBy(xpath = "//div[@id='s2id_sp_formfield_u_business_unit']/a/span[1]") private WebElement eleDDLBusinessUnit;
	public void clickDDlBusinessUnit()
	{
		eleDDLBusinessUnit.click();
	}
	
	@FindBy(xpath = "//div[@id='s2id_sp_formfield_u_what_will_be_the_location_of_the_share_folder']/a/span[text()='-- None --']") private WebElement eleShareFolderLoc1;
	public void clickLocationOfShareFolder()
	{
		eleShareFolderLoc1.click();
		//((JavascriptExecutor)driver).executeScript("arguments[0].click();", eleLocationOfShareFolder);
	}
	
	@FindBy(xpath = "//label[text()='What will be the location of the share folder?']/following-sibling::input[1]") private WebElement eleShareFolderLoc2;
	public void setShareFolderLocInTextBox(String strShareFolderLoc)
	{
		eleShareFolderLoc2.sendKeys(strShareFolderLoc);
	}
	
	@FindBy(xpath = "//input[@id='sp_formfield_msq_share_name']") private WebElement eleShareName;
	public void setShareName(String strShareName)
	{
		eleShareName.sendKeys("Folder Name- Abc");
	}
	
	@FindBy(xpath = "//textarea[@id='sp_formfield_u_additional_information']") private WebElement eleAdditionalInformation;
	public void setAdditionalInformation(String strAdditionalInfo)
	{
		eleAdditionalInformation.sendKeys(strAdditionalInfo);
	}
	
	@FindBy(xpath = "//span[text()='Click or Drag to add']") private WebElement eleClickOrDragToAddBtn;
	public void clickClickOrDragToAddBtn()
	{
		eleClickOrDragToAddBtn.click();
	}
	
	@FindBy(xpath = "//button[text()='Submit Request']") private WebElement eleSubmitBtn;
	public void clickSubmitBtn()
	{
		eleSubmitBtn.click();
	}
	
	@FindBy(xpath = "//a[text()='Track your request']") private WebElement eleTrackYourRequestText;
	public String getTrackYourRequestText()
	{
		return eleTrackYourRequestText.getText();
	}
	
	@FindBy(xpath = "//a[text()='Track your request']") private WebElement eleTrackYourRequestLink;
	public void clickTrackYourRequestLink()
	{
		eleTrackYourRequestLink.click();
	}
	
	
}
