package test_script;

import java.io.File;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import object_repository.CreateServiceRequest_Page;
import object_repository.HomePageSearch_Page;
import object_repository.OpenAGenericRequest_Page;
import utilities.FileOperation_IT;

import org.testng.Assert;
import org.testng.annotations.*;

public class OpenAGenericRequest_Test extends BaseClass
{
	
	//OpenAGenericRequest_Page objG = new OpenAGenericRequest_Page(driver);
	String strMailBody = "", strNew = "";
	
	
	//switch to specific window
	public void switchToSpecificWindow(int windowId)
	{
		try
		{
			String strWindowHandle = "";
			
			Set<String> setAllWildowHandle = driver.getWindowHandles();
			Iterator<String> itrWindowHandle = setAllWildowHandle.iterator();
			
			for(int i=0; i<=windowId; i++)
			{
				strWindowHandle = itrWindowHandle.next();
			}
			driver.switchTo().window(strWindowHandle);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	//extract number from a string
		public String extractNumberFromText(String strMailBdy)
		{
			CreateServiceRequest_Page objC = new CreateServiceRequest_Page(driver);
			strMailBody = objC.getOutlookMailBodyText();
			char charArr[] = strMailBody.toCharArray();


			for(int i=0; i<charArr.length; i++)
			{
				if(Character.isDigit(charArr[i]))
					strNew = strNew + charArr[i];
			}

			strNew = strNew.substring(1, 7);
			return strNew;
		}
		
		
		//select the application from DDL
		public void selectTheApplication()
		{
			try
			{
				List<WebElement> eleLst = driver.findElements(By.xpath("//div[@id='select2-drop']/ul[1]/li"));
				
				for(WebElement ele : eleLst)
				{
					if(ele.getText().contains("Video Conferencing"))
					{
						ele.click();
						break;
					}
				}
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}

		@Test(enabled = true, priority = 1)
		public void testLogin() 
		{
			try
			{
				OpenAGenericRequest_Page objG = new OpenAGenericRequest_Page(driver);
				FileOperation_IT objF = new FileOperation_IT();

				objG.switchiFrame();
				objG.setUserName(objF.readPropertiesFile("AC_User_Id"));
				objG.setPassword(objF.readPropertiesFile("AC_User_Pwd"));
				objG.clickLoginBtn();

				if(driver.findElement(By.xpath("//input[@id='email_factor']")).isSelected()) //if CheckBox is selected
				{
					objG.clickContinueBtn();
				}
				else
				{
					objG.checkCheckBox();
				}
				objG.clickContinueBtn();
				
				String strDefaultWindowHandleBE = driver.getWindowHandle();

				driver.switchTo().newWindow(WindowType.TAB); //opening a new tab
				driver.get(objF.readPropertiesFile("AC_Outlook_2")); //launching outlook in newly opened tab	

				switchToSpecificWindow(1); //Switching to outlook window

				//objG.setOutlookUserName(objF.readPropertiesFile("Outlook_UserNm"));		
				//objG.clickOutlookOkButton();

				objG.setOutlookEmail(objF.readPropertiesFile("Outlook_Email")); //set email id
				objG.clickOutlookNextBtn(); //click Next button
				
				WebDriverWait waitOP = new WebDriverWait(driver, Duration.ofSeconds(3000));
				waitOP.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='passwd']")));
				
				objG.setOutlookPwd("Juul@2024");
				objG.clickOutlookSignInBtn();
				
				Thread.sleep(30000);
				
				WebDriverWait waitO = new WebDriverWait(driver, Duration.ofSeconds(99000000)); //apply Explicit wait
				waitO.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)']"))));
				
				objG.clickOnDraftFolder(); //click on Draft
				
				objG.clickOutlookInbox(); //click on Inbox
				objG.clickOutlookMultifactor();
				extractNumberFromText(strNew); //getting mail body and extracting number from text
				//objG.selectCheckBoxAutheticationMail();
				objG.clickDeleteIconOutlook();
				System.out.println("Number: " + strNew);
				//driver.close(); //closing the outlook window/tab
				
				driver.switchTo().window(strDefaultWindowHandleBE); //switch to default window
				
				objG.switchiFrame();
				objG.set6DigitVerficationCode(strNew); //set 6 digit verification code
				objG.clickVerifyBtn();
				
				System.out.println("Login complete....");
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}
		
		@Test(enabled = true, priority = 2)
		public void openGenericRequest() throws Exception
		{
			try
			{
				System.out.println("Open Generic Req....");
				OpenAGenericRequest_Page objG = new OpenAGenericRequest_Page(driver);
				switchToSpecificWindow(1);
				FileOperation_IT objF = new FileOperation_IT();
				driver.get(objF.readPropertiesFile("AC_Url_IT_FE")); //launching FE IT portal
				
				WebDriverWait waitFCU = new WebDriverWait(driver, Duration.ofSeconds(15000));
				waitFCU.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Contact us')]")));
				
				objG.clickFooterContactUs();
				
				WebDriverWait waitOSR = new WebDriverWait(driver, Duration.ofSeconds(2000));
				waitOSR.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Open a Service Request')])[2]")));
				
				objG.clickFooterOpenAServiceReqLink();
				
				WebDriverWait waitCN = new WebDriverWait(driver, Duration.ofSeconds(3000));
				waitCN.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@placeholder='Search Request Topic'])[1]")));
				
				//switchToSpecificWindow(2); //switch Select Your Request Topic window
				
				objG.setSearchRequestTopic(objF.readPropertiesFile("Category_Name"));
				
				WebDriverWait waitCND = new WebDriverWait(driver, Duration.ofSeconds(8000));
				waitCND.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@src='ag_or_category.svg']")));
				
				if(driver.findElement(By.xpath("//img[@src='ag_or_category.svg']")).isDisplayed())
				{
					objG.clickCategoryName();
				}
				else
					System.out.println("Category not displayed...");
				
				WebDriverWait waitScroll = new WebDriverWait(driver, Duration.ofSeconds(4000));
				waitScroll.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Back']")));
				
				objG.scrollToOpenAGenericRequest();
				objG.clickOpenAGenericReqLink();
				
				String strPageHeader = objF.readPropertiesFile("Page_Header");
				
				WebDriverWait waitPH = new WebDriverWait(driver, Duration.ofSeconds(15000));
				waitPH.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='main not-display']/div[contains(text(),'"+ strPageHeader +"')]")));
				
				//String strPageHeader = objG.getPageHeader();
				Assert.assertEquals(objG.getPageHeader(), strPageHeader); //verify page header
				System.out.println("Assert pass... " + strPageHeader);
				
				objG.setDescribeYourIssue("Describe your issue-Open Generic Request");
				
				Thread.sleep(2000);				
				objG.verifyVisibilityOfFormsAndKnowledgeResultsDiv();
				
				objG.scrollToSelectTheApplicationDDL();
				objG.clickSelectTheApplicationDDL();
				Thread.sleep(2000);
				selectTheApplication();
				
				objG.scrollToAttachments();
				objG.clickOnClickOrDrag();
				
				//Runtime.getRuntime().exec("C:\\UploadFile_AutoIT\\UploadFile_OpenGenericReq.exe");
				String[] commands = new String[] {"C:\\UploadFile_AutoIT\\UploadFile_OpenGenericReq.exe"}; //file upload
				Runtime.getRuntime().exec(commands, null);
				
				objG.scrollToSubmitRequestBtn();
				Thread.sleep(2000);
				objG.clickSubmitRequestBtn();
			}
			catch (Exception ex) 
			{
				//ex.printStackTrace();
				throw ex;
			}
		}
}
