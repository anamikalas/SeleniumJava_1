package test_script;

public class ClassPractice extends BaseClass
{
	
}
