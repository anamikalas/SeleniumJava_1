package test_script;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReport_Test
{
	ExtentSparkReporter htmlReport;
	ExtentReports report;
	ExtentTest test;
	
	@BeforeTest
	public void startReport()
	{
		htmlReport = new ExtentSparkReporter(".\\src\\test\\resources\\Test_Case_Execution_Report\\TestCaseExecutionReport.html");
		report = new ExtentReports();
		report.attachReporter(htmlReport);
		
		report.setSystemInfo("Machine", "My PC");
		report.setSystemInfo("OS", "Windows 11");
		report.setSystemInfo("User", "Anamika");
		report.setSystemInfo("Browser", "Chrome");
		
		htmlReport.config().setDocumentTitle("Document Title-My Doc");
		htmlReport.config().setReportName("Report Name-My Report");
		htmlReport.config().setTheme(Theme.STANDARD);
		htmlReport.config().setTimeStampFormat("EEEE, MMMM dd, yyyy 'at' hh:mm a '('zzz')'");
	}
	
	@Test(priority = 1)
	public void launchBrowser()
	{
		test = report.createTest("Launch the Browser");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		driver.get("https://www.google.com/");
		Assert.assertTrue(true);
	}
	
	@Test(priority = 2)
	public void verifyLogo()
	{
		test = report.createTest("Verify Logo");
		Assert.assertTrue(false);
	}
	
	@Test(priority = 3)
	public void verifyTitle()
	{
		test = report.createTest("Verify Title");
		throw new SkipException("Skipped method....");
	}
	
	@AfterMethod
	public void getTestResult(ITestResult testRes)
	{
		if(testRes.getStatus() == ITestResult.FAILURE)
		{
			test.log(Status.FAIL, MarkupHelper.createLabel(testRes.getName() + "Fail", ExtentColor.RED));
			test.fail(testRes.getThrowable()); //get details error
		}
		else if(testRes.getStatus() == ITestResult.SUCCESS)
		{
			test.log(Status.PASS, MarkupHelper.createLabel(testRes.getName() + "Pass", ExtentColor.GREEN));
			test.pass(testRes.getThrowable());
		}
		else if(testRes.getStatus() == ITestResult.SKIP)
		{
			test.log(Status.SKIP, MarkupHelper.createLabel(testRes.getName() + "Skipped", ExtentColor.YELLOW));
			test.skip(testRes.getThrowable());
		}
		
	}
	
	@AfterMethod
	public void tearDown()
	{
		report.flush();
	}
	
}
