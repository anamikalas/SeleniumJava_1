package test_script;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.*;

import utilities.BrowserOperation_IT;

public class BaseClass 
{
	public WebDriver driver;
	BrowserOperation_IT objBO = new BrowserOperation_IT();
	
	//@BeforeMethod(enabled = true)
	@BeforeClass(enabled = true)
	public void launchApp_AC()
	{
		try
		{
			Reporter.log("Launch AC BE");
			driver = objBO.launchAppAC_BO();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	@BeforeMethod(enabled = false)
	public void launchAppBrokenLink_BC()
	{
		try
		{
			Reporter.log("Launch DeadLink City");
			driver = objBO.launchAppBrokenLink_BO();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	@BeforeMethod(enabled = false)
	public void launchJQuery_BC()
	{
		try
		{
			Reporter.log("Launch JQuery Application");
			driver = objBO.launchJQuery_BO();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	@AfterMethod(enabled = false)
	public void closeBrowser()
	{
		//driver.close();
	}
}
