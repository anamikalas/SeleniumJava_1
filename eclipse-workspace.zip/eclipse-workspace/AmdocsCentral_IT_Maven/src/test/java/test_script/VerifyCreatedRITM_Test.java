package test_script;

import java.time.Duration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import object_repository.VerifyCreatedRITM_Page;
import utilities.FileOperation_IT;

public class VerifyCreatedRITM_Test extends BaseClass
{
	String strMailBody = "";
	String strNew = "";
	
	//public static final String URL = "https://API_KEY:API_SECRET@hub.testingbot.com/wd/hub";
	String strURL = "https://amdocssystemtest.service-now.com/";

	 
	//switch to specific window by passing parameter
	public void switchToSpecificWindow(int windowId)
	{
		try
		{
			String strNewWindowHandle = "";
			Set<String> setAllWIndowHandle = driver.getWindowHandles();
			Iterator<String> itrAllWindowHandle = setAllWIndowHandle.iterator();

			for(int i=0; i<=windowId; i++)
			{
				strNewWindowHandle = itrAllWindowHandle.next();
			}
			driver.switchTo().window(strNewWindowHandle);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();			
		}
	}


	//extract number from a string
	public String extractNumberFromText(String strMailBdy)
	{
		VerifyCreatedRITM_Page objV = new VerifyCreatedRITM_Page(driver);
		strMailBody = objV.getOutlookMailBodyText();
		char charArr[] = strMailBody.toCharArray();


		for(int i=0; i<charArr.length; i++)
		{
			if(Character.isDigit(charArr[i]))
				strNew = strNew + charArr[i];
		}

		strNew = strNew.substring(1, 7);
		return strNew;
	}
	
	
	public boolean verifyFileGotAttached()
	{
		try
		{
			boolean isAttached = false; 
			List<WebElement> eleLst = driver.findElements(By.xpath("//ul[@id='header_attachment_list']/li"));
			for(WebElement ele : eleLst)
			{
				if(ele.getText() != " " || !ele.equals(" "))
				{
					System.out.println("Fil name: " + ele.getText());
					isAttached = true;
				}
			}
			return isAttached;
		}
		catch(Exception ex)
		{
			//ex.printStackTrace();
			throw ex;
		}
	}

	@Test(enabled = true, priority = 1)
	public void loginToAC()
	{
		try
		{
			///************* Login *************************************************************************************************************
			VerifyCreatedRITM_Page objV = new VerifyCreatedRITM_Page(driver);
			FileOperation_IT objF = new FileOperation_IT();
			
			String strTktName = objF.readPropertiesFile("Ticket_Name_AC");

			objV.switchiFrame();
			objV.setUserName(objF.readPropertiesFile("AC_User_Id"));
			objV.setPassword(objF.readPropertiesFile("AC_User_Pwd"));
			objV.clickLoginBtn();

			if(driver.findElement(By.xpath("//input[@id='email_factor']")).isSelected()) //if CheckBox is selected
			{
				objV.clickContinueBtn();
			}
			else
			{
				objV.checkCheckBox();
			}
			objV.clickContinueBtn();

			String strDefaultWindowHandleBE = driver.getWindowHandle();
			
			

			driver.switchTo().newWindow(WindowType.TAB); //opening a new tab
			driver.get(objF.readPropertiesFile("AC_Outlook_2")); //launching outlook in newly opened tab	

			switchToSpecificWindow(1); //Switching to outlook window

			//objV.setOutlookUserName(objF.readPropertiesFile("Outlook_UserNm"));		
			//objV.clickOutlookOkButton();

			objV.setOutlookEmail(objF.readPropertiesFile("Outlook_Email")); //set email id
			objV.clickOutlookNextBtn(); //click Next button

			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(650000)); //apply Explicit wait
			wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)']")));
			//Thread.sleep(50000);

			objV.clickOnDraftFolder(); //click on Draft
			objV.clickOutlookInbox(); //click on Inbox
			objV.clickOutlookMultifactor();
			
			Thread.sleep(12000);
			
			extractNumberFromText(strNew); //getting mail body and extracting number from text
			System.out.println("Number: " + strNew);
			
			//objV.clickDeleteIconOutlook1();
			
			//objV.clickDeleteIconOutlook2();
			Actions actns = new Actions(driver);
			actns.moveToElement(driver.findElement(By.xpath("(//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)'])[1]"))).click(driver.findElement(By.xpath("(//div[@class='QpoLy'])[1]"))).build().perform();
			
			//driver.close(); //closing the outlook window/tab

			driver.switchTo().window(strDefaultWindowHandleBE); //switch to default window

			objV.switchiFrame();
			objV.set6DigitVerficationCode(strNew); //set 6 digit verification code
			objV.clickVerifyBtn();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	//Go to BE and verify RITM data
	@Test(enabled = true, priority = 2)
	public void verifyCreatedRITM()
	{
		try
		{
			System.out.println("Verification started 1....");
			
			VerifyCreatedRITM_Page objV = new VerifyCreatedRITM_Page(driver);
			FileOperation_IT objF = new FileOperation_IT();
			
			objV.setTableNameOnFilterNavigator(objF.readPropertiesFile("Table_Name"));
			
			WebDriverWait waitTblNmClick = new WebDriverWait(driver, Duration.ofSeconds(15000));
			waitTblNmClick.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[text()='All Requested Items']")));
			
			objV.clickOnTableName();
			
			objV.switchToFrame();
			
			WebDriverWait waitRITM = new WebDriverWait(driver, Duration.ofSeconds(15000));
			waitRITM.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='sc_req_item_table']/thead/tr[2]/td[@name='number']")));
			
			//objV.switchToFrame();	
						
			objV.setRITMNumberOnInputBox(objF.readPropertiesFile("RITM_No"));
			
			System.out.println("Verification going on 1....");
					
			objV.sendEnterRITMTxtBox();
			objV.clickPreviewBtn();
			objV.clickOpenRecordBtn();
			
			String strItem = objV.getItem();
			String strTextarea = objV.getBusinessUnit();
			System.out.println("Textarea is: " + strTextarea + "\n");
			
			SoftAssert sftAssert = new SoftAssert();
			sftAssert.assertTrue(strTextarea.contains(objF.readPropertiesFile("Business_Unit")));
			//sftAssert.assertTrue(strTextarea.contains("What will be the location of the share folder?: '"+ objF.readPropertiesFile("Share_Folder_Location") +"' ")); //What will be the location of the share folder?: Toronto
			sftAssert.assertTrue(strTextarea.contains(objF.readPropertiesFile("Share_Folder_Location"))); //What will be the location of the share folder?: Toronto
			sftAssert.assertAll();
			
			objV.scrollToCatalogTaskTab();
			objV.clickCatalogTaskTab();
			objV.openTaskRightClick();
			
			//Actions actns = new Actions(driver);
			//actns.keyDown(Keys.CONTROL).click(driver.findElement(By.xpath("(//a[contains(text(),'TASK')])[1]"))).build().perform();
			
			switchToSpecificWindow(2);
			
			//objV.clickTakeOverBtn();
			objV.selectStateAwaitingUserInfo();
			String strState = objV.getStateDDL();
			System.out.println("State: " + strState);
			Assert.assertEquals(strState, "Awaiting User Info");
			objV.clickSaveBtn();
			driver.close();
			
			switchToSpecificWindow(0);
			driver.navigate().refresh();
			
			objV.switchToFrame();
			Assert.assertEquals(true, objV.verifyCheckBoxIsReadOnly());
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	@Test(enabled = true, priority = 3)
	public void uploadFileForRITM()
	{
		try
		{
			VerifyCreatedRITM_Page objV = new VerifyCreatedRITM_Page(driver);
			FileOperation_IT objF = new FileOperation_IT();
			
			switchToSpecificWindow(0);
			objV.switchiFrame();
			objV.clickAttachmentIcon();
			objV.clickChooseFileBtn();
			
			Runtime.getRuntime().exec("C:\\UploadFile_AutoIT\\UploadFile_VerifyRITM1.exe");
			
			objV.clickXBtn();
			
			//Assert.assertEquals(true, verifyFileGotAttached());
			
			Assert.assertEquals(true, objV.verifyAttachmentGotAttached());
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
