package test_script;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import utilities.ExcelOperation;

public class ReadDataFromExcel 
{
	@DataProvider(name = "")
	public Object[][] getExcelData() throws IOException
	{
		ExcelOperation objE = new ExcelOperation();
		objE.getSheetName();
		int totRow = objE.getTotalRowNumber();
		Object[][] data = new Object[totRow][2];
		
		for(int i=0; i<totRow; i++)
		{
			data[i][0] = objE.getCellValue(i, 0);
			data[i][0] = objE.getCellValue(i, 1);
		}
		
		return data;
	}
	
	@Test(dataProvider = "")
	public void readExcelData(String strUserNm, String strPwd)
	{
		try
		{
			WebDriver driver = new ChromeDriver();
			driver.findElement(By.xpath("")).sendKeys(strUserNm);
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
