package test_script;

import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import object_repository.HomePageSearch_Page;
import utilities.FileOperation_IT;

public class HomePageSearch_Test extends BaseClass
{
	HomePageSearch_Page objH = new HomePageSearch_Page(driver);
	String strMailBody = "";
	String strNew = "";
	
	//switch to newly opened window
	public void switchToSpecificWindow(int windowId)
	{
		String strNewWindowHandle = "";
		Set<String> setAllWIndowHandle = driver.getWindowHandles();
		Iterator<String> itrWindowHandle = setAllWIndowHandle.iterator();
		
		for(int i=0; i<=windowId; i++)
		{
			strNewWindowHandle = itrWindowHandle.next();
		}
		driver.switchTo().window(strNewWindowHandle);
	}
	
	//click on auto complete list
	public void clickOnSearchHistoryText()
	{
		try
		{
		List<WebElement> lstEle = driver.findElements(By.xpath("//ul[@class='dropdown-menu ng-isolate-scope']"));
		for(WebElement ele : lstEle)
		{
			if(ele.getText().contains("Amdocs"))
				ele.click();
		}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	//extract number from a string
	public String extractNumberFromText(String strMailBdy)
	{
		HomePageSearch_Page objH = new HomePageSearch_Page(driver);
		strMailBody = objH.getOutlookMailBodyText();
		char charArr[] = strMailBody.toCharArray();
		

		for(int i=0; i<charArr.length; i++)
		{
			if(Character.isDigit(charArr[i]))
				strNew = strNew + charArr[i];
		}

		//int num = Integer.parseInt(strNew);
		strNew = strNew.substring(1, 7);
		return strNew;
	}
	
	//login
	@Test(enabled = true, priority = 1)
	public void testLogin() 
	{
		try
		{
			HomePageSearch_Page objH = new HomePageSearch_Page(driver);
			FileOperation_IT objF = new FileOperation_IT();

			objH.switchiFrame();
			objH.setUserName(objF.readPropertiesFile("AC_User_Id"));
			objH.setPassword(objF.readPropertiesFile("AC_User_Pwd"));
			objH.clickLoginBtn();

			if(driver.findElement(By.xpath("//input[@id='email_factor']")).isSelected()) //if CheckBox is selected
			{
				objH.clickContinueBtn();
			}
			else
			{
				objH.checkCheckBox();
			}
			objH.clickContinueBtn();
			
			String strDefaultWindowHandleBE = driver.getWindowHandle();

			driver.switchTo().newWindow(WindowType.TAB); //opening a new tab
			driver.get(objF.readPropertiesFile("AC_Outlook_2")); //launching outlook in newly opened tab	

			switchToSpecificWindow(1); //Switching to outlook window

			//objH.setOutlookUserName(objF.readPropertiesFile("Outlook_UserNm"));		
			//objH.clickOutlookOkButton();

			objH.setOutlookEmail(objF.readPropertiesFile("Outlook_Email")); //set email id
			objH.clickOutlookNextBtn(); //click Next button
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1000)); //apply Explicit wait
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)']"))));
			
			objH.clickOnDraftFolder(); //click on Draft
			objH.clickOutlookInbox(); //click on Inbox
			objH.clickOutlookMultifactor();
			extractNumberFromText(strNew); //getting mail body and extracting number from text
			//objH.selectCheckBoxAutheticationMail();
			objH.clickDeleteIconOutlook();
			System.out.println("Number: " + strNew);
			//driver.close(); //closing the outlook window/tab
			
			driver.switchTo().window(strDefaultWindowHandleBE); //switch to default window
			
			objH.switchiFrame();
			objH.set6DigitVerficationCode(strNew); //set 6 digit verification code
			objH.clickVerifyBtn();
			
			System.out.println("Login complete....");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	//search
	@Test(enabled = true, priority = 2)
	public void searchOperationAtHomePage()
	{
		try
		{
			//driver.switchTo().newWindow(WindowType.TAB); //opening new tab in same browser
			switchToSpecificWindow(1);
			FileOperation_IT objF = new FileOperation_IT();
			driver.get(objF.readPropertiesFile("AC_Url_IT_FE")); //launching FE
			HomePageSearch_Page objH = new HomePageSearch_Page(driver);
			objH.setSearchTextBox(objF.readPropertiesFile("Search_Text_IT"));
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//ul[@class='dropdown-menu ng-isolate-scope']"))));
			
			clickOnSearchHistoryText();
			
			objH.clickAmdocsLogo();
			
			System.out.println("Search complete...");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
