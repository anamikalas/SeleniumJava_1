package test_script;

import java.io.IOException;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import object_repository.CreateKnowledgeArticle_Page;
import object_repository.VerifyCreatedRITM_Page;
import utilities.FileOperation_IT;

public class CreateKnowledgeArticle_Test extends BaseClass
{
	String strMailBody = "";
	String strNew = "";
	
	//switch to specific window
	public void switchToSpecificWindow(int windowId)
	{
		try
		{
			String strNewWindowHandle = "";
			Set<String> setAllWindowHandle = driver.getWindowHandles();
			Iterator<String> itrWindowHandle = setAllWindowHandle.iterator();
			for(int i=0; i<=windowId; i++)
			{
				strNewWindowHandle = itrWindowHandle.next();
			}
			driver.switchTo().window(strNewWindowHandle);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	//extract number from a string
	public String extractNumberFromText(String strMailBdy)
	{
		VerifyCreatedRITM_Page objA = new VerifyCreatedRITM_Page(driver);
		strMailBody = objA.getOutlookMailBodyText();
		char charArr[] = strMailBody.toCharArray();


		for(int i=0; i<charArr.length; i++)
		{
			if(Character.isDigit(charArr[i]))
				strNew = strNew + charArr[i];
		}

		strNew = strNew.substring(1, 7);
		return strNew;
	}
	
	//click to select current date
	public void clickOnCurrentdate()
	{
		Calendar cal = Calendar.getInstance();
		int date = cal.get(Calendar.DAY_OF_MONTH);
		//System.out.println("Date: " + date);
		
		Actions actns = new Actions(driver);
		actns.doubleClick(driver.findElement(By.xpath("//a[text()='"+ date +"']"))).build().perform();
	}
	

	//Do login
	@Test (enabled = true, priority = 1)
	public void loginToAC()
	{
		try
		{
			///************* Login *************************************************************************************************************
			CreateKnowledgeArticle_Page objA = new CreateKnowledgeArticle_Page(driver);
			FileOperation_IT objF = new FileOperation_IT();
			
			String strTktName = objF.readPropertiesFile("Ticket_Name_AC");

			objA.switchiFrame();
			objA.setUserName(objF.readPropertiesFile("AC_User_Id"));
			objA.setPassword(objF.readPropertiesFile("AC_User_Pwd"));
			objA.clickLoginBtn();

			if(driver.findElement(By.xpath("//input[@id='email_factor']")).isSelected()) //if CheckBox is selected
			{
				objA.clickContinueBtn();
			}
			else
			{
				objA.checkCheckBox();
			}
			objA.clickContinueBtn();

			String strDefaultWindowHandleBE = driver.getWindowHandle();
			
			

			driver.switchTo().newWindow(WindowType.TAB); //opening a new tab
			driver.get(objF.readPropertiesFile("AC_Outlook_2")); //launching outlook in newly opened tab	

			switchToSpecificWindow(1); //Switching to outlook window

			//objA.setOutlookUserName(objF.readPropertiesFile("Outlook_UserNm"));		
			//objA.clickOutlookOkButton();

			objA.setOutlookEmail(objF.readPropertiesFile("Outlook_Email")); //set email id
			objA.clickOutlookNextBtn(); //click Next button

			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(650000)); //apply Explicit wait
			wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)']")));
			//Thread.sleep(50000);

			objA.clickOnDraftFolder(); //click on Draft
			objA.clickOutlookInbox(); //click on Inbox
			objA.clickOutlookMultifactor();
			
			Thread.sleep(12000);
			
			extractNumberFromText(strNew); //getting mail body and extracting number from text
			System.out.println("Number: " + strNew);
			
			//objA.clickDeleteIconOutlook1();
			
			//objA.clickDeleteIconOutlook2();
			Actions actns = new Actions(driver);
			actns.moveToElement(driver.findElement(By.xpath("(//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)'])[1]"))).click(driver.findElement(By.xpath("(//div[@class='QpoLy'])[1]"))).build().perform();
			
			//driver.close(); //closing the outlook window/tab

			driver.switchTo().window(strDefaultWindowHandleBE); //switch to default window

			objA.switchiFrame();
			objA.set6DigitVerficationCode(strNew); //set 6 digit verification code
			objA.clickVerifyBtn();
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	@Test(enabled = true, priority = 2)
	public void createKBArticleFromBE()
	{
		try
		{
			CreateKnowledgeArticle_Page objA = new CreateKnowledgeArticle_Page(driver);
			FileOperation_IT objF = new FileOperation_IT();
			
			objA.setKnowledgeOnFilterNavigatorTextBox(objF.readPropertiesFile("Aplication_Name"));
			System.out.println("Application name is: " + objF.readPropertiesFile("Aplication_Name"));
			
			objA.switchiFrame();
			
			WebDriverWait waitAA = new WebDriverWait(driver, Duration.ofSeconds(20000));
			waitAA.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Add content']")));
			
			switchToSpecificWindow(0);
						
			objA.clickTableNameAllArticles(); 
			System.out.println("Table Name: All Articles");
			
			objA.switchiFrameKB();
			
			WebDriverWait waitNew = new WebDriverWait(driver, Duration.ofSeconds(3000));
			waitNew.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='sysverb_new']")));
			
			objA.clickNewBtn();
			
			//objA.switchiFrameKB();
			
			WebDriverWait waitKBNo = new WebDriverWait(driver, Duration.ofSeconds(2000));
			waitKBNo.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='sys_readonly.kb_knowledge.number']")));
			
			//String strKBNo = driver.findElement(By.xpath("//input[@id='sys_readonly.kb_knowledge.number']")).getAttribute("");
					
			String strKBNo = objA.getKBNumber();
			
			Assert.assertTrue(strKBNo.contains("KB"));
			System.out.println("KB Article No.: " + strKBNo);			
			
			objA.clickKnowledgeBaseMG();
			
			switchToSpecificWindow(2);
			
			objA.setKnowledgeBaseTextBox(objF.readPropertiesFile("KB_Title"));
			
			Thread.sleep(700);
			
			//objA.sendKBTitleEnter();
			Actions actns = new Actions(driver);
			actns.sendKeys(Keys.ENTER).build().perform();
			
			Thread.sleep(1000);
			
			objA.clickKnowledgeBaseHR();
			switchToSpecificWindow(0);
			objA.switchiFrameKB();
			
			String strKBName = objA.getAndVerifyKnowledgeBase();
			Assert.assertFalse(strKBName.equals(" "));
			System.out.println("Knowledge base: " + strKBName);
			
			objA.clickServiceCategoryMG();
			switchToSpecificWindow(2);
			objA.clickServiceCategory();
			switchToSpecificWindow(0);
			objA.switchiFrameKB();
			
			objA.selectArticleTypeFromDDL();
			objA.clickUpdatedDateIcon();
			//objA.switchiFrameCalendar();
			clickOnCurrentdate();
			
			objA.setShortDescription("Short Description - Knowledge Article " + System.currentTimeMillis());
			
			boolean isEnabledFalse = objA.verifyRejectedIsFalse();
			Assert.assertTrue(isEnabledFalse);
			objA.clickMetaTextarea();
			
			String strWorkflow = objA.verifyWokflowIsDraft();
			System.out.println("Workflow: " + strWorkflow);
			Assert.assertEquals("Draft", strWorkflow);
			
			objA.clickSaveButton();
			objA.clickSubmitToReviewBtn();
			
			String strWofflowReview = objA.getWorkflowReview();
			Assert.assertEquals("Review", strWofflowReview);
			System.out.println("Workflow: " + strWofflowReview);
			
			Thread.sleep(1000);
			driver.switchTo().alert().accept();
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
