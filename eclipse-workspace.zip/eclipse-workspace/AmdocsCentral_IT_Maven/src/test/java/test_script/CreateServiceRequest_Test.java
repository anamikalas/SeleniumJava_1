package test_script;
import utilities.*;
import object_repository.*;

import java.lang.ref.Reference;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CreateServiceRequest_Test extends BaseClass
{
	//CreateServiceRequest_Page objC = new CreateServiceRequest_Page(driver);
	FileOperation_IT objF = new FileOperation_IT();
	String strMailBody = "";
	String strNew = "";
	
	
	//switch to specific window
	public void switchToSpecificWindow(int windowId)
	{
		try
		{
			String strNewWindowHandle = "";

			Set<String> setAllWindowHandle = driver.getWindowHandles();
			Iterator<String> itrWindowHandle = setAllWindowHandle.iterator();

			for(int i=0; i<=windowId; i++)
			{
				strNewWindowHandle = itrWindowHandle.next();
			}
			driver.switchTo().window(strNewWindowHandle);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	//extract number from a string
	public String extractNumberFromText(String strMailBdy)
	{
		CreateServiceRequest_Page objC = new CreateServiceRequest_Page(driver);
		strMailBody = objC.getOutlookMailBodyText();
		char charArr[] = strMailBody.toCharArray();


		for(int i=0; i<charArr.length; i++)
		{
			if(Character.isDigit(charArr[i]))
				strNew = strNew + charArr[i];
		}

		strNew = strNew.substring(1, 7);
		return strNew;
	}
	
	//click service request to open RITM
	public void clickOnServiceRwquestLinkToOpenRITM()
	{
		try
		{
			List<WebElement> lstEle = driver.findElements(By.xpath("//span[text()='Service Request']"));
			int countSR = lstEle.size();
			String strTktName = driver.findElement(By.xpath("(//div[@class='topic-cubes']/div/div/div/div[1])[1]")).getText();
			
			/*for(WebElement ele : lstEle)
			{
				if(ele.getText().equals("Service Request"))
				{
					ele.click();
					break;
				}
				else
					break;
			}*/
			
			for(int i=0; i<=countSR; i++)
			{
				if(lstEle.get(i).getText().equalsIgnoreCase("Service Request") & strTktName.contains(objF.readPropertiesFile("Ticket_Name_AC")));
				{
					lstEle.get(i).click();
					break;
				}
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	//select Business Unit
	public void selectBusinessUnit()
	{
		try
		{
			List<WebElement> lstEle = driver.findElements(By.xpath("//ul[@aria-label='Select the Business Unit']/li"));
			int lstSize = lstEle.size();
			System.out.println("Size: " + lstSize);
			
			for(int i=0; i<=lstEle.size(); i++)
			{
				if(lstEle.get(i).getText().contains(objF.readPropertiesFile("Business_Unit")))
				{
					lstEle.get(i).click();
					break;
				}
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	//select share folder location
	@SuppressWarnings("unused")
	public void selectLocationOfShareFolder()
	{
		try
		{
			FileOperation_IT objF = new FileOperation_IT();
			String strSFLoc = objF.readPropertiesFile("Share_Folder_Location");
			
			List<WebElement> lstEle = driver.findElements(By.xpath("//ul[@aria-label='What will be the location of the share folder?']/li"));
			
			
			for(int i=0; i<=lstEle.size(); i++)
			{
				if(lstEle.get(i).getText().contains(objF.readPropertiesFile("Share_Folder_Location")));
				{	
					//lstEle.get(i).click();
					driver.findElement(By.xpath("//span[text()='"+ strSFLoc +"']")).click();
					System.out.println("Share folder location: " + objF.readPropertiesFile("Share_Folder_Location"));
					break;
				}
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	
	public String getRITMNumber() throws Exception
	{
		try
		{
			String strTktName = objF.readPropertiesFile("Ticket_Name_AC");
			String strRITMNoWithTxt = driver.findElement(By.xpath("(//span[contains(text(),'"+ strTktName +"')])[1]/following::span[1]")).getText();
			String strRITMNo1 = strRITMNoWithTxt.substring(8, 19);
			return strRITMNo1;
		}
		catch(Exception ex)
		{
			throw ex;
		}
	}

	@Test(enabled = true, priority = 1)
	public void testLogin()
	{
		try
		{
			CreateServiceRequest_Page objC = new CreateServiceRequest_Page(driver);
			FileOperation_IT objF = new FileOperation_IT();
			String strTktName = objF.readPropertiesFile("Ticket_Name_AC");

			objC.switchiFrame();
			objC.setUserName(objF.readPropertiesFile("AC_User_Id"));
			objC.setPassword(objF.readPropertiesFile("AC_User_Pwd"));
			objC.clickLoginBtn();

			if(driver.findElement(By.xpath("//input[@id='email_factor']")).isSelected()) //if CheckBox is selected
			{
				objC.clickContinueBtn();
			}
			else
			{
				objC.checkCheckBox();
			}
			objC.clickContinueBtn();

			String strDefaultWindowHandleBE = driver.getWindowHandle();

			driver.switchTo().newWindow(WindowType.TAB); //opening a new tab
			driver.get(objF.readPropertiesFile("AC_Outlook_2")); //launching outlook in newly opened tab	

			switchToSpecificWindow(1); //Switching to outlook window

			//objC.setOutlookUserName(objF.readPropertiesFile("Outlook_UserNm"));		
			//objC.clickOutlookOkButton();

			objC.setOutlookEmail(objF.readPropertiesFile("Outlook_Email")); //set email id
			objC.clickOutlookNextBtn(); //click Next button

			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(100000)); //apply Explicit wait
			wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)']")));
			//Thread.sleep(50000);

			objC.clickOnDraftFolder(); //click on Draft
			objC.clickOutlookInbox(); //click on Inbox
			objC.clickOutlookMultifactor();
			extractNumberFromText(strNew); //getting mail body and extracting number from text
			System.out.println("Number: " + strNew);
			objC.clickDeleteIconOutlook();
			//driver.close(); //closing the outlook window/tab

			driver.switchTo().window(strDefaultWindowHandleBE); //switch to default window

			objC.switchiFrame();
			objC.set6DigitVerficationCode(strNew); //set 6 digit verification code
			objC.clickVerifyBtn();
		}

		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}


	
	@Test(enabled = true, priority = 2)
	public void OpenITSupportPortal()
	{
		CreateServiceRequest_Page objC = new CreateServiceRequest_Page(driver);
		FileOperation_IT objF = new FileOperation_IT();

		try
		{
			switchToSpecificWindow(1);
			//driver.switchTo().newWindow(WindowType.TAB);
			driver.get(objF.readPropertiesFile("AC_Url_IT_FE")); //launching FE
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20000));
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//div[@uib-popover='Accounts & Permissions']"))));
			
			objC.scrollToCatagoryAccountsAndPermissions(); //scroll to category - Accounts & Permissions
			objC.clickAccountsAndPermissions();
			
			clickOnServiceRwquestLinkToOpenRITM(); //click on ticket name to open Service Request form
			
			WebDriverWait waitCR = new WebDriverWait(driver, Duration.ofSeconds(30000));
			waitCR.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Will the folder contain highly sensitive data?']")));
			
			objC.clickDDlHighlySensitiveData();
			objC.clickYes();
			
			objC.clickDDlBusinessUnit();
			selectBusinessUnit();
			objC.setShareName("Folder-Abc");
			
			Thread.sleep(4000);
			
			objC.clickLocationOfShareFolder();
			
			objC.setShareFolderLocInTextBox(objF.readPropertiesFile("Share_Folder_Location"));
			
			selectLocationOfShareFolder();
			objC.setAdditionalInformation("Create a shared folder or map a network drive.");
			//objC.clickClickOrDragToAddBtn();
			
			//Runtime.getRuntime().exec("C:\\UploadFile_AutoIT\\UploadFile_AutoIT_RITM.exe");
			
			objC.clickSubmitBtn();
			
			WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(120));
			wait2.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//a[text()='Track your request']"))));
			
			String strTrackRITM = driver.findElement(By.xpath("//a[text()='Track your request']")).getText();
			System.out.println("Track: " + strTrackRITM);
			
			Assert.assertEquals("Track your request", strTrackRITM);
			
			objC.clickTrackYourRequestLink();		
			
			String strRITMNo = getRITMNumber();
			objF.writeProperties("\nRITM_No=", strRITMNo);
			
			//fluent wait		
			Wait<WebDriver> waitF2 = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(60)).pollingEvery(Duration.ofSeconds(60)).ignoring(NoSuchElementException.class);
			waitF2.until(ExpectedConditions.elementToBeClickable(By.xpath("")));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	}

