package utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelOperation 
{
	XSSFSheet sheetName;
	
	public void getSheetName() throws IOException
	{
		try(FileInputStream fis =  new FileInputStream(""))
		{
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			sheetName = wb.getSheet("Sheet1");
			//wb.close();
		}
	}
	
	public int getTotalRowNumber()
	{
		int rowNum = sheetName.getLastRowNum()-1;
		return rowNum;
	}
	
	public String getCellValue(int row, int col)
	{
		String strVal = sheetName.getRow(row).getCell(col).getStringCellValue();
		return strVal;
	}
}
