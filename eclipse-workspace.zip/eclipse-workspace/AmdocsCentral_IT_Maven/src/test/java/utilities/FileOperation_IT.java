package utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class FileOperation_IT 
{
	//read properties file
	public String readPropertiesFile(String strKey) throws IOException
	{
		try(FileInputStream fis = new FileInputStream(".\\src\\test\\resources\\DataFolder\\PropertiesFile.properties"))
		{
			Properties prop = new Properties();
			prop.load(fis);
			String strval = prop.getProperty(strKey);
			return strval;
		}
	}


	/*public FileOutputStream writeProperties(String strKey, String strVal) throws Exception
	{
		try
		{
			FileOutputStream fos = new FileOutputStream(".\\src\\test\\resources\\DataFolder\\Properties_Write.properties");
			Properties prop = new Properties();
			prop.setProperty(strKey, strVal);
			prop.store(fos, "New Value");
			return fos;
		}
		catch(Exception ex)
		{
			throw ex;
		}
	}*/

	//write data into properties file
	public void writeProperties(String strKey,String strVal) throws Exception
	{
			//String fileName = ".\\src\\test\\resources\\DataFolder\\Properties_Write.properties";
			String strFileName = ".\\src\\test\\resources\\DataFolder\\PropertiesFile.properties";

			try
			{
				FileOutputStream fos = new FileOutputStream(strFileName,true); //true - data will append, false - data will replace
				byte[] byteVal = (strKey+strVal).getBytes();
				fos.write(byteVal);

		}
		catch(Exception ex)
		{
			throw ex;
		}
	}
}
