package utilities;

import static org.testng.Assert.assertThrows;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class BrowserOperation_IT 
{
	FileOperation_IT objF = new FileOperation_IT();
	
	//WebDriver driver = new ChromeDriver();
	
	public WebDriver launchAppAC_BO() throws Exception
	{
		try
		{	
			//System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
			
			ChromeOptions options = new ChromeOptions();
			//options.addArguments("disable-notifications"); //disable normal popup
			//options.addArguments("--disable-geolocations"); //disable location popup
			//options.addArguments("--disable-media-stream"); //disable camera microphone popup
			
			//handle browser popup Block
			Map<String, Integer> contentSettings = new HashMap<String, Integer>();
			Map<String, Object> profile = new HashMap<String, Object>();
			Map<String, Object> prefs = new HashMap<String, Object>();
			
			contentSettings.put("notifications", 2); // permission 0 - Cancel, 1 - Allow, 2 - Block
			profile.put("managed_default_content_settings", contentSettings);
			prefs.put("profile", profile);
			options.setExperimentalOption("prefs", prefs);
			
			WebDriver driver = new ChromeDriver(options);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
			driver.get(objF.readPropertiesFile("AC_Url_OO_BE"));					
			return driver;
		}
		catch(Exception ex)
		{
			//ex.printStackTrace();
			throw ex;
		}
	}
	
	//launch broken link page
	public WebDriver launchAppBrokenLink_BO() throws Exception
	{
		try
		{
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
			driver.get(objF.readPropertiesFile("Broken_Link_Url"));
			return driver;
		}
		catch(Exception ex)
		{
			throw ex;
		}
	}
	
	
	public WebDriver launchJQuery_BO() throws Exception
	{
		try
		{
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
			driver.get(objF.readPropertiesFile("JQuery_URL"));
			return driver;
		}
		catch(Exception ex)
		{
			//ex.printStackTrace();
			throw ex;
		}
	}
	
	/*public WebDriver launchOutlookB_AC()
	{
		driver.switchTo().newWindow(WindowType.TAB);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://outlook.office.com/mail/");
		return driver;
	}*/

}
