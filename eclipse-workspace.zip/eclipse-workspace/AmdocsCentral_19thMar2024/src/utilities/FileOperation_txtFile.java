package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class FileOperation_txtFile 
{
	public String readPropertyFile(String strKey) throws IOException
	{
		try
		{
		File file = new File(".\\InputFolder\\InputFile.properties");
		FileInputStream fis = new FileInputStream(file);
		Properties prop = new Properties();
		prop.load(fis);
		String strData = prop.getProperty(strKey);
		return strData;
		}
		catch(IOException ex)
		{
			throw ex;
		}
	}
}
