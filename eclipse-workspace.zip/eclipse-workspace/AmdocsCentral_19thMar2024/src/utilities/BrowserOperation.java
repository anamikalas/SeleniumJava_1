package utilities;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BrowserOperation 
{
	public WebDriver driver;
	
	FileOperation_txtFile objFO = new FileOperation_txtFile();
	
	//application for table scenario
	public WebDriver launchApplicationTable() throws IOException /*https://www.techlistic.com/2020/07/automation-testing-demo-websites.html*/
	{
		try
		{
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		//FileOperation_txtFile objFO = new FileOperation_txtFile();
		String strUrl = objFO.readPropertyFile("Demo_Page_Table_Url");
		
		driver.get(strUrl);
		return driver;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			throw ex;
		}
	}
	
	//launch application for JavaScriptExecutor
	public WebDriver launchApplicationJSExecutor() throws IOException /*https://www.way2automation.com/way2auto_jquery/automation-practice-site.html*/
	{
		try
		{
			System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			String strPgUrl = objFO.readPropertyFile("Page_Url_JSE");
			driver.get(strPgUrl);
			return driver;
		}
		catch(Exception ex)
		{
			throw ex;
		}
	}
	
	//launch application of broken url
	public WebDriver launchApplicationOfBrokenUrl() throws IOException
	{
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String strUrl = objFO.readPropertyFile("Broken_Site_Url");
		driver.get(strUrl);
		//driver.navigate().to(strUrl);
		//driver.navigate().refresh();
		return driver;
	}
}
