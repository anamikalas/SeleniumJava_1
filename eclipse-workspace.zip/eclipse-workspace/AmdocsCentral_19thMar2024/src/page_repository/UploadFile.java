package page_repository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UploadFile 
{
	public WebDriver driver;
	
	public UploadFile(WebDriver webDriver)
	{
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this);
	}
	
	@FindBy(xpath = "//a[@href='draggable.php']")
	private WebElement eleDragableDiv;
	public void clickDragableDiv()
	{
		eleDragableDiv.click();
	}
	
	@FindBy(xpath = "//a[text()='Draggable + Sortable']")
	private WebElement eleDraggableAndStorable;
	public void clickDraggableAndStorable()
	{
		eleDraggableAndStorable.click();
	}
	
	@FindBy(xpath = "//iframe[@src='draggable/default5.html']")
	private WebElement eleiFrame;
	public void switchiFrame()
	{
		driver.switchTo().frame(eleiFrame);
	}
	
	@FindBy(xpath = "//a[text()='Registration']")
	private WebElement eleRegistration;
	public void clickRegistration()
	{
		eleRegistration.click();
	}
	
	@FindBy(xpath = "//label[text()='Your Profile Picture']/following-sibling::input[1]") private WebElement eleUploadFilePath;
	public void uploadFileBySendkeys(String strFilePath)
	{
		//((JavascriptExecutor)driver).executeScript("arguments[0].value='c:\\Users\\anamikla\\eclipse-workspace\\AmdocsCentral_19thMar2024\\ScreenShotFolder\\Error1.png';", eleUploadFilePath);
		eleUploadFilePath.sendKeys(strFilePath);
	}
	
	@FindBy(xpath = "//label[text()='Your Profile Picture']/following-sibling::input[1]") private WebElement eleUploadFileBtn;
	public void ClickuploadFileBtn() 
	{
		//((JavascriptExecutor)driver).executeScript("arguments[0]click();", eleUploadFileBtn);*/
		Actions actns = new Actions(driver);
		actns.click(eleUploadFileBtn).build().perform();
	}
}
