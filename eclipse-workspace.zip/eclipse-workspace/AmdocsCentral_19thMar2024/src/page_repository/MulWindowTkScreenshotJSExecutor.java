package page_repository;

import java.util.Set;

import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MulWindowTkScreenshotJSExecutor 
{
	public WebDriver driver;
	
	public MulWindowTkScreenshotJSExecutor(WebDriver webDriver)
	{
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this);
	}
	
	@FindBy(xpath = "//a[@href='frames-and-windows.php']")
	private WebElement eleFramesAndWindowsDiv;
	public void verifyFramesAndWindowsDiv()
	{
		eleFramesAndWindowsDiv.isDisplayed();
	}
	
	@FindBy(xpath = "//a[@href='frames-and-windows.php']")
	private WebElement eleFramesAndWindows;
	public void clickFramesAndWindows()
	{
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();", eleFramesAndWindows);
	}
	
	//switching to new opened window
	public void swithToNewWindow()
	{
		String strDefaultWindow = driver.getWindowHandle();
		Set<String> setAllWindowHanle = driver.getWindowHandles();
		
		for(String strAllWIndowHandle : setAllWindowHanle)
		{
			if(!strDefaultWindow.equals(strAllWIndowHandle))
				driver.switchTo().window(strAllWIndowHandle);
		}
	}
	
	@FindBy(xpath = "//iframe[@src='frames-windows/defult1.html']")
	private WebElement eleiFrame;
	public void switchiFrame()
	{
		driver.switchTo().frame(eleiFrame);
	}
	
	@FindBy(xpath = "//a[text()='New Browser Tab']")
	private WebElement eleNewBrowserLink;
	public void clikNewBrowserTabLink()
	{
		eleNewBrowserLink.click();
	}
	
	//method to fail script and to take screen shot
	//wrong xpath, element not found, bcoz of that script will fail and will take screen shot
	@FindBy(xpath = "//a[text()='New Browser Tabb']")
	private WebElement eleNewBrowserLink1;
	public void clikNewBrowserTabLink1()
	{
		eleNewBrowserLink1.click();
	}
}
