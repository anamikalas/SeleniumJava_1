package page_repository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.server.handler.FindElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage 
{
	public WebDriver driver;
	
	public LoginPage(WebDriver webDriver)
	{
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this);
	}	
	
	@FindBy(xpath = "//input[@id='user_name']")
	private WebElement eleUserName; 
	public void setUserName(String strUN)
	{
		eleUserName.sendKeys(strUN);
	}
	
	@FindBy(xpath = "//input[@id='user_password']")
	private WebElement elePwd;
	public void setPassword(String strPwd)
	{
		elePwd.sendKeys(strPwd);
	}
	
	@FindBy(id="sysverb_login")
	private WebElement eleBtn;
	public void clickLoginBtn()
	{
		eleBtn.click();
	}
}
