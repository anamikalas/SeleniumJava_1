package page_repository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DemoWebsitePage 
{
	public WebDriver driver;
	
	public DemoWebsitePage(WebDriver webDriver)
	{
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this);
	}
	
	@FindBy(xpath = "//h3[text()='17 Best Demo Websites for Automation Testing Practice']")
	private WebElement elePageTitle;
	public String getpageTile() 
	{
		return elePageTitle.getText();
	}
	
	@FindBy(xpath = "//span[text()='Techlistic - DEMO TABLEs for Automation practice']")
	private WebElement eleSpan;
	public void clickTablePageLink() 
	{
		eleSpan.click();
	}
}
