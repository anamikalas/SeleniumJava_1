package page_repository;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ActionMouseHoverKeyboardAction 
{
	public WebDriver driver;
	
	public ActionMouseHoverKeyboardAction(WebDriver webDriver)
	{
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this);
	}
	
	@FindBy(xpath = "//a[@href='draggable.php']")
	private WebElement eleDragableDiv;
	public void clickDragableDiv()
	{
		eleDragableDiv.click();
	}
	
	@FindBy(xpath = "//a[text()='Interaction']")
	private WebElement eleIteration;
	public void mouseHoverOnInteraction() //hovering on Interaction
	{
		Actions actns = new Actions(driver);
		actns.moveToElement(eleIteration).perform();
	}
	
	@FindBy(xpath = "//a[text()='Interaction']/following::a[text()='Draggable']")
	private WebElement eleDraggableLink;
	public void clickDraggableLink()
	{
		eleDraggableLink.click();
	}
	
	@FindBy(xpath = "//a[text()='Draggable + Sortable']")
	private WebElement eleDraggableAndStorable;
	public void clickDraggableAndStorable()
	{
		eleDraggableAndStorable.click();
	}
	
	@FindBy(xpath = "//iframe[@src='draggable/default5.html']")
	private WebElement eleiFrame;
	public void switchiFrame()
	{
		driver.switchTo().frame(eleiFrame);
	}
	
	//@FindBy(xpath = "//li[text()='Drag me down']") private WebElement eleDragElement;
	@FindBy(xpath = "//li[text()='Item 1']") private WebElement eleDragElement;
	@FindBy(xpath = "//li[text()='Item 3']") private WebElement eleDropTo;
	public void dragAndDrop()
	{
		Actions actns = new Actions(driver);
		//actns.clickAndHold(eleDragElement).click(eleDropTo).build().perform();
		//actns.clickAndHold(eleDragElement).release(eleDropTo).build().perform();
		actns.clickAndHold(eleDragElement).dragAndDrop(eleDragElement, eleDropTo);
	}
	
	@FindBy(xpath = "//a[text()='Registration']")
	private WebElement eleRegistration;
	public void clickRegistration()
	{
		eleRegistration.click();
	}
	
	@FindBy(xpath = "//input[@name='name']") private WebElement eleFirstName;	
	public void setFirstName(String strFirstName)
	{
		eleFirstName.sendKeys(strFirstName);
	}
	
	/*@FindBy(xpath = "//input[@name='name']") private WebElement eleFirstName2;
	public void copyFNToSetLN()
	{
		Actions actns = new Actions(driver);
		actns.keyDown(Keys.CONTROL).sendKeys("c").keyDown(Keys.CONTROL).sendKeys("a").keyDown(Keys.CONTROL).sendKeys("c").keyDown(Keys.CONTROL).sendKeys("a").build().perform();
	}*/
	
	@FindBy(xpath = "//label[text()='Last Name:']/following-sibling::input") private WebElement eleLastName;	
	public void setLastName()
	{
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].value='Laskar';", eleLastName);
	}
	
	@FindBy(xpath = "//label[contains(text(),'Single')]") private WebElement eleMaritialStatus;
	public void selectMaritialStatusRadioBtn()
	{
		eleMaritialStatus.click();
	}
	
	@FindBy(xpath = "//input[@name='hobby']") private WebElement eleHobbyChkBox;
	public void selectHobbyChkBox()
	{
		eleHobbyChkBox.click();
	}
	
	@FindBy(xpath = "(//input[@name='phone'])[1]") private WebElement elePhNumber;
	public void setPhNumber(String strPhNo)
	{
		//((JavascriptExecutor)driver).executeScript("arguments[0].value='9876543210';", elePhNumber);
		elePhNumber.sendKeys(strPhNo);
	}
	
	@FindBy(xpath = "(//input[@name='username'])[1]") private WebElement eleUserNm;
	public void setUserNm(String struserNm)
	{
		eleUserNm.sendKeys(struserNm);
	}
	
	@FindBy(xpath = "//input[@name='email']") private WebElement eleEmailId;
	public void setEmailId(String strEmailId)
	{
		eleEmailId.sendKeys(strEmailId);
	}
	
	@FindBy(xpath = "//label[text()='About Yourself']/following-sibling::textarea[1]") private WebElement eleAboutYourself1;
	public void setAboutYourself()
	{
		((JavascriptExecutor)driver).executeScript("arguments[0].value='Nature is an inherent character or constitution, particularly of the ecosphere or the universe as a whole. In this general sense nature';", eleAboutYourself1);
	}
	
	@FindBy(xpath = "//label[text()='About Yourself']/following-sibling::textarea[1]") private WebElement eleAboutYourself2;
	public void setColorAboutYourself()
	{
		((JavascriptExecutor)driver).executeScript("arguments[0].setAttribute('style','background: yellow; border: 2px solid red;');", eleAboutYourself2);
	}
	
	@FindBy(xpath = "//input[@name='password']") private WebElement elePassword;
	public void setPassword()
	{
		((JavascriptExecutor)driver).executeScript("arguments[0].value='Amdocs@123';", elePassword);
	}
	
	@FindBy(xpath = "//input[@name='c_password']") private WebElement eleConfirmPassword;
	public void setConfirmpassword()
	{
		((JavascriptExecutor)driver).executeScript("arguments[0].value='Amdocs@123';", eleConfirmPassword);
	}
	
	@FindBy(xpath = "//label[text()='Your Profile Picture']/following-sibling::input[1]") private WebElement eleUploadFilePath;
	public void uploadFileBySendkeys(String strFilePath)
	{
		//((JavascriptExecutor)driver).executeScript("arguments[0].value='c:\\Users\\anamikla\\eclipse-workspace\\AmdocsCentral_19thMar2024\\ScreenShotFolder\\Error1.png';", eleUploadFilePath);
		eleUploadFilePath.sendKeys(strFilePath);
	}
	
	@FindBy(xpath = "//label[text()='Your Profile Picture']/following-sibling::input[1]") private WebElement eleUploadFileBtn;
	public void ClickuploadFileBtn() 
	{
		//((JavascriptExecutor)driver).executeScript("arguments[0]click();", eleUploadFileBtn);*/
		Actions actns = new Actions(driver);
		actns.click(eleUploadFileBtn).build().perform();
	}

}
