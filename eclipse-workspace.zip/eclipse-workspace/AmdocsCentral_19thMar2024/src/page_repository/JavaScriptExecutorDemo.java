package page_repository;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class JavaScriptExecutorDemo
{
	public WebDriver driver;
	
	public JavaScriptExecutorDemo(WebDriver webDriver) 
	{
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this);
	}
	
	@FindBy(xpath = "//a[@href='autocomplete.php']")
	private WebElement eleAutoCompleteDiv; 
	public void verifyAutocompleteDiv()
	{
		eleAutoCompleteDiv.isDisplayed();
	}
	
	@FindBy(xpath = "//a[@href='autocomplete.php']")
	private WebElement eleAutocompleteDivLink;
	public void clickAutocompleteDivLink()
	{
		eleAutocompleteDivLink.click();
	}
	
	@FindBy(xpath = "//iframe[@src='autocomplete/defult1.html']")
	private WebElement eleiFrame;
	public void switchAutocompleteiFrame()
	{
		driver.switchTo().frame(eleiFrame);
	}
	
	@FindBy(xpath = "//label[contains(text(),'Tags')]/following-sibling::input")
	private WebElement eleTextBoxInput;
	public void setValuInTextBox() //set value in TextBox by using javascriptexecutor
	{
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		//jse.executeScript("document.getElementById('tags').value='Anamika';");
		jse.executeScript("arguments[0].value='Laskar';", eleTextBoxInput);
	}
	
	@FindBy(xpath = "//label[contains(text(),'Tags')]/following-sibling::input")
	private WebElement eleTxtBoxTag1;
	public void borderWithColorTextBox() //highlighting element, setting background and border color
	{
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].setAttribute('style','border: 2px solid red;');", eleTxtBoxTag1);
	}
	
	@FindBy(xpath = "//label[contains(text(),'Tags')]/following-sibling::input")
	private WebElement eleTxtBoxTag2;
	public void bhighLightTextBox() //highlighting element, setting background and border color
	{
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].setAttribute('style','background: yellow;');", eleTxtBoxTag2);
	}
	
	@FindBy(xpath = "//label[contains(text(),'Tags')]/following-sibling::input")
	private WebElement eleTxtBoxTag3;
	public void borderWithColorAndHighlightTextBox() //highlighting element, setting background and border color
	{
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].setAttribute('style','background: yellow; border: 2px solid red;');", eleTxtBoxTag3);
	}
	
	@FindBy(xpath = "(//a[@href='alert.php'])[2]")
	private WebElement eleAlertDiv;
	public void scrollToAlertDiv()
	{
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", eleAlertDiv);
	}
}
