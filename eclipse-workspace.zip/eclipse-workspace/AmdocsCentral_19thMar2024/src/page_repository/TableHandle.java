package page_repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class TableHandle 
{
	public WebDriver driver;

	//LoginPage objLP = new LoginPage(driver);

	public TableHandle(WebDriver webDriver)
	{
		//"this" keyword is used here to distinguish global and local variable "driver"
		//gets driver as parameter from MainClass.java and assigns to the driver instance in this class 
		this.driver = webDriver;
		PageFactory.initElements(webDriver, this); // Initializes WebElements declared in this class using webDriver instance
	}

	/*@FindAll({
		@FindBy(xpath = "//table[@class='table table-bordered table-striped']"), //table xpath
		@FindBy(xpath = "//span[text()='UAE']") //text UAE xpath
	})*/

	//@FindBy(xpath = "//table[@class='table table-bordered table-striped']")
	//private WebElement eleTable;

	@FindBy(xpath = "//table[@id='customers']/tbody[1]/tr[4]/td[2]")
	private WebElement eleTableCell;	
	public String gettableCellVal() //getting table call value Contact = Francisco Chang
	{
		String strCellval = eleTableCell.getText();
		return strCellval;
	}
	
	@FindBy(xpath = "//table[@id='customers']/tbody[1]/tr[4]/td[2]/following::td[1]")
	private WebElement eleTdSiblingFollowing;
	public String getSiblingFollowingCell() 
	{
		return eleTdSiblingFollowing.getText();
	}
	
	@FindBy(xpath = "//table[@id='customers']/tbody[1]/tr[4]/td[2]/preceding::td[1]")
	private WebElement eleTableSiblingPreceeding;
	public String getSiblingPrecedingCell()
	{
		return eleTableSiblingPreceeding.getText();
	}
}
