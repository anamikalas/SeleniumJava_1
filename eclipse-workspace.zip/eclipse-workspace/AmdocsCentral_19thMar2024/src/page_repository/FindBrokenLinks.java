package page_repository;

public class FindBrokenLinks 
{
	
	public void getUrlOfBrokenSite()
	{
		
	}
}
