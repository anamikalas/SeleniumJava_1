package test_suite;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.Set;

import javax.swing.text.Document;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import page_repository.*;
import utilities.FileOperation_txtFile;

public class ActionMouseHoverKeyboardAction_Test extends BaseClass
{
	FileOperation_txtFile objFO = new FileOperation_txtFile();
	
	@Test(enabled = false, priority = 1)
	public void testMethod1()
	{	
		ActionMouseHoverKeyboardAction objA = new ActionMouseHoverKeyboardAction(driver);
		objA.clickDragableDiv();
				
		String strDefaultWindowHandle = driver.getWindowHandle(); //getting main window handle
		Set<String> setAllWindowHandle = driver.getWindowHandles(); //getting all window handle
		
		for(String strAllWindowHandle : setAllWindowHandle) //for each loop to switch newly opened window
		{
			if(!strDefaultWindowHandle.equals(strAllWindowHandle))
				driver.switchTo().window(strAllWindowHandle); //switching to newly opened window
		}
		
		objA.mouseHoverOnInteraction(); //mouse hover on Interaction tab
		objA.clickDraggableLink(); //clicking on Draggable link present on Interaction menu
		objA.clickDraggableAndStorable();
		objA.switchiFrame();
		objA.dragAndDrop();
	}
	
	@Test(enabled=true)
	public void keyBoardAction()
	{
		try
		{
		ActionMouseHoverKeyboardAction objK = new ActionMouseHoverKeyboardAction(driver);
		objK.clickDragableDiv();
		
		String strDefaultWindowHandle = driver.getWindowHandle();
		Set<String> setAllWindowHandle = driver.getWindowHandles();
		
		for(String strAllWindowHandle : setAllWindowHandle)
		{
			if(!strAllWindowHandle.equals(strDefaultWindowHandle))
				driver.switchTo().window(strAllWindowHandle);
		}
		
		objK.clickRegistration();
		objK.setFirstName("Anamika");
		//objK.copyFNToSetLN();
		
		//copy paste First Name
		Actions actns = new Actions(driver);
		actns.keyDown(Keys.CONTROL).sendKeys("c").keyDown(Keys.CONTROL).sendKeys("a").keyDown(Keys.CONTROL).sendKeys("c").keyDown(Keys.CONTROL).sendKeys("a").build().perform();
		
		objK.setLastName();
		objK.selectMaritialStatusRadioBtn();
		objK.selectHobbyChkBox();
		
		Select ddlCountry = new Select(driver.findElement(By.xpath("(//label[text()='Country:']/following::select[1])[1]")));
		ddlCountry.selectByValue("India");
		
		Select ddlMonth = new Select(driver.findElement(By.xpath("(//label[text()='Date of Birth:']/following::select[1])[1]")));
		ddlMonth.selectByIndex(1);
		
		Select ddlDay = new Select(driver.findElement(By.xpath("(//label[text()='Date of Birth:']/following::select[2])[1]")));
		ddlDay.selectByVisibleText("1");
		
		Select ddlYear = new Select(driver.findElement(By.xpath("(//label[text()='Date of Birth:']/following::select[3])[1]")));
		ddlYear.selectByIndex(1);
		
		//FileOperation_txtFile objFO = new FileOperation_txtFile(); //creating object of input file
		objK.setPhNumber(objFO.readPropertyFile("Phone_Number_Reg"));
		//objK.setPhNumber();
		objK.setUserNm(objFO.readPropertyFile("User_Name_Reg"));
		objK.setEmailId(objFO.readPropertyFile("Email_Reg"));

		objK.setAboutYourself(); //providing fixed value by using javascript executor
		objK.setColorAboutYourself();
		objK.setPassword(); //providing fixed value by using javascript executor
		objK.setConfirmpassword(); //providing fixed value by using javascript executor
		objK.uploadFileBySendkeys("C:\\Users\\anamikla\\OneDrive - AMDOCS\\Backup Folders\\Desktop\\All_LCD\\Holiday_Pdf"); //uploading file by Sendkeys when type=file
		objK.ClickuploadFileBtn();
		
		StringSelection strSel1 = new StringSelection("C:\\AC-KT\\OrderITKitDocument.docx");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(strSel1,null);
		
		//upload file
		Robot rb = new Robot();
		rb.delay(8000);	
		
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
	      
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
