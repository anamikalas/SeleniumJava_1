package test_suite;

import java.io.File;
import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import page_repository.MulWindowTkScreenshotJSExecutor;

//click by using javascriptexecutor
//handle multiple window
//taking screen shot
//soft assert

public class MulWindowTkScreenshotJSExecutor_Test extends BaseClass
{
	@Test(enabled=false)
	public void Test_Method1()
	{
		MulWindowTkScreenshotJSExecutor objWC = new MulWindowTkScreenshotJSExecutor(driver);
		
		objWC.verifyFramesAndWindowsDiv(); //verifying that div is visible
		objWC.clickFramesAndWindows(); //clicking on link by using javascriptexecutor
		
		String strDefaultWindowHandle = driver.getWindowHandle(); //getting default window handle
		
		Set<String> setAllWindowHandles = driver.getWindowHandles(); //getting all window handle
		
		for(String strAllWinDowHandle : setAllWindowHandles) //foreach loop to switch newly opened window
		{
			if(!strDefaultWindowHandle.equals(strAllWinDowHandle))
				driver.switchTo().window(strAllWinDowHandle);
		}
		
		/*objWC.swithToNewWindow(); //switching to newly opened window */
		
		objWC.switchiFrame(); //switching to iFrame
		
		objWC.clikNewBrowserTabLink();
		objWC.clikNewBrowserTabLink1(); //method will fail bcoz element not found, xpath is wrong. Failing method and taking screen shot
	}
	
	@AfterMethod
	public void takeScreenSHot(ITestResult iTestResult)
	{
		try
		{
		if(iTestResult.getStatus() == ITestResult.FAILURE)
		{
			TakesScreenshot tkSC = (TakesScreenshot)driver;
			File file = tkSC.getScreenshotAs(OutputType.FILE);
			FileHandler.copy(file, new File(".\\ScreenShotFolder\\Error1.png"));
		}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	
	@Test(enabled=false)
	public void softAssertDemo()
	{
		SoftAssert sa1 = new SoftAssert();
		sa1.assertEquals(1, 2);
		System.out.println("Soft assert 1....");
		
		SoftAssert sa2 = new SoftAssert();
		sa2.assertEquals(3, 4);
		System.out.println("Soft assert 2....");
		
		sa1.assertAll();
		System.out.println("Assert all 1....");
		
		sa2.assertAll();
		System.out.println("Assert all 2....");		
	}
}