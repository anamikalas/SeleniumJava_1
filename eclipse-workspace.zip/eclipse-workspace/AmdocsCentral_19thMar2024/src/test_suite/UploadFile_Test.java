package test_suite;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import page_repository.*;

public class UploadFile_Test extends BaseClass
{

	//************UPLOAD FILE BY USING SENDKEYS******************************************************************************************************************//
	@Test(enabled = false, priority=1)
	public void uploadFileBySendKeys()
	{
		UploadFile objUP = new  UploadFile(driver);
		
		objUP.uploadFileBySendkeys("C:\\Users\\anamikla\\OneDrive - AMDOCS\\Backup Folders\\Desktop\\All_LCD\\Holiday_Pdf"); //uploading file by Sendkeys when type=file
	}
	
	@Test(enabled = true, priority=1)
	public void uploadFileByRobotClass() throws AWTException
	{
		UploadFile objUP = new  UploadFile(driver);
		
		objUP.clickDragableDiv(); //clicking Draggable div
		
		String strDefaultWindowHandle = driver.getWindowHandle(); //getting default window handle
		Set<String> setAllWindowHandle = driver.getWindowHandles(); //getting all window handle
		
		for(String strAllWindowHandle : setAllWindowHandle)
		{
			if(!strAllWindowHandle.equals(strDefaultWindowHandle))
				driver.switchTo().window(strAllWindowHandle); //switching newly opened window
		}
		
		objUP.clickRegistration(); //clicking on registration tab
		
		//********************FILE UPLOAD START******FILE UPLOAD BY ROBOT CLASS*******************************************************************************************//
		objUP.ClickuploadFileBtn(); //clicking on file upload button
		
		StringSelection strSel1 = new StringSelection("C:\\AC-KT\\OrderITKitDocument.docx"); //copying file path in clipboard
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(strSel1,null);
		
		//using Robot class to upload file
		Robot rb = new Robot();
		rb.delay(8000);	
		
		rb.keyPress(KeyEvent.VK_CONTROL); //pressing ctrl
		rb.keyPress(KeyEvent.VK_V); //pressing v
		
		rb.keyRelease(KeyEvent.VK_CONTROL); //releasing ctrl
		rb.keyRelease(KeyEvent.VK_V); //releasing v
		
		rb.keyPress(KeyEvent.VK_ENTER); //pressing Enter key
		rb.keyRelease(KeyEvent.VK_ENTER); //releasing Enter key
	}
}
