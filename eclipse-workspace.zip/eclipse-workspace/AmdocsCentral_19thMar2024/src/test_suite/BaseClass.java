package test_suite;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import utilities.BrowserOperation;
import utilities.FileOperation_txtFile;

public class BaseClass 
{
	public WebDriver driver;
	
	BrowserOperation objBO = new BrowserOperation();
	
	@BeforeMethod (enabled=false)
	public void launchApplicationTable() throws Exception /*https://www.techlistic.com/2020/07/automation-testing-demo-websites.html*/
	{		
		try
		{
		Reporter.log("Launch Application");
		//BrowserOperation objBO = new BrowserOperation();
		driver = objBO.launchApplicationTable();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	@BeforeMethod(enabled=false)
	public void launchApplicationJSExecutor() throws Exception /*https://www.way2automation.com/way2auto_jquery/automation-practice-site.html*/
	{
		try
		{
			Reporter.log("Launch Application JS Executor");
			driver = objBO.launchApplicationJSExecutor();
		}
		catch(Exception ex)
		{
			throw ex;
		}
	}
	
	@BeforeMethod(enabled = true)
	public void launchSiteWithBrokenUrl() //Url - http://www.deadlinkcity.com/
	{
		try
		{
			Reporter.log("Launch Site With Broken Url");
			driver = objBO.launchApplicationOfBrokenUrl();
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}
	
	@AfterMethod
	public void closeBrowser()
	{
		Reporter.log("Close Browser");
		//driver.quit();
	}
}
