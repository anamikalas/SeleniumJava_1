package test_suite;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import page_repository.DemoWebsitePage;
import page_repository.LoginPage;
import utilities.FileOperation_txtFile;

public class DemoWebsitePageTest extends BaseClass
{
	@Test(priority = 1)
	public void Test_DoLogin() throws IOException 
	{
		try
		{
			DemoWebsitePage objDP = new DemoWebsitePage(driver);
			String strPgTitle1 = objDP.getpageTile();
			
			FileOperation_txtFile objFO = new FileOperation_txtFile();
			String strPgTitle2 = objFO.readPropertyFile("Demo_Page_Title");
			
			Assert.assertEquals(strPgTitle1, strPgTitle2);
			
			//LoginPage objLP = new LoginPage(driver);
			//objLP.setUserName("");
			//objLP.setPassword("");
			//objLP.clickLoginBtn();
			
			//DemoWebsitePage objDP = new DemoWebsitePage(driver);
			objDP.clickTablePageLink();
		}
		catch(Exception ex)
		{
			throw ex;
		}
	}
}
