package test_suite;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import page_repository.DemoWebsitePage;
import page_repository.LoginPage;
import page_repository.TableHandle;
import utilities.FileOperation_txtFile;

//handle table
public class TableHandle_Test extends BaseClass
{
	//verifying table data
	@Test(priority=1, enabled=false)
	public void getAndVerifyTableCellData() throws IOException
	{
		try
		{
			DemoWebsitePage objDP = new DemoWebsitePage(driver);
			objDP.clickTablePageLink();	//redirecting to the table page	

			FileOperation_txtFile objFOT = new FileOperation_txtFile();
			String strContactNm = objFOT.readPropertyFile("Contact_Name"); //reading Contact = Roland Mendel
			String strCountry = objFOT.readPropertyFile("Country_Name"); //reading Country = Austria
			String strCompanyNm = objFOT.readPropertyFile("Company_Name"); //reading Company = Microsoft

			TableHandle objMP = new TableHandle(driver);
			String strComNm = objMP.gettableCellVal(); //calling method to get Contact = Roland Mendel
			Assert.assertEquals(strContactNm, strComNm); //verifying Contact = Roland Mendel	

			Assert.assertEquals(strCountry, objMP.getSiblingFollowingCell()); //Verifying Country of Roland Mendel = Austria 
			Assert.assertEquals(strCompanyNm, objMP.getSiblingPrecedingCell()); //Verifying Company = Microsoft
		}
		catch(Exception ex)
		{
			throw ex;
		}
	}

	@Test(priority=2, enabled=false)
	public void getTableBodyRowData() 
	{
		try
		{
			DemoWebsitePage objDP = new DemoWebsitePage(driver);
			objDP.clickTablePageLink();	//redirecting to the table page	

			WebElement eleTable = driver.findElement(By.xpath("//table[@id='customers']"));
			WebElement eleTBody = eleTable.findElement(By.tagName("tbody")); //getting all data of a table body - all row
			List<WebElement> eleList = eleTBody.findElements(By.tagName("tr"));

			for (WebElement webEle : eleList) 
			{
				System.out.println(webEle.getText());
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	@Test(priority=3, enabled=true)
	public void getTableData()
	{
		try
		{
			DemoWebsitePage objDP = new DemoWebsitePage(driver);
			objDP.clickTablePageLink();	//redirecting to the table page

			//driver.findElement(By.xpath("//div[@id='dismiss-button']")).click();

			WebElement weTab = driver.findElement(By.xpath("//table[@id='customers']"));
			WebElement weTbody = weTab.findElement(By.tagName("tbody"));
			WebElement weRow = weTbody.findElement(By.tagName("tr"));
			WebElement weTh = weRow.findElement(By.tagName("th"));
			WebElement weCol = weTbody.findElement(By.tagName("td"));

			List<WebElement> lstRow = weTbody.findElements(By.tagName("tr"));
			List<WebElement> lstColCol = weTbody.findElements(By.tagName("td"));

			int noOfRows = lstRow.size(); //getting no. of rows
			int noOfColumn = lstColCol.size(); //getting no. of columns

			System.out.println("No of rows: " + noOfRows);
			System.out.println("No of columns: " + noOfColumn);

			//getting all header name of a table
			List<WebElement> lstHeader = weTbody.findElements(By.tagName("th"));
			for (WebElement webElement : lstHeader) 
			{
				System.out.println("Header name: " + webElement.getText());
			}
			
			//getting table body data without header name
			List<WebElement> lstBody = weTbody.findElements(By.tagName("td")) ;
			for(WebElement webEle : lstBody)
			{
				System.out.println("Table body data: " + webEle.getText());
			}
		}
		catch(Exception ex)
		{
			throw ex;
		}
		finally
		{

		}
	}
}

