package test_suite;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import page_repository.JavaScriptExecutorDemo;
import test_suite.*;

public class JavaScriptExecutorDemo_Test extends BaseClass
{
	JavaScriptExecutorDemo objJSE = new JavaScriptExecutorDemo(driver);
	
	@Test(enabled = true)
	public void switchToNewlyOpenedWindow()
	{
		try
		{
		JavaScriptExecutorDemo objJSE = new JavaScriptExecutorDemo(driver);
		objJSE.verifyAutocompleteDiv();
		objJSE.clickAutocompleteDivLink(); //clicking on link
		
		String strDefaultWindowHandle = driver.getWindowHandle();
		Set<String> setAllWindowHandle = driver.getWindowHandles();
		
		for(String strAllWindowHandle : setAllWindowHandle)
		{
			if(!strDefaultWindowHandle.equals(strAllWindowHandle))
			{
				driver.switchTo().window(strAllWindowHandle); //switching to newly opened window
			}
		}
		
		objJSE.switchAutocompleteiFrame(); //switching iFrame
		
		objJSE.setValuInTextBox(); //set value in textBox by using javascriptexecutor
		
		//objJSE.borderWithColorTextBox(); //border color TextBox
		//objJSE.bhighLightTextBox(); //highlight TextBox
		objJSE.borderWithColorAndHighlightTextBox(); //highlighting element, setting background and border color
		
		driver.switchTo().defaultContent(); //switching to default frame
		
		//objJSE.scrollToAlertDiv(); //scrolling to that element
		
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		//jse.executeScript("arguments[0].scrollIntoView(true);", eleAlertDiv);
		//jse.executeScript("arguments[0].scrollIntoView();", eleAlertDiv);
		//jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		jse.executeScript("window.scrollBy(0,document.body.scrollHeight)");
	}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	@Test(enabled = false)
	public void verifyTextBoxIsDisplayed() //when elements are there with same xpath
	{
		try
		{
			List<WebElement> lstWebEle = driver.findElements(By.xpath("//input[@id='tags']"));
			
			for(WebElement webEle : lstWebEle)
			{
				if(webEle.isDisplayed()) //verifying WebElement is visible when multiple WebElement are there
				{
					webEle.sendKeys("Anamika"); //setting txt if TextBox is displaying
				}
			}
		}
		catch(Exception ex)
		{
			throw ex;
		}
	}

}
