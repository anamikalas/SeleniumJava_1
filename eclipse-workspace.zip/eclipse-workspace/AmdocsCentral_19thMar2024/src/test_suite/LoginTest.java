package test_suite;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.*;
import org.testng.annotations.Test;

import page_repository.LoginPage;
import utilities.FileOperation_txtFile;

public class LoginTest extends BaseClass
{
	@Test
	public void testMethod1() throws IOException
	{
		try
		{
		FileOperation_txtFile objFO = new FileOperation_txtFile();
		//String strUserNm = objFO.readPropertyFile("User_Name");
		String strPwd = objFO.readPropertyFile("User_Pwd");
		
		WebElement eleiFrame = driver.findElement(By.xpath("//iframe[@id='gsft_main']"));
		driver.switchTo().frame(eleiFrame);
		LoginPage objLP = new LoginPage(driver);
		//objLP.setUserName(strUserNm);
		objLP.setUserName(objFO.readPropertyFile("User_Name"));
		objLP.setPassword(strPwd);
		objLP.clickLoginBtn();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
