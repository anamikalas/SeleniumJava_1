package test_suite;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class FindBrokenLinks_Test extends BaseClass
{
	@Test(enabled=true, priority=1)
	public void getBrokenLink() throws MalformedURLException, IOException, URISyntaxException
	{
		int responseCode = 0, countBrokenUrl = 0;
		List<WebElement> eleList = driver.findElements(By.tagName("a")); //getting all the url of the webpage
		System.out.println("Total links are: " + eleList.size()); //printing all the url

		for(WebElement ele : eleList)
		{
			String strUrl = ele.getAttribute("href"); //getting attribute of webelement

			if(strUrl==null || strUrl.isEmpty())
			{
				System.out.println("Url is empty...");
				continue;
			}
			try
			{
				HttpURLConnection con = (HttpURLConnection) new URI(strUrl).toURL().openConnection(); //opening connection with url
				con.setRequestMethod("HEAD"); //request method is HEAD
				con.connect(); //establishing connection
				
				responseCode = con.getResponseCode(); //getting response code
				
				if(responseCode >= 400) //when response code is 400 or greater than that something wrong with url
				{
					System.out.println("Broken url: " + strUrl); //print broken url
					countBrokenUrl++; //getting count of broken url
				}
			}	
			catch(MalformedURLException ex)
			{
				ex.printStackTrace();
			}
			catch(IOException ex)
			{
				ex.printStackTrace();
			}
			
		}
		System.out.println("Count of broken link: " + countBrokenUrl); //printing total count of broken url
	}
}
