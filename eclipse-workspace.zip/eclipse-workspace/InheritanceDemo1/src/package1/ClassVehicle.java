package package1;

public class ClassVehicle 
//final public class ClassVehicle - "FINAL" keyword prevent inheritance
{
	public ClassVehicle(int a)
	{
		System.out.println(a);
		System.out.println("Vehicle constractor...");
	}
	public void accelerate()
	{
		System.out.println("Veicle accelerate...");
	}
	public void brake()
	{
		System.out.println("Vehicle brake...");
	}
}
