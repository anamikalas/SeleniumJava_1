package package1;

public class MainClassInheritance 
{
	//how to implement inheritance - by using extends keyword
	// which constructor will get called when we create an object 
	public static void main(String[] args)
	{
		ClassCar objCar = new ClassCar(10);
		//objCar.accelerate(); //inheriting accelerate() from vehicle class
		//objCar.brake(); //inheriting brake() from vehicle class
	}
}
