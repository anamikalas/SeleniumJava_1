package package1;

public class MainClass_Sir 
{

	// 1. How to implement inheritance - extends keyword
	// 2. Which constructor will get called when we create an object of child class -  Both the constructor will be called
	// first it will call parent class constructor and then child class constructor
	// 3. What is the use of super keyword - to call base class parameterized constructor and to call base class method
	// 4. How to prevent inheritance - final keyword
	// 5. this keyword - to use global variable
	public static void main(String[] args) {
		
		Car_Sir obj=new Car_Sir(10);
		//obj.Accelearate();
		//obj.Brake();
		
		//Bike obj1=new Bike();
		//obj1.Accelearate();
		//obj1.Brake();

		String str="Hello";
	}

}
