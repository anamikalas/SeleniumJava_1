package package1;

public class Car_Sir extends Vehicle_Sir
{
	
	public Car_Sir(int b)
	{
		super(100); // Calling parent class constructor
		System.out.println(b);
		System.out.println("Car constructor.........");
	}
	
	public void AudiCar()
	{
		super.Accelearate(); // Calling parent class method
	}

}
