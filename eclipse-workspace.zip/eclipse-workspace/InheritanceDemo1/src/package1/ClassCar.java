package package1;

public class ClassCar extends ClassVehicle
{
	public ClassCar(int b)
	{
		super(100); //calling parent class constructor
		System.out.println(b);
		System.out.println("Car constractor...");
	}
	public void audiCar()
	{
		super.accelerate(); //calling parent class method
	}
}
