package package1;

//final public class Vehicle - prevent inheritance
public class Vehicle_Sir 
{
	
	public Vehicle_Sir(int a)
	{
		System.out.println(a);
		System.out.println("Vehicle constructor............");
	}
	
	public void Accelearate()
	{
		System.out.println("Vehicle accelerate");
	}
	
	public void Brake()
	{
		System.out.println("Vehicle brake");
	}
	

}
