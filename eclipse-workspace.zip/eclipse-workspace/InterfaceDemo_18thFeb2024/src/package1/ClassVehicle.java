package package1;

public class ClassVehicle 
{
	public static void methodStatic1()
	{
		System.out.println("Static ethod Vehicle class...");
	}
	
}
