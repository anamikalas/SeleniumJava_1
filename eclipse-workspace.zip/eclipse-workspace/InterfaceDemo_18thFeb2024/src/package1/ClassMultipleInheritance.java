package package1;

//If method name is same in 2 different Interface than java will consider only 1 method
interface A
{
	public void M1();
}

interface B
{
	public void M1();
}

public class ClassMultipleInheritance implements A,B
{
	public void M1()
	{
		System.out.println("Method name is same in 2 different Interface...");
	}
}
