package package1;

interface myBikeInterface
{
	void methodColor();
}

public class ClassBike implements myCarInterface, myBikeInterface
{
	public void methodColor()
	{
		System.out.println("Color method...");
	}
	public void methodAccelerate()
	{
		System.out.println("Accelerate method myInterfcaeCar...");
	}
	public void methodBrake()
	{
		System.out.println("Brake method myInterfcaeCar...");
	}
	public int methodEngine(int a)
	{
		System.out.println("Engine method myInterfcaeCar...");
		return 10;
	}
}
