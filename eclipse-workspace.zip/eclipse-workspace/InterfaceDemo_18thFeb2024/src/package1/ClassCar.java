package package1;

//Inside method we can declare method but can't define method
//Interface doen't require access modifier
//What is the default access odifier of method inside Interface - public
//If we implement an interface i our class than all the method inside interface has to be implemented
//One class can implement multiple Interface
//If method name is same in 2 different Interface than java will consider only 1 method
//Can we declare variable inside Interface - Yes, but can not change it's value
interface myCarInterface
{
	void methodAccelerate();
	void methodBrake();
	int methodEngine(int a); //Properties are same but implementation is different
	int b = 0;
	String str = "";
	
}

public class ClassCar implements myCarInterface
{
	public void methodAccelerate()
	{
		System.out.println("Accelerate method....");
	}
	public void methodBrake()
	{
		System.out.println("Brake method...");
	}
	public int methodEngine(int a)
	{
		System.out.println("Engine method...");
		return 10;
	}
}
