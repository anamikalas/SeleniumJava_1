package package1;

public class ClassTruck extends ClassVehicle
{
	public static void methodStatic1()
	{
		System.out.println("Staic method Truck...");
	}
}
