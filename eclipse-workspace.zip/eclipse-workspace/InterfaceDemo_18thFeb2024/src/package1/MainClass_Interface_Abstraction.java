package package1;

public class MainClass_Interface_Abstraction 
{
	public static void main(String[] args)
	{
		//ClassBike objB = new ClassBike();
		//ClassVehicle objCV = new ClassVehicle();
		ClassVehicle.methodStatic1();
		ClassTruck.methodStatic1();
	}
}
