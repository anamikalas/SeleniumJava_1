package packageInterface_UT;


interface myInterface1
{
	//If we are not defining any access modifier to the field then java compiler by default considering it public static final
	//Other than public static final no other variable type is supported in interface
	int intVar = 10; 
	
	void show1(); 
	
	/*Will show error bcoz only public, private and default modifier is allowed, Protected is not allowed
	protected void show2() 
	{
		
	}*/
	
	//By default access method is public abstract
	
	//Using static keyword we can define method body inside interface
	static void show3() 
	{
		
	}
	
	//Using default access modifier we can define method body inside interface
	default void show4() 
	{
		
	}
}

interface myInterface2
{
	void display1();
}

public class ClassInterfaceDemo_UT implements myInterface1, myInterface2
{
	//Here we are not assigning any access modifier, hence without access modifier java compiler will. show compile time exception.//
	//void show()	
	
	//When we are implementing any abstract method from interface we need to provide public access modifier to the method of child class,
	//else java compiler will throw compile time exception, becoz when we are implementing any method to child class scope of access modifier need to be public. 
	public void show1()  
	{
		System.out.println("My interface1, show1 method");
	}
	public void display1() //if we are not implementing display1() then it will show compile time error "must inherited abstract method display1()"
	{
		System.out.println("My interface2, Display1 method...");
	}
}