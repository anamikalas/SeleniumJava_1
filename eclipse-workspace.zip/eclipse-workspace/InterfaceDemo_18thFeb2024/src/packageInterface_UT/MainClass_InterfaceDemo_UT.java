package packageInterface_UT;

public class MainClass_InterfaceDemo_UT 
{
	public static void main(String[] args)
	{
		//will show compile time error myInterface1 is a abstract can't instantiated
		//myInterface1 objI = new myInterface1();
		
		
		ClassInterfaceDemo_UT objUT = new ClassInterfaceDemo_UT();
		objUT.show1(); //Called interface myInterface1 method in child class and then printed
		objUT.display1(); //Called interface myInterface2 method in child class and then printed
	}
}
