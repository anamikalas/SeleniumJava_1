package test_script;
import java.awt.Window;
import java.security.Timestamp;
import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import object_repository.LoginPage;
import utilities.FileOperation_IT;

public class LoginPage_Test extends BaseClass
{	
	LoginPage objL = new LoginPage(driver);
	String strMailBody = "";
	String strNew = "";
	
	public void switchToSpecificWindow(int windowId)
	{
		String strNewWindow = "";
		Set<String> setWindowHandle = driver.getWindowHandles();
		Iterator<String> itrWindowHandle = setWindowHandle.iterator();

		for(int i=0; i<=windowId; i++)
		{
			strNewWindow = itrWindowHandle.next();
		}

		driver.switchTo().window(strNewWindow);
	}
	
	public String extractNumberFromText(String strMailBdy)
	{
		LoginPage objL = new LoginPage(driver);
		strMailBody = objL.getOutlookMailBodyText();
		char charArr[] = strMailBody.toCharArray();
		

		for(int i=0; i<charArr.length; i++)
		{
			if(Character.isDigit(charArr[i]))
				strNew = strNew + charArr[i];
		}

		//int num = Integer.parseInt(strNew);
		strNew = strNew.substring(1, 7);
		return strNew;
	}

	@Test(enabled = true, priority = 1)
	public void testLogin()
	{
		try
		{
			LoginPage objL = new LoginPage(driver);
			FileOperation_IT objF = new FileOperation_IT();

			objL.switchiFrame();
			objL.setUserName(objF.readPropertiesFile("AC_User_Id"));
			objL.setPassword(objF.readPropertiesFile("AC_User_Pwd"));
			objL.clickLoginBtn();

			if(driver.findElement(By.xpath("//input[@id='email_factor']")).isSelected()) //if CheckBox is selected
			{
				objL.clickContinueBtn();
			}
			else
			{
				objL.checkCheckBox();
			}
			objL.clickContinueBtn();
			
			String strDefaultWindowHandleBE = driver.getWindowHandle();

			driver.switchTo().newWindow(WindowType.TAB); //opening a new tab
			driver.get(objF.readPropertiesFile("AC_Outlook_2")); //launching outlook in newly opened tab	

			switchToSpecificWindow(1); //Switching to outlook window

			//objL.setOutlookUserName(objF.readPropertiesFile("Outlook_UserNm"));		
			//objL.clickOutlookOkButton();

			objL.setOutlookEmail(objF.readPropertiesFile("Outlook_Email")); //set email id
			objL.clickOutlookNextBtn(); //click Next button
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(300)); //apply Explicit wait
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//span[text()='Multi-factor one-time password for user Anamika Laskar (Admin)']"))));
			
			objL.clickOnDraftFolder(); //click on Draft
			objL.clickOutlookInbox(); //click on Inbox
			objL.clickOutlookMultifactor();
			extractNumberFromText(strNew); //getting mail body and extracting number from text
			System.out.println("Number: " + strNew);
			driver.close(); //closing the outlook window/tab
			
			driver.switchTo().window(strDefaultWindowHandleBE); //switch to default window
			
			objL.switchiFrame();
			objL.set6DigitVerficationCode(strNew); //set 6 digit verification code
			objL.clickVerifyBtn();
			
			driver.switchTo().newWindow(WindowType.TAB);
			driver.get(objF.readPropertiesFile("AC_Url_IT_FE")); //launching FE
			
		}


		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}

